CREATE USER 'zabbix-dev'@'%' IDENTIFIED BY 'Workit2017';
GRANT SELECT ON  *.*  TO 'zabbix-dev'@'%';
FLUSH PRIVILEGES;
