#!/bin/bash
# TO BE ADD IN OPS_...
# UserParameter=workit.db.mysql.wv4.sizing.get_metrics[*],/opt/workit/get_mysql_metrics_caller.sh $1


BGB_DB_USER='opsadmin'
export MYSQL_PWD='W@rk1T!!!'

PLATFORM=$(hostname | sed -e 's/..\(..\).*/\1/')
BGB_DB_NAME="workit_${PLATFORM}_v4"
case "$PLATFORM" in
"fr")
  BGB_DB_NAME="workit_bgb_v4"
  ;;
"fa")
  BGB_DB_NAME="workit_fashion_v4"
  ;;
"ad")
  BGB_DB_NAME="workit_adhoc_v4"
  ;;
esac

if [ $# -lt 1 ]; then
	echo "0";
else 
	if [ "$1" == "site_product_instances" ]; then
		/usr/bin/mysql -sN --silent --user=${BGB_DB_USER}  --database=${BGB_DB_NAME}  --execute='SELECT COUNT(*) FROM site_product_instances;' 
	elif [ "$1" == "catalog_product_identifiers" ]; then
		/usr/bin/mysql -sN --silent --user=${BGB_DB_USER}  --database=${BGB_DB_NAME}  --execute='SELECT COUNT(*) FROM catalog_product_identifiers;'
	elif [ "$1" == "information_schema.tables" ]; then
		/usr/bin/mysql -sN --silent --user=${BGB_DB_USER}  --database=${BGB_DB_NAME}  --execute="SELECT Round(Sum(data_length + index_length) / 1024 / 1024, 1) FROM   information_schema.tables  WHERE table_schema = '${BGB_DB_NAME}' GROUP  BY table_schema;" 
	else
		echo "0"
	fi
fi
