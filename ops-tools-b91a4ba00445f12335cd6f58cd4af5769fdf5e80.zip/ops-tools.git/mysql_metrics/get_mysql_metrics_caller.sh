#!/bin/bash
# To be configure in ZABBIX agent file
/usr/bin/curl -s http://gitlab.workit.fr/ops-team/ops-tools/raw/master/mysql_metrics/get_mysql_metrics_workit.sh | bash /dev/stdin $1
