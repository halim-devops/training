#!/bin/bash
if echo $1 | grep -Eq "([0-9]{1,3}\.){3}[0-9]{1,3}/[0-9]{1,3}"; then
	echo YES
else
	echo NO
fi
