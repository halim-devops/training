#!/bin/bash
OLD_NAS="10.10.12.33"
LIST_FSTAB=""
LIST_MONTAGE_LOCAL=""
NEW_NAS="10.16.100.154:\/zpool-125392\/ZPOOL"
DATE=`date +%Y%m%d`
FSTAB="/etc/fstab"
FSTAB_BAK="$FSTAB.$DATE"
FSTAB_TO_UPD="$FSTAB"
for lfstab in `sudo cat /etc/fstab |grep $OLD_NAS|grep -v "#"|awk '{print $2}'`; do
	LIST_FSTAB="$LIST_FSTAB $lfstab"
done

echo "Check if mounted folder are used"
for i in $LIST_FSTAB; do
	USE=`lsof |grep $i|wc -l`
	if [ "x0" != "x$USE" ]; then
		echo "Folder $i is in use we will be unable to umount it"
		exit 1
	else
		echo "Folder $i is not used"
	fi
done;

echo "List of mounted filesystem : $LIST_FSTAB"
# unmount all mounted folder
for i in $LIST_FSTAB; do
	echo "Umounting $i"
	sudo umount -l $i
done;


echo "Backing up $FSTAB to $FSTAB_BAK"
sudo cp $FSTAB $FSTAB_BAK
for i in $LIST_FSTAB; do
	regex=`echo $i|sed 's/\//./g'`
#	echo $regex
	sudo sed  -i -e "/$regex/s/^10.10.12.33.*volume1\(.*\)/#&\n$NEW_NAS\\1/" $FSTAB_TO_UPD
done;


echo "Mounting all the new zpool"
sudo mount -a

#echo "#################################################################"
mount|grep ZPOOL
#echo "#################################################################"
