#!/bin/bash
sudo /etc/init.d/puppet stop
sudo update-rc.d -f puppet remove
