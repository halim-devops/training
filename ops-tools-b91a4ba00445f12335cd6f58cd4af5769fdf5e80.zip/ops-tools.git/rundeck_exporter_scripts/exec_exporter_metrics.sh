#/bin/bash
### Script de gestion de lancement des jobs EXPORTER METRICS via RUNDECK

# Arguments
FLUX=$1
MEMOIRE=$2
# Variable
SLEEPMIN=1
SLEEPMAX=15


# Au cas ou on sait pas se servir de ce script 
function usage() {
        echo "MAUVAISE UTILISATION DU SCRIPT"
        echo "USAGE: ./launch_exporter_metrics  <FLUX> <MEMOIRE>"
        echo "EXEMPLE: ./launch_exporter_metrics <FLUX> <MEMOIRE>"
        echo "AUTRE EXEMPLE: ./launch_exporter_metrics bcc/xml -Xmx4096 -Xms4096m"
        exit 1
}

LOG="/mnt/nas-e1/exporter/$(echo $1 | sed -e 's/\//_/g')_$(date +%Y%m%d-%H%M%S)-metrics-rundeck.log"

#Si tout est OK on lance la commande Exporter (voir check des variables vides en bas!)
function launchExporter() {
        # On temporise un peu pour éviter un éventuel gouleau d'etranglement si le HAPROXY fait de la merde..."
        # Un petit RANDOM
        DELAI=$((SLEEPMIN+RANDOM*(1+SLEEPMAX-SLEEPMIN)/32767))
        echo "Lancement de la commande Exporter dans $DELAI secondes"
        sleep $DELAI
        # LAUNCH
        sudo -u wit-exporter /usr/bin/java $MEMOIRE -jar /opt/workit/exporter/lib/metrics.jar --config-location /etc/workit/exporter/metrics/ --feed $FLUX | tee $LOG
        if [ $? -eq 1 ]; then
                echo METRICS SYSTEM ERROR
                exit 1
        elif [ $? -eq 0 ]; then
                echo METRICS SUCESS
                exit 0
        else
                echo METRICS FUNCTIONAL ERROR
                echo "Code Ret: $?"
                exit 0
        fi
}


# Check des arguments, $MEMOIRE est optionnel (check inutile)
if [[ -z $FLUX ]] ;then
        usage
else
        launchExporter
fi
