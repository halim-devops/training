#/bin/bash
### Script de gestion de lancement des jobs EXPORTER via RUNDECK

# Arguments
ENVIRONNEMENT=$1
PLATEFORME=$2
FLUX=$3
LOG=$4
MEMOIRE=$5
# Variable
SLEEPMIN=1
SLEEPMAX=15
# Overwrite LOG parameter !!! what the idea to set in parameter !!!! for each jobs ?!?!? !!!
LOG="/mnt/nas-e1/exporter/$(echo ${FLUX}| sed -e 's/\//_/g')_${PLATEFORME}__$(date +%Y%m%d-%H%M%S)-rundeck.log"
echo "Overwriting LOG by $LOG"

# Au cas ou on sait pas se servir de ce script 
function usage() {
        echo "MAUVAISE UTILISATION DU SCRIPT"
        echo "USAGE: ./launch_exporter <ENVIRONNEMENT> <PLATEFORME> <FLUX> <REPERTOIRE DE LOG> <MEMOIRE (OPTIONNEL)>"
        echo "EXEMPLE: ./launch_exporter PROD UK bcc/xml /mnt/nas-e1/exporter/boulanger_\${option.DATE}-rundeck.log"
        echo "AUTRE EXEMPLE: ./launch_exporter PROD UK bcc/xml -Xmx5120m -Xms5120m /mnt/nas-e1/exporter/boulanger_\${option.DATE}-rundeck.log"
        exit 1
}

#Si tout est OK on lance la commande Exporter (voir check des variables vides en bas!)
function launchExporter() {
        # On temporise un peu pour éviter un éventuel gouleau d'etranglement si le HAPROXY fait de la merde..."
        # Un petit RANDOM
        DELAI=$((SLEEPMIN+RANDOM*(1+SLEEPMAX-SLEEPMIN)/32767))
        echo "Starting Exporter execution in $DELAI secondes"
        sleep $DELAI
        # On crée un fichier d'execution pour gerer les alertes mails
        echo "Creating execution file."
        # On retravaille le nom du flux pour nommer le fichier d'execution
        NOMFLUX="$(echo $FLUX | cut -d "/" -f1)_$(echo $FLUX | cut -d "/" -f2)"
        if [ ! -f "/mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC.tmp" ]; then
                echo "3" > /mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC.tmp
        fi
        # LAUNCH
        sudo -u wit-exporter /usr/bin/java $MEMOIRE -jar /opt/workit/exporter/lib/exporter.jar --env  $ENVIRONNEMENT --platform $PLATEFORME --feed $FLUX --enable-caches 2>&1 | tee $LOG
        # On check si la job s'est bien executé pour éviter les codes erreurs douteux
        cat $LOG | grep "Ending feed" > /dev/null 2>&1
        if [ $? -ne 0 ]; then
                echo "Job failed to execute."
                # On décrémente de 1
                RETRY=$(cat "/mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC.tmp")
                RETRY=$(($RETRY-1))
                echo $RETRY > /mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC.tmp
                if [ $RETRY -le 0 ];then
                    rm -f /mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC.tmp
                    echo "FEED $NOMFLUX KO" | mail -s "Flux $NOMFLUX KO" -r "rundeck@workit.fr" exploitation@workit.fr team-cs@workit.fr
                    MAIL=$(mysql -s -h pral-expmys01.workit.fr -uroot -p'W0rk1T!121!' --database=exporter -e "select recipient from exporter.feed_alerting_recipient where client_name='$(echo $FLUX | cut -d/ -f1)' and datafeed_name='$(echo $FLUX | cut -d/ -f2)';")
                    if [ $? -ne 0 ]; then
                        echo "Failed getting email addrss from exporter database";
                        exit 1;
                    fi
                    echo "$MAIL"
                    echo -e "The feed generation process has failed. The alert is currently being processed by our teams. \nYou will receive a new notification when the feed is available again \n\nTeam Workit" | mail -s "Workit - Feed generation Failed $NOMFLUX KO" -r "rundeck@workit.fr" $MAIL
                    touch /mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC_KO.tmp
                    exit 1
                fi
                exit 1
        else
		if [ -f "/mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC_KO.tmp" ]; then
            MAIL=$(mysql -s -h pral-expmys01.workit.fr -uroot -p'W0rk1T!121!' --database=exporter -e "select recipient from exporter.feed_alerting_recipient where client_name='$(echo $FLUX | cut -d/ -f1)' and datafeed_name='$(echo $FLUX | cut -d/ -f2)';")
            echo "$MAIL"
            echo -e "The feed is now available. \n\nTeam Workit" | mail -s "Workit - Feed delivered: $NOMFLUX" -r "rundeck@workit.fr" $MAIL
            rm -f /mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC_KO.tmp
         fi
		echo "Job terminated successfully."
		# On supprime le fichier d'execution car le job s'est executé correctement
		echo "Deleting execution file."
		rm -f /mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC.tmp
		exit 0
        fi
}

echo "Executing on $HOSTNAME"
# Check des arguments, $MEMOIRE est optionnel (check inutile)
if [[ -z $ENVIRONNEMENT ||  -z $PLATEFORME ||  -z $FLUX || -z $LOG ]] ;then
        usage
else
        launchExporter
fi

