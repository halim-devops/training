#!/usr/bin/env bash
PATTERN=$1
echo Killing the following :
echo ps aux | grep -E $PATTERN
kill -9 $(ps aux | grep -E $PATTERN | awk '{print $2}')

