#!/bin/bash
### Script de gestion de lancement des jobs EXPORTER via RUNDECK

EXEC_EXPORTER="/tmp/exec_exporterv2.$$.sh"

# Kubernees prerequisite VPN
if [ ! -d /dev/net ]; then
	mkdir -p /dev/net
	mknod /dev/net/tun c 10 200
	chmod 600 /dev/net/tun
fi

if [ -f /tmp/flag ]; then 
	openvpn /etc/openvpn/client/openvpnovh.ovpn
	sleep 10
	if [ $? -ne 0 ]; then
		echo "ERROR: Failed to mount nfs share"
	fi
	rm -f /tmp/flag
	echo "10.10.1.103 prfr-wv4mys00.workit.fr" >> /etc/hosts
	echo "10.10.0.173 pruk-wv4mys00.workit.fr" >> /etc/hosts
	echo "10.10.1.153 prde-wv4mys00.workit.fr" >> /etc/hosts
	echo "10.10.1.129 prii-wv4mys00.workit.fr" >> /etc/hosts
	echo "10.10.1.131 prit-wv4mys00.workit.fr" >> /etc/hosts
	echo "10.10.0.250 prad-wv4mys00.workit.fr" >> /etc/hosts
	echo "10.10.1.133 prcg-wv4mys01.workit.fr" >> /etc/hosts
	echo "10.10.7.121 gitlab.workit.fr" >> /etc/hosts
fi

curl -o $EXEC_EXPORTER -s http://gitlab.workit.fr/ops-team/ops-tools/raw/master/rundeck_exporter_scripts/exec_exporterv2.sh
chmod +x $EXEC_EXPORTER
$EXEC_EXPORTER $@
rm $EXEC_EXPORTER
