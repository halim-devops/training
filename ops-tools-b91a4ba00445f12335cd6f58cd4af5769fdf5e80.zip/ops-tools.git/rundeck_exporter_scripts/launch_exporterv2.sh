#!/bin/bash
### Script de gestion de lancement des jobs EXPORTER via RUNDECK

EXEC_EXPORTER="/tmp/exec_exporterv2.$$.sh"

curl -o $EXEC_EXPORTER -s http://gitlab.workit.fr/ops-team/ops-tools/raw/master/rundeck_exporter_scripts/exec_exporterv2.sh
chmod +x $EXEC_EXPORTER
$EXEC_EXPORTER $@
ret=$?
rm $EXEC_EXPORTER
exit $ret
