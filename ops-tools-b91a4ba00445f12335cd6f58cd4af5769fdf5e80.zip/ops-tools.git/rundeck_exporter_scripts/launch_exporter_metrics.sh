#!/bin/bash
### Script de gestion de lancement des jobs EXPORTER via RUNDECK

EXEC_EXPORTER="/tmp/exec_exporter_metrics.$$.sh"

curl -o $EXEC_EXPORTER -s http://gitlab.workit.fr/ops-team/ops-tools/raw/master/rundeck_exporter_scripts/exec_exporter_metrics.sh
chmod +x $EXEC_EXPORTER
$EXEC_EXPORTER $@
rm $EXEC_EXPORTER
