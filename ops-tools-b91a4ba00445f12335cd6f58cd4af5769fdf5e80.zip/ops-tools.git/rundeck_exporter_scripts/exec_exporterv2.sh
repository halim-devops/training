#/bin/bash
### Script de gestion de lancement des jobs EXPORTER via RUNDECK Version 2

# Arguments
ENVIRONNEMENT=$1
PLATEFORME=$2
FLUX=$3
DRYRUN=$4
CACHE=$5
MEMOIREMIN=$6
MEMOIREMAX=$7

# Variable
SLEEPMIN=1
SLEEPMAX=15
LOG="/mnt/nas-e1/exporter/$(echo $3| sed -e 's/\//_/g')_$(date +%Y%m%d-%H%M%S)-rundeck.log"

# Au cas ou on sait pas se servir de ce script
function usage() {
        echo "MAUVAISE UTILISATION DU SCRIPT"
        echo "USAGE: ./launch_exporterv2.sh <ENVIRONNEMENT> <PLATEFORME> <FLUX> <DRYRUN> <CACHE> <MEMOIRE (OPTIONNEL)>"
        echo "EXEMPLE: ./launch_exporterv2.sh PROD UK bcc/xml disabledryrun enablecache"
        echo "AUTRE EXEMPLE: ./launch_exporterv2.sh PROD UK bcc/xml enabledryrun disablecache -Xmx5120m -Xms5120m"
        exit 1
}

#Si tout est OK on lance la commande Exporter (voir check des variables vides en bas!)
function launchExporter() {
	# On temporise un peu pour éviter un éventuel gouleau d'etranglement si le HAPROXY fait de la merde..."
        # Un petit RANDOM
        DELAI=$((SLEEPMIN+RANDOM*(1+SLEEPMAX-SLEEPMIN)/32767))
        echo "Starting Exporter execution in $DELAI secondes"
        sleep $DELAI
        # On crée un fichier d'execution pour gerer les alertes mails
        echo "Creating execution file."
        # On retravaille le nom du flux pour nommer le fichier d'execution
        NOMFLUX="$(echo $FLUX | cut -d "/" -f1)_$(echo $FLUX | cut -d "/" -f2)"
        if [ ! -f "/mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC.tmp" ]; then
                echo "3" > /mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC.tmp
        fi
        # LAUNCH
	# On construit notre liste de paramètre CACHE et DRYRUN en fonction des arguments
	if [ $CACHE == "enablecache" ]; then
 		OTHERPARAM="--enable-caches"
		echo "Cache activé"z
	fi
	if [ $DRYRUN == "enabledryrun" ]; then
		OTHERPARAM="$OTHERPARAM --dry-run"
		echo "Mode DRYRUN activé"
	fi

	[ -f /tmp/${NOMFLUX}.status.tmp ] && rm -f /tmp/${NOMFLUX}.status.tmp > /dev/null 2>&1

    CLEANUP="\"/home/rundeck/kill-job.sh 'java.*$PLATEFORME.*$FLUX'\""
    echo $CLEANUP
    echo ssh pral-exp07.workit.fr $CLEANUP
    #CLEANUP="""ps aux | grep -v grep | grep java | grep $PLATEFORME | grep $FLUX """
    #ssh pral-exp07.workit.fr $CLEANUP &&
    #ssh pral-exp08.workit.fr $CLEANUP &&
    #ssh pral-exp09.workit.fr $CLEANUP &&
    #ssh pral-exp10.workit.fr $CLEANUP &&
    #ssh pral-exp11.workit.fr $CLEANUP &&
    #ssh pral-exp12.workit.fr $CLEANUP &&


    #ssh pral-exp07.workit.fr 'echo kill $(ps aux | grep 'env  $ENVIRONNEMENT' | grep 'platform $PLATEFORME' [ grep "feed $FLUX $OTHERPARAM" | awk "{print $2}")"


	echo "Executing: /usr/bin/java $MEMOIREMIN $MEMOIREMAX -jar /opt/workit/exporter/lib/exporter.jar --env  $ENVIRONNEMENT --platform $PLATEFORME --feed $FLUX $OTHERPARAM"
	sudo -u wit-exporter /usr/bin/java $MEMOIREMIN $MEMOIREMAX -jar /opt/workit/exporter/lib/exporter.jar --env  $ENVIRONNEMENT --platform $PLATEFORME --feed $FLUX $OTHERPARAM 2>&1 | tee $LOG
        # On check si la job s'est bien executé pour éviter les codes erreurs douteux
        cat $LOG | grep "Ending feed" > /dev/null 2>&1
	if [ $? -ne 0 ]; then
                echo "Job failed to execute."
                # On décrémente de 1
                RETRY=$(cat "/mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC.tmp")
                RETRY=$(($RETRY-1))
                echo $RETRY > /mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC.tmp
                if [ $RETRY -le 0 ];then
                        rm -f /mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC.tmp
#		 	if [ "$DRYRUN" != "disabledryrun" ]; then
		 	if [ "$DRYRUN" != "enabledryrun" ]; then
				echo "FEED $NOMFLUX KO" | mail -s "Flux $NOMFLUX KO" -r "rundeck@workit.fr" exploitation@workit.fr team-cs@workit.fr
				MAIL=$(mysql -s -h pral-expmys01.workit.fr -uroot -p'W0rk1T!121!' --database=exporter -e "select recipient from exporter.feed_alerting_recipient where client_name='$(echo $FLUX | cut -d/ -f1)' and datafeed_name='$(echo $FLUX | cut -d/ -f2)';")
				echo "$MAIL"
				echo -e "The feed generation process has failed. The alert is currently being processed by our teams. \nYou will receive a new notification when the feed is available again \n\nTeam Workit" | mail -s "Workit - Feed generation Failed $NOMFLUX KO" -r "rundeck@workit.fr" $MAIL
				touch /mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC_KO.tmp
				exit 1
			fi
                fi
                exit 1
        else
		if [ -f "/mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC_KO.tmp" ]; then
			MAIL=$(mysql -s -h pral-expmys01.workit.fr -uroot -p'W0rk1T!121!' --database=exporter -e "select recipient from exporter.feed_alerting_recipient where client_name='$(echo $FLUX | cut -d/ -f1)' and datafeed_name='$(echo $FLUX | cut -d/ -f2)';")
                        echo "$MAIL"
			echo -e "The feed is now available. \n\nTeam Workit" | mail -s "Workit - Feed delivered: $NOMFLUX" -r "rundeck@workit.fr" $MAIL
			rm -f /mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC_KO.tmp
		fi
		echo "Job terminated successfully."
		# On supprime le fichier d'execution car le job s'est executé correctement
		echo "Deleting execution file."
		rm -f /mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC.tmp
		touch /tmp/${NOMFLUX}.status.tmp
                exit 0
        fi
}

echo "Executing on $HOSTNAME"
# Check des arguments, $MEMOIRE est optionnel (check inutile)
if [[ -z $ENVIRONNEMENT ||  -z $PLATEFORME ||  -z $FLUX || -z $DRYRUN || -z $CACHE ]] ;then
	usage
else
	#On respecte la casse
        ENVIRONNEMENT=`echo $ENVIRONNEMENT | tr '[a-z]' '[A-Z]'`
        if [ $ENVIRONNEMENT != "PROD" ]; then
		echo "Wrong environment"
		echo "List of available environment: PROD"
		exit 1
	fi

	PLATEFORME=`echo $PLATEFORME | tr '[a-z]' '[A-Z]'`
	if [ $PLATEFORME != "FR" ] && [ $PLATEFORME != "DE" ] && [  $PLATEFORME != "UK" ] && [  $PLATEFORME != "IT" ] && [ $PLATEFORME != "II" ]  && [  $PLATEFORME != "ADHOC" ] && [  $PLATEFORME != "CG" ] ; then
		echo "Wrong platform"
		echo "List of available platform: FR, DE, UK, IT, II, ADHOC" 
		exit 1
	fi

#       FLUX=`echo $FLUX | tr '[A-Z]' '[a-z]'`
        DRYRUN=`echo $DRYRUN | tr '[A-Z]' '[a-z]'`
        if [ $DRYRUN != "disabledryrun" ] && [ $DRYRUN != "enabledryrun" ]; then
		echo "Incorrect dryrun parameter"
		echo "List of available dryrun parameter: disabledryrun, enabledryrun"
		exit 1
	fi

	CACHE=`echo $CACHE | tr '[A-Z]' '[a-z]'`
	if [ $CACHE != "disablecache" ] && [ $CACHE != "enablecache" ]; then
		echo "Incorrect cache parameter"
		echo "List of available cache parameter: enablecache, disablecache"
		exit 1
	fi

	launchExporter

fi
