<?php
$json = file_get_contents('/var/www/html/web-status/web-status.json');
echo $json;
?>
