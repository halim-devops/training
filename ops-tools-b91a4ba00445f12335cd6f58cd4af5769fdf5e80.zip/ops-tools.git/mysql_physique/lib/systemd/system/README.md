# This is a template file
# copy it for the plateform
# for example FR:
# cp mysql-XX.service mysql-fr.service
#
# Edit the file mysql-fr.service
# change the XX to the plateform value (like fr)
#
# to enable the service, for example FR:
# systemctl enable mysql-fr.service
