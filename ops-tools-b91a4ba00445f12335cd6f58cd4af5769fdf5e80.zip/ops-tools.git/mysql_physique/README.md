# Install zabbix
apt-get install libcurl3 php-common php7.0-cli php7.0-common php7.0-json php7.0-mysql php7.0-opcache php7.0-readline
wget http://repo.zabbix.com/zabbix/3.2/debian/pool/main/z/zabbix/zabbix-agent_3.2.3-1+jessie_amd64.deb
dpkg -i zabbix-agent_3.2.3-1+jessie_amd64.deb


# /etc/zabbix/zabbix_agend.conf
------------------------------------------------------------
PidFile=/var/run/zabbix/zabbix_agentd.pid
LogFile=/var/log/zabbix/zabbix_agentd.log
LogFileSize=0
Server=zabbix4-svc-prod.wit, pral-zabsrv01.workit.fr, pral-zabbixproxy01.workit.fr, pral-frtzab-metrics.workit.fr
Include=/etc/zabbix/zabbix_agentd.conf.d/
UnsafeUserParameters=1
------------------------------------------------------------

# Install percona
apt-get install percona-server-server-5.6 percona-server-common-5.6 percona-zabbix-templates percona-server-client-5.6 percona-xtrabackup

# For one thread backup install facter: 
apt-get install facter

# Change all XX to the plateform 
# XX to fr ...

