# The file mysql.sh must be copied in /sbin/
# To create a instance you need to create a symbolic link on it:
# ln -s /sbin/mysql.sh /sbin/mysql-XX
