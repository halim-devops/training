# you need to modify /etc/fstab in order to be able to use the backup
# install 
apt-get -y install nfs-kernel-server
# copy the exports file 
cat exports >> /etc/exports
