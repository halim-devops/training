# copy this script and modify mys_backup to /etc/cron.d to generate backup
