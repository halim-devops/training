#!/bin/bash

if [[ $EUID -ne 0 ]]; then
        echo "You must be root or sudoers"
        exit 1;
fi

echo "Updating mysql services"
pkill mysql
mkdir -p /var/lib/mysql/default
mv /var/lib/mysql/* /var/lib/mysql/default/
systemctl disable mysql.service

echo "Updating mysql files"
mkdir -p /etc/mysql/default
mv /etc/mysql/* /etc/mysql/default/

echo "Adding mysql script startup"
curl -o /sbin/mysql.sh -s http://gitlab.workit.fr/ops-team/ops-tools/raw/master/mysql_physique/sbin/mysql.sh
chmod +x /sbin/mysql.sh
curl -o /etc/mysql/debian-start -s http://gitlab.workit.fr/ops-team/ops-tools/raw/master/mysql_physique/etc/mysql/debian-start
chmod +x /etc/mysql/debian-start

echo "Updating system FSTAB (adding backup folder)"
FSTAB_UPDATE=$(grep "zpool-124461" /etc/fstab|grep -v "#"|wc -l)
if [ "x$FSTAB_UPDATE" == "x0" ]; then
	echo "Updating fstab"
	curl -o /tmp/addFstab -s http://gitlab.workit.fr/ops-team/ops-tools/raw/master/mysql_physique/etc/fstab
	cat /tmp/addFstab >> /etc/fstab
fi


echo "Force install nfs-kernel-server to export folder"
apt-get -y -f install nfs-kernel-server
echo "Updating export FS (we expose /var/lib/mysql/backup to be able to grab a fresh backup from another server)"
EXPORT_UPDATE=$(grep "backup" /etc/exports|grep -v "#"|wc -l)
if [ "x$EXPORT_UPDATE" == "x0" ]; then
        curl -o /tmp/addExports -s http://gitlab.workit.fr/ops-team/ops-tools/raw/master/mysql_physique/etc/exports
        cat /tmp/addExports >> /etc/exports
	mkdir -p /var/lib/mysql/backup/
fi
echo "Reloading export"
service nfs-kernel-server reload
