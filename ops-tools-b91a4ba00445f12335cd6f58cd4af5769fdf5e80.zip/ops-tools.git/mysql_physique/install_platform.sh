#!/bin/bash

if [[ $EUID -ne 0 ]]; then
        echo "You must be root or sudoers"
        exit 1;
fi

function usage {
        echo "sudo $0 <fr/uk/ii/cg/it/de> <bind ip for mysql>"
        exit 1
}

if [[ $EUID -ne 0 ]]; then
        echo "You must be root or sudoers"
        exit 1;
fi


if [ -z "$1" ]; then
        echo "Plateform is mandatory";
        usage;
fi

if [ -z "$2" ]; then
        echo "External ip for mysql is mandatory for binding";
        usage;
fi;

PLATFORM="$1"
BIND_IP="$2"

echo " ** platform : $PLATFORM"
echo " ** bind address : $BIND_IP"

echo ""

echo "Creating mysql folder"
mkdir -p /etc/mysql/$PLATFORM/conf.d

echo "Downloading configuration for $PLATFORM"
curl -o /tmp/my.$PLATFORM.cnf -s http://gitlab.workit.fr/ops-team/ops-tools/raw/master/mysql_conf/$PLATFORM/my.cnf

sed -i "s|bind-add.*|bind-address = $BIND_IP|" /tmp/my.$PLATFORM.cnf
echo "Copy configuration file"
mv /tmp/my.$PLATFORM.cnf /etc/mysql/$PLATFORM/my.cnf

for file in "debian.cnf" "conf.d/mysql.cnf" "conf.d/mysqldump.cnf"; do
	echo $file
	curl -o /etc/mysql/$PLATFORM/$file -s http://gitlab.workit.fr/ops-team/ops-tools/raw/master/mysql_physique/etc/mysql/XX/$file
done;

sed -i "s|xxx.yyy.zzz.ttt|$BIND_IP|g" /etc/mysql/$PLATFORM/debian.cnf
sed -i "s|XX|$PLATFORM|g" /etc/mysql/$PLATFORM/debian.cnf
echo ""
echo "***** Execute this command with the root password of mysql"
echo "sudo sed -i \"s|password.*|password = <PASSWORD ROOT MYSQL>|g\" /etc/mysql/$PLATFORM/debian.cnf"
echo "***** Execute this command with the root password of mysql"
echo ""

echo "updating rights"
chown -R mysql:mysql /etc/mysql

ln -s /sbin/mysql.sh /sbin/mysql-$PLATFORM

echo "Installing service mysql $PLAFTFORM"
curl -o /tmp/mysql-$PLATFORM.service -s http://gitlab.workit.fr/ops-team/ops-tools/raw/master/mysql_physique/lib/systemd/system/mysql-XX.service
sed -i "s|XX|$PLATFORM|g" /tmp/mysql-$PLATFORM.service
mv /tmp/mysql-$PLATFORM.service /lib/systemd/system/
systemctl enable mysql-$PLATFORM.service

