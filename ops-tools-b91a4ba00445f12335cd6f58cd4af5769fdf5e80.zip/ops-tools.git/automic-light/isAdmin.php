<?php
$user=$_GET['user'];
$admins = array("jdboisse", "imoussa","fchan", "wkersalez", "vdahmane");
if (in_array($user, $admins)) {
    echo "true";
} else {
	echo "false";
}
?>
