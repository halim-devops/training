<?php
$job=str_replace("_", "*",strtolower(str_replace("GENER_FLUX_","",$_GET['job_name'])));
$job.="*";
$command="ls -1t /mnt/exporter/$job|head -1|xargs -I % tail -n 60 %";
//echo shell_exec ($command);
$nb_file=shell_exec("ls -1t /mnt/exporter/$job|head -1|wc -l");
if($nb_file==1)
{
	echo shell_exec ($command);
}
else{
	echo "No log file";
}

?>
