#!/bin/bash

############################
######## Libraries #########
############################

SHFLAGS_LIB_PATH=/usr/lib/workit/bash-libraries/shflags
BSFL_LIB_PATH=/usr/lib/workit/bash-libraries/bsfl
CBL_LIB_PATH=/usr/lib/workit/bash-libraries/cbl

source ${CBL_LIB_PATH}
if [[ $? -ne 0 ]]; then
  echo "Unable to source cbl library: ${CBL_LIB_PATH}"
  exit ${_EXEC_FAILURE}
fi

source ${BSFL_LIB_PATH}
if [[ $? -ne 0 ]]; then
  echo "Unable to source bsfl library: ${BSFL_LIB_PATH}"
  exit ${_EXEC_FAILURE}
fi

source ${SHFLAGS_LIB_PATH}
if [[ $? -ne 0 ]]; then
  echo "Unable to source shFlags library: ${SHFLAGS_LIB_PATH}"
  exit ${_EXEC_FAILURE}
fi

############################
########### BSFL ###########
############################

# LOG_ENABLED: Enable/disable the logging via BSFL.
LOG_ENABLED=y

############################
######## Variables #########
############################

mongohost="localhost"
host="crawlplatform"
port="27017"
collection="sites jobs warning_setup remote_services directives http_proxies warning statistics exec_runtime_stats executions report_links"
db="crawl"
repository="/net/backup/MONGODB/CRAWL-PLATFORM/"
user="backup-user"
password="b4cKup3r"
backup_date="$(date +%Y%m%d)"
archive_name="mongodb_backup_${host}_collections_${backup_date}.tar.gz"
backup_path="${repository}/${backup_date}"

############################
########## Backup ##########
############################

for collection in $collection
do
    echo $collection
    temporary_folder="${repository}/tmp"
    mkdir -p ${temporary_folder}/${host}
    mongodump --host $mongohost --port $port --collection $collection --db $db --username $user --password $password --out ${temporary_folder}/${host}
    if [[ $? -ne 0 ]]
    then
      echo "backup_collections failed."
      exit 1
    fi
done || exit 1

###############################
# Archive and compress backup #
###############################

mkdir -p ${backup_path}
tar czf ${backup_path}/${archive_name} -C ${temporary_folder} ${host}
  if [[ $? -ne 0 ]]
  then
    echo "archive_backup failed."
    exit 1
  fi

###############################
### Clean temporary folder ####
###############################

rm -rf ${temporary_folder}/${host}

