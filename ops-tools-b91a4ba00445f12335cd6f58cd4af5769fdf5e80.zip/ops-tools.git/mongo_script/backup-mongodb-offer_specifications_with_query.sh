#!/bin/bash

############################
######## Libraries #########
############################
echo "MONGO DUMP CRAWL PLATFORM WITH QUERY"

SHFLAGS_LIB_PATH=/usr/lib/workit/bash-libraries/shflags
BSFL_LIB_PATH=/usr/lib/workit/bash-libraries/bsfl
CBL_LIB_PATH=/usr/lib/workit/bash-libraries/cbl

source ${CBL_LIB_PATH}
if [[ $? -ne 0 ]]; then
  echo "Unable to source cbl library: ${CBL_LIB_PATH}"
  exit ${_EXEC_FAILURE}
fi

source ${BSFL_LIB_PATH}
if [[ $? -ne 0 ]]; then
  echo "Unable to source bsfl library: ${BSFL_LIB_PATH}"
  exit ${_EXEC_FAILURE}
fi

source ${SHFLAGS_LIB_PATH}
if [[ $? -ne 0 ]]; then
  echo "Unable to source shFlags library: ${SHFLAGS_LIB_PATH}"
  exit ${_EXEC_FAILURE}
fi

############################
########### BSFL ###########
############################

# LOG_ENABLED: Enable/disable the logging via BSFL.
LOG_ENABLED=y

############################
######## Variables #########
############################

mongohost="localhost"
host="datasci_with_query"
port="27017"
collection="offer_specifications"
db="crawl"
repository="/mnt/nas-e1/files"
user="backup-user"
password="b4cKup3r"
backup_date="$(date +%Y%m%d)"
archive_name="Dump_collection_offer_specifications_with_query_${backup_date}.tar.gz"
backup_path="${repository}"

############################
########## Backup ##########
############################

for collection in $collection
do
    echo $collection
    temporary_folder="/mnt/nas-e1/files/tmp"
    mkdir -p ${temporary_folder}/${host}
    mongoexport --host $mongohost --port $port --collection $collection --db $db --username $user --password $password --out ${temporary_folder}/${host}/Dump_collection_offer_specifications_with_query_${backup_date}.json --query "{\"siid\" : { \$in: [ '57c03342e4b0222f070e08cf','57c13ecae4b0222f070e08d2', '57b6c7dce4b0222f070e08a0','585a8a28e4b097b05919c6bc', '57a1e96ce4b088fd085b8838','57b46064e4b0222f070e089d', '57bc3571e4b0222f070e08b3','562f817ae4b04476b51b4b9f', '56331c39e4b04476b51b4ba6','57f4d159e4b04ce35fd5f5d3','56a8fbdde4b095af1ec69a92','562a2dc2e4b04476b51b4b96','57ba9138e4b0222f070e08a5' ] }}"

    if [[ $? -ne 0 ]]
    then
      echo "backup_collections failed."
      exit 1
    fi
done || exit 1

###############################
# Archive and compress backup #
###############################

mkdir -p ${backup_path}
tar czf ${backup_path}/${archive_name} -C ${temporary_folder} ${host}
  if [[ $? -ne 0 ]]
  then
    echo "archive_backup failed."
    exit 1
  fi

###############################
### Clean temporary folder ####
###############################

rm -rf ${temporary_folder}/${host}

