<?php
$action=$_GET['action'];
$data1=$_GET['data1'];
echo shell_exec("/var/www/html/listZones.sh $action $data1");
?>
