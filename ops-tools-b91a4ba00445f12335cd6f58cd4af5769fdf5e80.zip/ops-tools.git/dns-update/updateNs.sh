#!/bin/bash
NSUPDATE=/usr/bin/nsupdate
NSLOOKUP=/usr/bin/nslookup
DNS="10.10.7.49"
KEY="/var/www/html/rndc.key"
ACTION=$1
DATA1=$2
TYPE=$3
DATA2=$4
if [ -f "$5" ]; then
	KEY="$5"
fi

ZONE=`/bin/echo $DATA1|/bin/sed 's|.*\.\(.*\)\.\([a-z]*\)|\1.\2.|g'`
DATE=`date +%Y%m%d%H%M%S`
TMP_FILE="/tmp/$DATE.tmp"
rm -f $TMP_FILE
echo "Creating update file to send to $DNS using file $TMP_FILE"
echo "server $DNS" >> $TMP_FILE
echo "debug yes" >> $TMP_FILE
echo "zone $ZONE" >> $TMP_FILE
if [ $ACTION == "ADD" ]; then
	if [ $TYPE == "A" ]; then
		reverse=$(echo $DATA2|sed 's|\([0-9]*\)\.\([0-9]*\)\.\([0-9]*\)\.\([0-9]*\)|\4.\3.\2.\1|g')
		zone=$(echo $DATA2|sed 's|\([0-9]*\)\.\([0-9]*\)\.\([0-9]*\)\.\([0-9]*\)|\2.\1|g')
		echo "********************** $reverse"
		echo "update add $DATA1 3600 $TYPE $DATA2" >> $TMP_FILE
		echo "send" >> $TMP_FILE
		echo "zone ${zone}.in-addr.arpa" >> $TMP_FILE
		echo "update add ${reverse}.in-addr.arpa 3600 PTR $DATA1" >> $TMP_FILE
	else
		echo "update add $DATA1 3600 $TYPE $DATA2." >> $TMP_FILE
	fi
else
	echo "update delete $DATA1 $TYPE" >> $TMP_FILE
fi
echo "show" >> $TMP_FILE
echo "send" >> $TMP_FILE
echo ""
echo "#### TMP_FILE OUTPUT ################################################"
cat "$TMP_FILE"
echo "#####################################################################"
echo ""
echo "#### CALL BIND SERVER ###############################################"
$NSUPDATE -k $KEY -v $TMP_FILE
echo "#####################################################################"
echo ""
echo "#### CALL NSLOOKUP ##################################################"
$NSLOOKUP $DATA1 $DNS
echo "#####################################################################"
rm $TMP_FILE
