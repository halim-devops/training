Fichier a placer dans le répertoire /var/www/html 

Il se base sur le ServerName de fichier de conf d'apache afin de lister automatiquement les liens dispo pour une conf donnée.
