<?php
$action=$_GET['action'];
$data1=$_GET['data1'];
$type=$_GET['type'];
$data2=$_GET['data2'];
echo shell_exec("/var/www/html/updateNs.sh $action $data1 $type $data2");
?>
