#!/bin/bash
DNS="10.10.7.49"
ACTION=$1
DATA1=$2
ZONE=`/bin/echo $DATA1|/bin/sed 's|.*\.\(.*\)\.\([a-z]*\)|\1.\2.|g'`
DATE=`date +%Y%m%d%H%M%S`
BASEDIR="/etc/bind/zones"
echo "List Zone from $DNS"
if [ $ACTION == "LIST" ]; then
	echo "<br/>"
	echo "<div><a href='javascript: clearFilter(true);'><button type='button' class='btn' id='clearfilter'>Clear filter</button></a></div>"
	echo "<table id='listTable'>"
	echo "<thead><tr><th><input type='text' id='inputDOM' onkeyup='searchBox(\"DOM\",0)' placeholder='Search domains' title='Search'></th><th><input type='text' id='inputTYP' onkeyup='searchBox(\"TYP\",1)' placeholder='Search type' title='Search'></th><th><input type='text' id='inputIP' onkeyup='searchBox(\"IP\",2)' placeholder='Search IP' title='Search'></th></tr></thead>"
	sudo cat /etc/bind/zones/db.${ZONE} | sed 's/\t\+/\t/g' | awk '/CNAME|A/ { split($0, ip, / |\t/); printf("<tr><td>%s</td><td>%s</td><td>%s</td></tr>\n", ip[1], ip[2]i, ip[3]); }'
	echo "</table>"

else
	echo "Unknown Action."
fi
