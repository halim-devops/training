#!/bin/bash
nmap -sP 10.10.0.0/20 | egrep -o "([0-9]{1,3}\.){3}[0-9]{1,3}" > /tmp/ip.list
for ip in $(cat /tmp/ip.list); do
	dns=$(nslookup $ip 10.10.7.11 2>&1|grep name|cut -d"=" -f2|sed 's| \(.*\)\.|\1|g')
	for d in $dns; do
#		echo "Domaine \"$d\" for ip  \"$ip\" from 10.10.7.11"
		dns2=$(nslookup $ip 10.10.7.49 2>&1|grep name|cut -d"=" -f2|sed 's| \(.*\)\.|\1|g'|sort -u)
		if [ ${#dns2} -eq 0 ]; then
			echo "$d/$ip:  DNS not in 10.10.7.49"
			echo " Updating 10.10.7.49..."
			./updateNs.sh "ADD" "$d" "A" "$ip" ./rndc.key
			echo "update done"

		else
			# contains?
			contains=0
			for d2 in $dns2; do
				if [ "$d" = "$d2" ] ; then
					contains=1
					continue
				fi
			done;


			if [ ! $contains ]; then
				echo "$d/$ip:  DNS not match - domaine \"$dns2\" for ip  \"$ip\" from 10.10.7.49"
#			else
#				echo "  DNS match \"$dns2\""
			fi
		fi
#		echo " *** "
	done
done;
