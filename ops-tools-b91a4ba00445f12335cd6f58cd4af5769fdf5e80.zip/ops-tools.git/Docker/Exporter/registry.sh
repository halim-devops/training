#!/bin/bash
export DOCKER_REGISTRY_SERVER=https://index.docker.io/v1/
export DOCKER_USER=workitsoftware
export DOCKER_EMAIL=exploitation@workitsoftware.com
export DOCKER_PASSWORD=FY3781sp8CCRwWJbvDeP

kubectl create secret docker-registry myregistrykey \
  --docker-server=$DOCKER_REGISTRY_SERVER \
  --docker-username=$DOCKER_USER \
  --docker-password=$DOCKER_PASSWORD \
--docker-email=$DOCKER_EMAIL


