#!/bin/sh
### BEGIN INIT INFO
# Provides:          workit-slow-query-killer.sh
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start and stop the workit-slow-query-killer.sh (Percona Server) daemon
# Description:       Kill slow query
#
### END INIT INFO

# Source function library.

PID="/var/run/workit-slow-query-killer.pid"
MAX_DURATION=1800
INTERVAL_CHECK=600
WAIT_RECHECK=1200
USER="root"
PASS='W0rk1T!121!'
LOG="/var/log/mysql-kill.log"
MAIL="exploitation@workit-software.com"
SOCKET_FILE=$2
if [ -z "SOCKET_FILE" ]
then
      SOCKET_FILE="/var/run/mysqld/mysqld.sock"
fi



RETVAL=0


# See how we were called.
case "$1" in
  start)
    echo -n "Starting workit-slow-query-killer: "

    workit-slow-query-killer.sh \
      --pid ${PID} \
      --daemonize \
      --interval ${INTERVAL_CHECK} \
      --busy-time ${MAX_DURATION} \
      --wait-after-kill ${WAIT_RECHECK}  \
      --log ${LOG} \
      --print \
      --kill-query \
      --ignore-user opsadmin \
      --user ${USER} \
      --password ${PASS} \
      --socket ${SOCKET_FILE} \
      --execute-command "(echo \"Subject: workit-slow-query-killer query found on `hostname`\"; tail -1 /var/log/mysql-kill.log)|/usr/sbin/sendmail -t ${MAIL}"

    RETVAL=$?
    echo
    [ $RETVAL -ne 0 ] && exit $RETVAL

  ;;
  stop)
        # Stop daemons.
        echo -n "Shutting down workit-slow-query-killer: "
        kill -9 `cat $PID`
	rm $PID
        echo
    ;;
  restart)
    $0 stop
        $0 start
        ;;
  *)
        echo "Usage: workit-slow-query-killer.sh {start|stop}"
        RETVAL=3
        ;;
esac

exit $RETVAL
