#!/bin/bash
USER="zabbix"
PASS="zabbix"
URL="http://10.10.7.96:8081/automic-rest/api/awa"

# Call URL
LOGIN_PARAM="login/v1/auth?login=$USER&pwd=$PASS&connection=WORKIT&client=1"
LOGOUT_PARAM="logout/v1/auth"
JOBS_PARAM="export/v1/All?name=EXPTR*"
STATS_PARAM="search/v1/Statistics"

function callRest {
	echo `curl -s "$URL/$1"`
}

function getToken {
	echo `callRest "$LOGIN_PARAM"|jq '.token'|sed 's/"//g'`
}

function logout {
	callRest "$LOGOUT_PARAM?token=$1"|jq '.status'|sed 's/"//g'
}

function getLastStatus {
	callRest "$JOBS_PARAM&token=$1"|jq '.data[]|.name'|sed 's/"//g'
}

function getStats {
#	echo "$URL/$STATS_PARAM?filters=[name:$1,start=LAST7Days]&token=$2"
	callRest "$STATS_PARAM?filters=\[name:$1,start:LAST7Days\]&token=$2"
}

# get the token for quering automic
TOKEN=`getToken`
#echo $TOKEN
# get the last status of $1
VALUE=`getLastStatus $TOKEN`
for i in $VALUE;
do
	DATA=`getStats $i $TOKEN`
	echo $DATA|jq '.data|map([.name, .starttime, .runtime, .status] |join(";"))|join("\n")'|sed 's/"//g'|sed 's/\\n/\n/g'|grep -v "unknown"|sed 's/state_abended/ERROR/g'|sed 's/state_ended/OK/g'
done;
#STATUS=`getLastStatus $TOKEN`
#echo $STATUS
# Login out from rest server
#EXIT_STATE=`logout $TOKEN`
echo $EXIT_STATE
if [ "$EXIT_STATE" != "success" ]; then
	exit 1
fi
exit 0
