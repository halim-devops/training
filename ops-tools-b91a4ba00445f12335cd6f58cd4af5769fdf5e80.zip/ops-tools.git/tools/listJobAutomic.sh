#!/bin/bash
USER="zabbix"
PASS="zabbix"
URL="http://10.10.7.96:8081/automic-rest/api/awa"

# Call URL
LOGIN_PARAM="login/v1/auth?login=$USER&pwd=$PASS&connection=WORKIT&client=1"
LOGOUT_PARAM="logout/v1/auth"
#JOBS_PARAM="search/v1/Statistics?filters=\[name:$1,activation:LAST24HOURS\]"
#JOBS_PARAM="search/v1/Activities?filters=\[type:JOBS|JOBP\]"
JOBS_PARAM="export/v1/All?name=EXPTR*"
#filters=\[type:JOBS|JOBP\]"

function callRest {
	echo `curl -s "$URL/$1"`
}

function getToken {
	echo `callRest "$LOGIN_PARAM"|jq '.token'|sed 's/"//g'`
}

function logout {
	callRest "$LOGOUT_PARAM?token=$1"|jq '.status'|sed 's/"//g'
}

function getLastStatus {
#	echo `callRest "$JOBS_PARAM&token=$1"|jq '[.data[] ]|sort_by(.starttime)|reverse|.[0]'|sed 's/"//g'`
	callRest "$JOBS_PARAM&token=$1"|jq '.data[]|.name'|sed 's/"//g'
}

# get the token for quering automic
TOKEN=`getToken`
#echo $TOKEN
# get the last status of $1
VALUE=`getLastStatus $TOKEN`
for i in $VALUE;
do
	echo "$i"
done;
#STATUS=`getLastStatus $TOKEN`
#echo $STATUS
# Login out from rest server
EXIT_STATE=`logout $TOKEN`
#echo $EXIT_STATE
if [ "$EXIT_STATE" != "success" ]; then
	exit 1
fi
exit 0
