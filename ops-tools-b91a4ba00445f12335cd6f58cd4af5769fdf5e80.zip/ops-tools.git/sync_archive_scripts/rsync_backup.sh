#!/bin/bash

DESTDIR=""
INCLUDEPARAMFIND=""

if [ ! -z "$1" ]; then
	DESTDIR="$1"
	if [[ "$1" == */ ]]; then
		echo "DESTINATION DIR MUST NOT HAVE \"/\" AT THE END"
		exit 1
	fi
	echo "Path to search : \"${DESTDIR}\""
fi

for i in {2..10}; do
	if [ ! -z "${!i}" ]; then
		INCLUDEPARAMFIND="${INCLUDEPARAMFIND} ${!i}"
	fi
done;

if [ ! -z "${INCLUDEPARAMFIND}" ]; then
	echo "Adding parameter to find: \"${INCLUDEPARAMFIND}\""
fi
if [[ "x$DESTDIR" == "x" ]]; then
	echo "Usage : $0 <folder to sync> [<optional param for find>]"
	exit 1
fi


REMOTE="pral-synbck-ext.workit.fr"
#REMOTE="5.196.105.106"
PORT="7202"

SRCDIR="${DESTDIR}/"
TMPDIR="/tmp/tosync"
TMPFILE="$TMPDIR/filelist.$$"


USER="root"
PASS="8vhfUynv85@"

echo "creating temp directory $TMPDIR"
#Create the temp director for the file list
mkdir -p $TMPDIR

echo "searching for files to sync"
#only find log files that are 14 days old or newer, then dump them to a temp file that is only the file name delimited with newlines
sshpass -p $PASS ssh -o StrictHostKeyChecking=no ${USER}@$REMOTE -p $PORT "find $SRCDIR -regex '.*gz' ${INCLUDEPARAMFIND} -not -regex '.*zfs.*' -type f -mmin +720 |sed 's|${SRCDIR}||g'" > $TMPFILE

if [ $? -ne 0 ]; then
	echo "Impossible de récupérer la liste a synchroniser depuis OVH"
	exit 1
fi

echo "######################################"
echo "list to sync"
cat $TMPFILE
echo "######################################"

echo "syncing files, this may take a while"
#rsync the two directories, but only include files from the tempfile list.  delete all other files in the destination directory
sshpass -p $PASS rsync --files-from=$TMPFILE -e "ssh -p $PORT" -avr --delete --delete-missing-args ${USER}@$REMOTE:$SRCDIR $DESTDIR

if [ $? -ne 0 ]; then
        echo "Impossible de synchroniser le zpool avec le NAS"
        exit 1
fi

echo "######################################"
echo "list to remove localy"
echo ""
find $SRCDIR -regextype posix-extended -regex '.*gz' $(printf "! -name %s " $(cat $TMPFILE|xargs -I % basename %)) -ls -delete
echo "######################################"

NB_L=$(cat $TMPFILE|wc -l)

if [ $NB_L -eq 0 ]; then
	echo "La liste récupérer est vide, il doit y avoir un problème je bloque la suppression locale"
	exit 1
fi

echo "Cleaning empty folder"
find $SRCDIR -type d -empty -delete

echo "removing temp directory"
#remove our temporary processing directory
rm -rf $TMPFILE
