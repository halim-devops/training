var request = require("request");

var EventEmitter = require("events").EventEmitter;
var _get_job_list = new EventEmitter();

var _token = "yJHjyHmo0M4oe8sczSLRrG7bNCdv9GSd";
var _url = "pral-rdk01.workit.fr";
var _port = 4440;
var _req_option_token="?authtoken="+_token;

var _get_job_url="/api/17/project/Exporter/jobs";
vr
request({
  uri: "http://"+_url+":"+_port+_get_job_url+"?authtoken="+_token,
  method: "GET",
  timeout: 10000,
  followRedirect: true,
  maxRedirects: 10,
  json: true
}, function(error, response, data) {
    _get_job_list.data = data;
    _get_job_list.emit('update');
});

_get_job_list.on('update', function () {
	var dataArray = _get_job_list.data;
	for (var i = 0, len = dataArray.length; i < len; i++) {
		console.log(dataArray[i].id);
	}
});
