#!/bin/bash
URL="http://pral-rdk01.workit.fr:4440"
TOKEN="yJHjyHmo0M4oe8sczSLRrG7bNCdv9GSd"

#echo $1
#curl -s -H "Accept: application/json" -X GET "$URL/api/17/project/Exporter/jobs?authtoken=$TOKEN"
curl -s  -X GET "$URL/api/17/job/${1}?authtoken=$TOKEN&format=yaml"
