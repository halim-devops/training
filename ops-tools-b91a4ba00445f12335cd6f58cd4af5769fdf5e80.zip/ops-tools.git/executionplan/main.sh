#!/bin/bash
URL="http://pral-rdk01.workit.fr:4440"
TOKEN="yJHjyHmo0M4oe8sczSLRrG7bNCdv9GSd"

ids=$(curl -s -H "Accept: application/json" -X GET "$URL/api/17/project/Exporter/jobs?authtoken=$TOKEN" |jq '.| .[] .id' | sed -e 's/"//g')
tomorrow=$(date --date="next day" '+%Y-%m-%d')
allline=""
for id in $ids
do
	jobinfo=$(curl -s -H "Accept: application/json" -X GET "$URL/api/20/job/$id/info?authtoken=$TOKEN" | jq '. | "\(.name) \(.nextScheduledExecution) \(.averageDuration)"' | sed -e 's/"//g')
	jobname=$(echo $jobinfo |cut -d' ' -f1)

	jobsched=$(echo $jobinfo |cut -d' ' -f2)
	if [ "$jobsched" != "null" ]; then
		jobsched_date=$(echo $jobsched | sed -e 's/\(....-..-..\).*/\1/')
		jobsched_starttime=$(echo $jobsched | sed -e 's/[^T]*T\([^Z]*\)Z/\1/')
		jobsched_starttime=$(date -d "$jobsched_starttime today + 60 minutes" +'%H:%M:%S')	

		jobduration=$(echo $jobinfo |cut -d' ' -f3)
		if [ "$jobduration" != "null" ]; then
			jobduration_sec=$(echo "scale=2; $jobduration / 1000" | bc)

			jobsched_endtime=$(date -d "$jobsched_starttime today + $jobduration_sec seconds" +'%H:%M:%S')
			if [ "$allline" == "" ]; then
				allline="${allline} { \"start\": \"${jobsched_starttime}\", \"end\": \"$jobsched_endtime\", \"id\":\"${jobname}\", \"name\":\"${jobname}\"}"
			else
                                allline="${allline},{ \"start\": \"${jobsched_starttime}\", \"end\": \"$jobsched_endtime\", \"id\":\"${jobname}\", \"name\":\"${jobname}\"}"

			fi
		fi
	fi
done
echo "[$allline]"
