#!/bin/bash
URL="http://pral-rdk01.workit.fr:4440"
TOKEN="yJHjyHmo0M4oe8sczSLRrG7bNCdv9GSd"

curl -s -H "Accept: application/json" -X GET "$URL/api/20/job/d1998dca-f32e-4c22-aff8-2736859fdeb7/info?authtoken=$TOKEN"
