#!/bin/bash
URL="http://pral-rdk01.workit.fr:4440"
TOKEN="yJHjyHmo0M4oe8sczSLRrG7bNCdv9GSd"

curl -s -H "Accept: application/json" -X GET "$URL/api/17/project/Exporter/jobs?authtoken=$TOKEN"
