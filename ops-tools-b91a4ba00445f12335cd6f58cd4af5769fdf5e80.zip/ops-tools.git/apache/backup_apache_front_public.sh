#!/usr/bin/env bash

timestamp=$(date +"%Y%m%d%H%M")
echo $timestamp
tar -cvzf /net/backup/APACHE/sites-and-config-$timestamp.tar.gz /etc/apache2/sites-available /etc/apache2/conf-available
tar -cvzf /net/backup/APACHE/websites-$timestamp.tar.gz /var/www
find /net/backup/APACHE -name 'sites-and-config*' -type f -mtime +90 -delete
find /net/backup/APACHE -name 'websites*' -type f -mtime +30 -delete