#!/usr/bin/env bash


timestamp=$(date +"%Y%m%d%H%M")
echo Restart $timestamp begun >> /var/log/apache2/restart_log
sudo service apache2 restart
echo Restart $timestamp complete >> /var/log/apache2/restart_log
