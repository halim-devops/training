#!/bin/bash

source /usr/bin/zabbix/isFeedInProgress.conf

WITPASS='W@rk1T!!!'

function evalvar {
        NAME="$1_$2"
        echo "${!NAME}"
}

FEED="$1"
if [ ${#FEED} -eq 0 ];
then
        echo "No feed set."
        exit 1
fi

for server in $EXPORTERS;
do
        RESPONSE=`curl -s "http://$server/checkProcessExporter.php?process=java%20|grep%20-v%20grep|grep%20-v%20sudo"`
        RESP=`echo [$RESPONSE null]|jq -c ".[] |select(.cmd|contains(\"$FEED\"))|.cmd" 2> /dev/null |sed 's|"||g' | grep -Po -- '--feed [^\s]+'|sed 's/--feed //g'`
        if [ ${#RESP} -gt 0 ] && [ "$RESP" == "$FEED" ];
        then
                # We find a server with the fee
                IP=`dig +short $server`
                LENGTH=${#IP}

                echo $IP|cut -c"7-$LENGTH"|sed 's/\.//g'
                exit 0;
        fi
done;
# No server found
echo 0;
exit 0;
