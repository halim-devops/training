<?php
echo shell_exec("/var/www/html/a2confreader.sh $_SERVER[HTTP_HOST]");
?>
