#!/bin/bash
# small comment to check gitlab
CONF=$(grep $1 /etc/apache2/sites-enabled/*|grep ServerName|awk '{print $1}'|sed 's/://g')
SERVICES=$(grep ProxyPassReverse $CONF|grep -v Cookie |awk '{print $2}')
LOCATIONS=$(grep RedirectPermanent $CONF|awk '{print $2}'|sed 's/"//g')
JSON="\"baseUrl\":\"$1\""

SRV=""

function addservices {
	NB=($1)
	if [ ${#NB[@]} -gt 0 ]; then
		for i in  $1; do 
			if [ ${#SRV} -gt 0 ]; then
				SRV="$SRV, \"$i\"";
			else
				SRV="\"$i\""
			fi
		done;
	fi
}


addservices "$SERVICES"
addservices "$LOCATIONS"

NB=($SRV)
if [ ${#NB[@]} -gt 0 ]; then
	JSON="$JSON, \"services\": [ $SRV ]";
else
	JSON="$JSON, \"services\": null"
fi
echo "{$JSON}"
