<?php
//phpinfo();
$process=$_GET['process'];
header('Content-Type: application/json');
$script="ps -eo start_time,pid,cmd|grep $process|grep -v grep| sed 's/\(.*\) \([0-9]*\) \(.*\)$/{\"start_time\":\"\\1\",\"pid\":\"\\2\",\"cmd\":\"\\3\"},/'";
//echo $script;
echo shell_exec ($script);
?>
