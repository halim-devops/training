#!/bin/bash
#PROJECTS_LIST="exporter"
#exporter_servers="10.10.10.10 10.10.12.45 10.10.1.145"
#exporter_process="java|grep -v sudo"
#test_servers="toot ututu"
#test_process="java"

source ./checkProcess.conf

#WITPASS='W@rk1T!!!'

function evalvar {
        NAME="$1_$2"
        echo "${!NAME}"
}

#ps -eo pid,cmd|grep apache|grep -v grep|sed 's/ \([0-9]*\) \(.*\)/{pid:"\1",cmd:"\2"}/g'
TO_RETURN="{ \"return\":["
prj=0

for project in $PROJECTS_LIST;
do
	if [ $prj -gt 0 ];
	then
		TO_RETURN="$TO_RETURN,"
	fi
	TO_RETURN="$TO_RETURN { \"name\":\"$project\", \"datas\":["
        SERVERS=`evalvar $project servers`
        PROCESS=`evalvar $project process`
	srv=0
        for server in $SERVERS;
        do
		if [ $srv -gt 0 ];
        	then
                	TO_RETURN="$TO_RETURN,"
        	fi
		TO_RETURN="$TO_RETURN { \"server\":\"$server\", \"processes\":"
#                CMD="ps -eo start_time,pid,cmd|grep $PROCESS|grep -v grep| sed 's/\(.*\) \([0-9]*\) \(.*\)$/{\"start_time\":\"\1\",\"pid\":\"\2\",\"cmd\":\"\3\"},/'"
#		RESPONSE=`sshpass -p $WITPASS ssh -o StrictHostKeyChecking=no wit@$server $CMD|sed 's/}.{/},{/g'`

		RESPONSE=`curl -s "http://$server/checkProcessExporter.php?process=$PROCESS"`
		#echo $CMD
		#echo $server
		if [ ${#RESPONSE} -gt 0 ];
		then
			TO_RETURN="$TO_RETURN [$RESPONSE null]"
		else
			TO_RETURN="$TO_RETURN null"
		fi
		TO_RETURN="$TO_RETURN }"
		let srv=$srv+1
        done;
	TO_RETURN="$TO_RETURN] }"
	let prj=$prj +1
done;

echo "$TO_RETURN] }";
