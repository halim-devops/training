<?php
$script=$_GET['path'];
$token = file_get_contents($script);
echo $token;
//echo shell_exec ("/var/www/html/ws/$script $params");
?>
