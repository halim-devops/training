#!/usr/bin/env bash

DOWNLOADDIR=/var/log/workit/download

find $DOWNLOADDIR -type f -mtime +7 -delete
find $DOWNLOADDIR -type d -empty -delete