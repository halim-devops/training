#!/bin/bash
subDomain=$1
list="/tmp/list.$(echo $1|sed 's|\/|_|g').dns"
rm $list;
for ip in $(nmap -sP $1 | egrep -o "([0-9]{1,3}\.){3}[0-9]{1,3}"|sort -u);
do 
	for name in $(nslookup $ip|grep name|sed 's|.* = \(.*\)\.|\1|g'|sed 's|.workit.*||g'); do
		echo "$name;$ip" >> $list
	done
done;
#/home/imoussa/Developpements/ops-tools/script//wssh.jd 10.10.10.13  "echo \"hostname: \$\(hostname -s\)"\"|grep hostname|awk '{print $2}'
checkDNS.sh $list
