#!/bin/bash
function usage {
	echo "Usage : $0 -d <network:x.y.z.t/v> -u [user] -p [password (if user set password is mandatory)]"
	exit 1;
}

# Usage: DOMAIN OUTPUT-FILE <USER> <PASS>


while getopts "d:u:p:o:" option
do
	case $option in
		d)
		DOMAIN=$OPTARG
		;;
		u)
		USER_W=$OPTARG
		;;
		p)
		PASS=$OPTARG
		;;
		o)
		OUTPUT=$OPTARG
		;;
#		\? ) echo "Unknown option: -$OPTARG" >&2; exit 1;;
	        :  ) echo "Missing option argument for -$OPTARG" >&2; exit 1;;
        	*  ) echo "Unimplemented option: -$OPTARG" >&2; exit 1;;
	esac
done

if [ -z "$DOMAIN" ]; then
	echo " # Network is mandatory <network:x.y.z.t/v>"
	usage;
fi

if [ -z "$OUTPUT" ]; then
	OUTPUT=`echo "$DOMAIN.log"|sed "s/\//-/g"`
	OUTPUT="/tmp/$OUTPUT"
	echo " # Output not set, default $OUTPUT is used"

fi

if [ -n "$USER_W" ]; then
	if [ -z "$PASS" ]; then
		echo " # User $USER is set, password is mandatory"
		usage;
	fi
else
	# Login par defaut
	USER_W="workitadmin"
	PASS='W0rk1T2013'
fi

echo ""
echo " # Domain is set: $DOMAIN"
echo " # User is set: $USER_W"
echo " # Password is set: ********"
echo " # Output file is set to: $OUTPUT"
echo ""
echo " # Cleaning output file"
rm -f $OUTPUT
touch $OUTPUT
echo " # Starting searching on the network"
echo ""
for ip in `nmap -sP $DOMAIN | egrep -o "([0-9]{1,3}\.){3}[0-9]{1,3}"`; do
	echo " # Working on $ip";
	echo "-------------------------------------------------------------------------------------------------------------------">> $OUTPUT;
	echo "SERVEUR ($ip), DNS name: ">> $OUTPUT;
	host $ip|awk '{print $5}'>> $OUTPUT;
	echo "INFO:" >> $OUTPUT;
	sshpass -p $PASS ssh -o StrictHostKeyChecking=no "$USER_W@$ip" 'echo "NB Cnx ESTABLISHED: " `netstat -lauten|grep EST|wc -l`;' 2>&1 >> $OUTPUT
	sshpass -p $PASS ssh -o StrictHostKeyChecking=no "$USER_W@$ip" 'echo "Montage disks: "; df -h;' 2>&1 >> $OUTPUT
	sshpass -p $PASS ssh -o StrictHostKeyChecking=no "$USER_W@$ip" 'netstat -lauten|grep EST;' 2>&1 >> $OUTPUT
	sshpass -p $PASS ssh -o StrictHostKeyChecking=no "$USER_W@$ip" 'echo "LATEST LOG: "; sudo find /var/log/ -type f -regex ".*log" -mtime -1 -exec ls -lah {} \;' 2>&1 >> $OUTPUT
 #-exec tail -n 4 {} \;' 2>&1 >> $OUTPUT
done;

exit 0;

