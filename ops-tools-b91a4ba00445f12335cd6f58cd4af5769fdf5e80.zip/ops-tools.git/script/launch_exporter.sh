#/bin/bash
### Script de gestion de lancement des jobs EXPORTER via RUNDECK

# Arguments
ENVIRONNEMENT=$1
PLATEFORME=$2
FLUX=$3
LOG=$4
MEMOIRE=$5
# Variable
SLEEPMIN=1
SLEEPMAX=15


# Au cas ou on sait pas se servir de ce script 
function usage() {
        echo "MAUVAISE UTILISATION DU SCRIPT"
        echo "USAGE: ./launch_exporter <ENVIRONNEMENT> <PLATEFORME> <FLUX> <REPERTOIRE DE LOG> <MEMOIRE (OPTIONNEL)>"
        echo "EXEMPLE: ./launch_exporter PROD UK bcc/xml /mnt/nas-e1/exporter/boulanger_\${option.DATE}-rundeck.log"
        echo "AUTRE EXEMPLE: ./launch_exporter PROD UK bcc/xml -Xmx5120m -Xms5120m /mnt/nas-e1/exporter/boulanger_\${option.DATE}-rundeck.log"
        exit 1
}

#Si tout est OK on lance la commande Exporter (voir check des variables vides en bas!)
function launchExporter() {
        # On temporise un peu pour éviter un éventuel gouleau d'etranglement si le HAPROXY fait de la merde..."
        # Un petit RANDOM
        DELAI=$((SLEEPMIN+RANDOM*(1+SLEEPMAX-SLEEPMIN)/32767))
        echo "Lancement de la commande Exporter dans $DELAI secondes"
        sleep $DELAI
        # On crée un fichier d'execution pour gerer les alertes mails
        echo "Creation du fichier d'execution"
        # On retravaille le nom du flux pour nommer le fichier d'execution
        NOMFLUX="$(echo $FLUX | cut -d "/" -f1)_$(echo $FLUX | cut -d "/" -f2)"
        if [ ! -f "/mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC.tmp" ]; then
                echo "3" > /mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC.tmp
        fi
        # LAUNCH
        sudo -u wit-exporter /usr/bin/java $MEMOIRE -jar /opt/workit/exporter/lib/exporter.jar --env  $ENVIRONNEMENT --platform $PLATEFORME --feed $FLUX --enable-caches | tee $LOG
        # On check si la job s'est bien executé pour éviter les codes erreurs douteux
        LASTLINE=`tail -1 $LOG`
        echo $LASTLINE | grep took > /dev/null 2>&1
        if [ $? -ne 0 ]; then
                echo "Le job ne s'est pas terminé correctement"
                # On décrémente de 1
                RETRY=$(cat "/mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC.tmp")
                RETRY=$(($RETRY-1))
                echo $RETRY > /mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC.tmp
                if [ $RETRY -le 0 ];then
                        rm -f /mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC.tmp
                        echo "Flux $NOMFLUX KO" | mail -s "Flux $NOMFLUX KO" -a "FROM: rundeck@workit.fr" exploitation@workit.fr team-cs@workit-software.com
                        exit 1
                fi
                exit 1
        else
		echo "Le job s'est terminé correctement"
                # On supprime le fichier d'execution car le job s'est executé correctement
                echo "Suppression du fichier d'execution"
                rm -f /mnt/nas-e1/exporter/rundeck/${NOMFLUX}_EXEC.tmp
                exit 0
        fi
}

# Check des arguments, $MEMOIRE est optionnel (check inutile)
if [[ -z $ENVIRONNEMENT ||  -z $PLATEFORME ||  -z $FLUX || -z $LOG ]] ;then
        usage
else
        launchExporter
fi
