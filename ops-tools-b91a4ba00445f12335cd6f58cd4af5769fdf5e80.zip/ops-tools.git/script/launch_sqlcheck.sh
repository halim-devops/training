#!/bin/bash

SERVER=$HOSTNAME

if [[ "$SERVER" =~ .*fr.* ]]; then
	PLATFORM=FR
	DB=workit_bgb_v4
fi

if [[ "$SERVER" =~ .*uk.* ]]; then
	PLATFORM=UK
	DB=workit_uk_v4
fi

if [[ "$SERVER" =~ .*fa.* ]]; then
	PLATFORM=FA
	DB=workit_fashion_v4
fi

if [[ "$SERVER" =~ .*ad.* ]]; then
	PLATFORM=AD
	DB=workit_adhoc_v4
fi

if [[ "$SERVER" =~ .*ii.* ]]; then
	PLATFORM=II
	DB=workit_ii_v4
fi

if [[ "$SERVER" =~ .*it.* ]]; then
	PLATFORM=IT
	DB=workit_it_v4
fi

if [[ "$SERVER" =~ .*de.* ]]; then
	PLATFORM=DE
	DB=workit_de_v4
fi

if [[ "$SERVER" =~ .*cg.* ]]; then
	PLATFORM=CG
	DB=workit_cg_v4
fi

curl -s http://gitlab.workit.fr/ops-team/ops-tools/raw/master/script/MysqlCheck.sh | bash /dev/stdin $PLATFORM $SERVER.workit.fr $DB; exit $?
