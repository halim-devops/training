#!/bin/bash
if [ "$#" -ne 1 ]; then
	echo -99
	exit 0;
fi
TEST_ID=$1
API_KEY="tJYYJBEZq35UixTyBmeb"
USERNAME="exploitationworkitfr"
RESULT=$(curl -s -H "API: $API_KEY" -H "Username: $USERNAME" -X GET https://app.statuscake.com/API/Tests/Checks?TestID=$TEST_ID|jq -r '[keys[] as $k | .[$k]|{Time, Status, Human}]|sort_by(.Time)|reverse|.[0]| .Status')
if [[ $RESULT == "null" ]]; then
	echo -1
else
	echo $RESULT
fi
exit 0
