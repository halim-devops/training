#!/bin/bash
function usage {
	echo "Usage : $0 -i <ip|hosts-file-list> -m <mongo-filelist> -n <login> "
	exit 1;
}

# Usage: DOMAIN OUTPUT-FILE <USER> <PASS>

while getopts "i:n:m:" option
do
	case $option in
		i)
		HOSTS=$OPTARG
		;;
		n)
		LOGIN=$OPTARG
		;;
		m)
		MONGOS=$OPTARG
		;;
#		\? ) echo "Unknown option: -$OPTARG" >&2; exit 1;;
	        :  ) echo "Missing option argument for -$OPTARG" >&2; exit 1;;
        	*  ) echo "Unimplemented option: -$OPTARG" >&2; exit 1;;
	esac
done

if [ -z "$HOSTS" ]; then
	echo " # IP or HOSTS LIST or DOMAIN is mandatory -i <ip|hosts-file-list|t.u.v.w/z>"
	usage;
fi
if [ -z "$LOGIN" ]; then
	echo " # New username is mandatory -n <login>"
	usage;
fi
if [ -z "$MONGOS" ]; then
	echo " # Mongos list servers not defined, not creating user for databases"
fi


DATE=`date +%Y-%m-%d-%H-%M-%S`
if [ -z "$OUTPUT" ]; then
	OUTPUT="/tmp/$DATE.log"
	echo " # Output not set, default $OUTPUT is used"
fi

ERRORS="/tmp/$DATE.err.log"
echo " # Setting errors file to $ERRORS"

M_USER="root"
M_PASS='W0rk1T!121!'


echo ""
echo " # Hosts is set: $HOSTS"
echo " # Login is set: $LOGIN password: changeme"
echo " # Password is set: ********"
echo " # Output file is set to: $OUTPUT"
echo " # Errors file is set to: $ERRORS"
echo " # Script used: $SCRIPT"
echo ""
echo " # Cleaning output file"
rm -f $OUTPUT
touch $OUTPUT
echo " # Starting searching on the network"
echo ""
if [ ! -f "$HOSTS" ]; then
	LIST="$HOSTS"
else
	LIST=`cat $HOSTS`
fi
for ip in $LIST; do
	echo " # Working on $ip";
	echo "----------------------------------------------------------------------------------" >> $OUTPUT
	echo " # Starting script : $ip" >> $OUTPUT;
	echo "----------------------------------------------------------------------------------" >> $OUTPUT
	echo "----------------------------------------------------------------------------------" >> $ERRORS
	echo " # Starting script : $ip" >> $ERRORS;
	echo "----------------------------------------------------------------------------------" >> $ERRORS

#	mysqldump -uroot -p'W0rk1T!121!' -h$ip mysql user --where="user='template'" --skip-comments|grep INSERT|sed "s/template/$LOGIN/g" >> $OUTPUT
	mysqldump -uroot -p'W0rk1T!121!' -h$ip mysql user --where="user='template'" --skip-comments|grep INSERT|sed "s/template/$LOGIN/g"|mysql -u root --password='W0rk1T!121!' -h $ip mysql 2>> $ERRORS >> $OUTPUT
	echo "flush privileges;" |mysql -u root --password='W0rk1T!121!' -h $ip 2>> $ERRORS >> $OUTPUT
	echo " # Ending script" >> $OUTPUT;
done;

if [ -n "$MONGOS" ]; then
	echo " # Creating user for mongos"
	LST_MGO=`cat $MONGOS`
	for ip in $LST_MGO; do
	        echo " # Working on $ip";
	        echo "----------------------------------------------------------------------------------" >> $OUTPUT
        	echo " # Starting script : $ip" >> $OUTPUT;
	        echo "----------------------------------------------------------------------------------" >> $ERRORS
        	echo " # Starting script : $ip" >> $ERRORS;
		mongo $ip:27017/admin --username wkCreator --password 'J01NtH34Sc$nt' --authenticationDatabase admin --eval "db.runCommand({ createUser: \"$LOGIN\", pwd: \"changeme\", roles: [ { role: \"witDev\", db: \"admin\" } ]})" 2>> $ERRORS >> $OUTPUT
	done;
fi


exit 0;

