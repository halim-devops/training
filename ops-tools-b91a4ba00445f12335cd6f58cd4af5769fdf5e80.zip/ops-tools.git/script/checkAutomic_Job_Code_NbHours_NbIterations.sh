#!/bin/bash
USER="zabbix"
PASS="zabbix"
URL="http://10.10.7.96:8081/automic-rest/api/awa"
TOKEN_FILE="/tmp/automic.token"
#PARAMS
JOB_NAME=$1
AUTOMIC_CODE=$2
NB_HOURS=$3
NB_ITERATIONS=$4


# Call URL
LOGIN_PARAM="login/v1/auth?login=$USER&pwd=$PASS&connection=WORKIT&client=1"
LOGOUT_PARAM="logout/v1/auth"
JOBS_PARAM="search/v1/Statistics?filters=\[name:$JOB_NAME,activation:LAST${NB_HOURS}HOURS\]"

function callRest {
	curl -s "$URL/$1"
}

function getToken {
	cat $TOKEN_FILE
}

function logout {
	callRest "$LOGOUT_PARAM?token=$1"|jq '.status'|sed 's/"//g'
}

function getLastStatus {
#	callRest "$JOBS_PARAM&token=$1"
	callRest "$JOBS_PARAM&token=$1"|jq '[.data[] | { statuscode } | select(.statuscode=='"$AUTOMIC_CODE"')]|length'
#	callRest "$JOBS_PARAM&token=$1"|jq "[.data[] | { statuscode}]"
}

# get the token for quering automic
TOKEN=`getToken`
#echo $TOKEN
# get the last status of $1
STATUS=`getLastStatus $TOKEN`
echo $STATUS
exit 0
if [ $STATUS -ge $NB_ITERATIONS ]; then
	echo 1;
	exit 0;
fi
echo 0;
exit 0;
