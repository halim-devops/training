#!/bin/bash
# need package JQ et libxml2-utils
JSON=$(curl -s http://travaux.ovh.net/|xmllint --html -xpath '/html/body/div[@id="content"]/div[@id="tasklist"]/form/div/table[@id="tasklist_table"]/tr' - |sed -e 's|<tr id="\(.*\)" class="[a-z1-9]*">|{ \r\n\t"taskId":"\1", \r\n\t"datas": { \r\n\t\t"default":null|g' -e "s|</tr>|\t}\r\n},|g" -e 's|<td class="\([a-z_]*\)">\(.*\)</td>|\t\t,"\1":"\2"|g' -e 's|<a href="\(.*\)">.*</a>|http://travaux.ovh.net\1|g'); 
NBALERT=$(echo "[${JSON}null]" |jq '.[]|select(.!=null)|select( (.datas.task_category|match( "(roubaix|rbx).*";"i") ) and (.datas.task_tasktype|match("incident";"i") ) and (.datas.task_status|match("in progress";"i") ) )|.taskId'|wc -l)
# ECHO FINAL
echo $NBALERT
# ECHO DE TEST
#echo 2

