#!/bin/bash
function usage {
	echo "sudo $0 <database> <file to restore>"
	exit 1
}

if [[ $EUID -ne 0 ]]; then
	echo "You must be root or sudoers"
	exit 1;
fi

MYCNF="/etc/mysql/my.cnf"
DATADIR=`cat $MYCNF|grep -v "#"|grep datadir|cut -d"=" -f2|sed 's/ //g'`

if [ -z "$1" ]; then
	echo "Database mandatory";
	usage;
fi;

if [ -z "$2" ]; then
	echo "File to restore mandatory";
	usage;
fi;

if [ ! -f "$2" ]; then
	echo "$2 is not a file";
fi

if [ ! -d "$DATADIR/$1" ]; then
	echo "$DATADIR/$1 doesn't exist"
	exit
fi

echo "Stopping puppet (if already not)"
service puppet stop;
DATE=`date +%Y-%m-%d-%H-%M-%S`
USER='root'
PASS='W0rk1T!121!'
PROPERTIES="/root/properties.$DATE.sql"
USERS="/root/user.$DATE.sql"
echo "Dumping properties"
mysqldump -u$USER -p$PASS $1 properties > $PROPERTIES
mysqldump -u$USER -p$PASS mysql user > $USERS
echo "flush privileges;" >> $USERS

echo "Stopping mysql services"
service mysql stop;
echo "Waiting 2s before check if mysql is down"
sleep 2
STATUS_M=`ps aux|grep mysql|grep -v grep|awk '{print $2}'|wc -l`
if [ $STATUS_M -ne 0 ]; then
	echo "Mysql is not STOPPED"
	exit 1
fi
echo "Removing $DATADIR/* before restore"
rm -rf $DATADIR/*
echo "Updating from dump"
tar xvfpz $2 -C $DATADIR/
echo "Updating rights"
chown -R mysql:mysql $DATADIR
echo "Starting mysql"
service mysql start

mysql -u $USER --password=$PASS -e "TRUNCATE TABLE properties;" $1
cat $PROPERTIES |mysql -u $USER --password=$PASS $1
cat $USERS |mysql -u $USER --password=$PASS mysql
echo "Restoration complete"
exit 0;
