#!/bin/bash
FILE=$1
rm /tmp/output.check.log
for elt in $(cat $FILE);
do
	IP=$(echo "$elt"|cut -d";" -f2)
	DNS=$(echo "$elt"|cut -d";" -f1)
	echo "Test $DNS on ip $IP"
	result=$(fping -q -t 50 $IP; echo $?)
	if [ "x$result" = "x0" ]; then
		REMOTE_DNS=$(wssh.jd $IP 'echo hostname: $(hostname -s)'|grep hostname|awk '{print $2}' |sed 's| ||g')
		echo "CHECK for $DNS: ${DNS/$REMOTE_DNS}"
		if [ "${DNS/$REMOTE_DNS}" = "$DNS" ]; then
			echo "       =====> DNS $DNS for hostname $REMOTE_DNS"
			echo "       =====> Need to remove $DNS -> $IP"
			echo "$DNS;$IP;$REMOTE_DNS;unavailable" >> /tmp/output.check.log
		else
			echo " OK      =====> DNS $DNS for hostname $REMOTE_DNS"
			echo "$DNS;$IP;$REMOTE_DNS;OK"  >> /tmp/output.check.log

		fi
	else
		echo "       =====> IP $IP is not available"
		echo "       =====> Need to remove $DNS -> $IP"
		echo "$DNS;$IP;pas de ping;to remove" >> /tmp/output.check.log
	fi

done;
