#!/bin/bash
USER="zabbix"
PASS="zabbix"
URL="http://10.10.7.96:8081/automic-rest/api/awa"
TOKEN_FILE="/tmp/automic.token"
# Call URL
LOGIN_PARAM="login/v1/auth?login=$USER&pwd=$PASS&connection=WORKIT&client=1"
LOGOUT_PARAM="logout/v1/auth"
JOBS_PARAM="search/v1/Statistics?filters=\[name:$1,activation:LAST24HOURS\]"

function callRest {
	curl -s "$URL/$1"
}

function getToken {
	cat $TOKEN_FILE
}

function logout {
	callRest "$LOGOUT_PARAM?token=$1"|jq '.status'|sed 's/"//g'
}

function getLastStatus {
	callRest "$JOBS_PARAM&token=$1"|jq '[.data[] | {status, starttime}]|sort_by(.starttime)|reverse|.[0]|.status'|sed 's/"//g'
}

# get the token for quering automic
TOKEN=`getToken`
#echo $TOKEN
# get the last status of $1
STATUS=`getLastStatus $TOKEN`
#echo $STATUS
case "$STATUS" in
	'state_abended')
		echo -1
	;;
	'state_unknown')
		echo 1
	;;
	'state_ended')
		echo 0
	;;
	*) echo 0
esac
exit 0
