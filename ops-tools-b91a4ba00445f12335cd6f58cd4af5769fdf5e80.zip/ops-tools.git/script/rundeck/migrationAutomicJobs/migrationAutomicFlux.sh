#!/bin/bash
# Paramètres
PROJECT=$1
FILECONF=$2
RUNDECKINSTANCE="http://pral-rdk01.workit.fr:4440"
TOKEN="yJHjyHmo0M4oe8sczSLRrG7bNCdv9GSd"

usage() {
echo "USAGE: migrationAutomicFlux.sh PROJECTNAME FICHIERPARAMETRE"
echo "Example: migrationAutomicFlux.sh Exporter jobs.conf"
}


migration() {

### On génère les fichiers XML RUNDECK
while read ligne; do
	# Récupération des variables qui nous intéressent
	JOBNAME=`echo $ligne | cut -d " " -f1 |  cut -d "=" -f2`
	ACTECACHE=`echo $ligne  | cut -d " " -f2 | cut -d "=" -f2`
	DRYRUN=`echo $ligne | cut -d " " -f3 | cut -d "=" -f2`
	FLUX=`echo $ligne | cut -d " " -f4 | cut -d "=" -f2`
	LOGFILE=`echo $ligne | cut -d " " -f5 | cut -d "=" -f2`
	PLATEFORME=`echo $ligne | cut -d " " -f6 | cut -d "=" -f2`	
        MONTH=`echo $ligne | cut -d " " -f7 | cut -d "=" -f2`	
        DAY=`echo $ligne | cut -d " " -f8 | cut -d "=" -f2`
	HOUR=`echo $ligne | cut -d " " -f9 | cut -d "=" -f2`
	MINUTE=`echo $ligne | cut -d " " -f10 | cut -d "=" -f2`

	# On génère ensuite le XML
echo "Génération du JOB $JOBNAME"
echo "<joblist>
  <job>
    <description></description>
    <dispatch>
      <excludePrecedence>true</excludePrecedence>
      <keepgoing>false</keepgoing>
      <rankOrder>ascending</rankOrder>
      <successOnEmptyNodeFilter>false</successOnEmptyNodeFilter>
      <threadcount>1</threadcount>
    </dispatch>
    <executionEnabled>false</executionEnabled>
    <loglevel>INFO</loglevel>
    <name>$JOBNAME</name>
    <nodeFilterEditable>false</nodeFilterEditable>
    <nodefilters>
      <filter>name: pral-haexp01.workit.fr:2222</filter>
    </nodefilters>
    <nodesSelectedByDefault>true</nodesSelectedByDefault>
    <notification>
      <onfailure>
        <email recipients='exploit@workit-software.com' subject='FLUX KO' />
      </onfailure>
      <onsuccess>
        <email recipients='exploit@workit-software.com' subject='Flux OK' />
      </onsuccess>
    </notification>
    <retry delay='20s'>1</retry>
    <schedule>
      <month month='$MONTH' />
      <time hour='$HOUR' minute='$MINUTE' seconds='0' />
      <weekday day='$DAY' />
      <year year='*' />
    </schedule>
    <scheduleEnabled>true</scheduleEnabled>
    <sequence keepgoing='false' strategy='parallel'>
      <command>
        <script><![CDATA[environnement=PROD
flux=$FLUX
plateforme=$PLATEFORME
cache=$ACTECACHE
dryrun=$DRYRUN

memoire=\"-Xmx5120m -Xms5120m\"
sudo -u wit-exporter /usr/bin/java \$memoire -jar /opt/workit/exporter/lib/exporter.jar --env  \$environnement --platform \$plateforme --feed \$flux  --enable-caches --dry-run

]]></script>
        <scriptargs />
      </command>
    </sequence>
   </job>
</joblist>

 
"> $JOBNAME.xml

echo "Importing JOB $JOBNAME"
curl -v --header "X-Rundeck-Auth-Token:$TOKEN" -F xmlBatch=@"$JOBNAME.xml" $RUNDECKINSTANCE/api/20/project/$PROJECT/jobs/import 
done < $FILECONF

echo "Purge des fichier XML temporaires"
rm -f *.xml

}

		
if [ $# -ne 2 ];then
	usage
else
	migration
fi
