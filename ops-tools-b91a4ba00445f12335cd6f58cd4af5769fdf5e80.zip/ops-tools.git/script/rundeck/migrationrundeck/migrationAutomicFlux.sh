#!/bin/bash
# Paramètres
PROJECT=$1
FILECONF=$2
RUNDECKINSTANCE="http://testrundeck01:4440"
TOKEN="EkHesRht75PfRCIlhZryI0Ys0b0bSH9C"

usage() {
echo "USAGE: migrationAutomicFlux.sh PROJECTNAME FICHIERPARAMETRE"
echo "Example: migrationAutomicFlux.sh Exporter jobs.conf"
}


migration() {

### On génère les fichiers XML RUNDECK
while read ligne; do
	# Récupération des variables qui nous intéressent
	JOBNAME=`echo $ligne | cut -d " " -f1 |  cut -d "=" -f2`
	ACTECACHE=`echo $ligne  | cut -d " " -f2 | cut -d "=" -f2`
	DRYRUN=`echo $ligne | cut -d " " -f3 | cut -d "=" -f2`
	FLUX=`echo $ligne | cut -d " " -f4 | cut -d "=" -f2`
	LOGFILE=`echo $ligne | cut -d " " -f5 | cut -d "=" -f2`
	PLATEFORME=`echo $ligne | cut -d " " -f6 | cut -d "=" -f2`	
	
	# On génère ensuite le XML
echo "Génération du JOB $JOBNAME"
echo "<joblist> 
  <job>
    <description></description>
    <dispatch>
      <excludePrecedence>true</excludePrecedence>
      <keepgoing>true</keepgoing>
      <rankOrder>ascending</rankOrder>
      <successOnEmptyNodeFilter>false</successOnEmptyNodeFilter>
      <threadcount>1</threadcount>
    </dispatch>
    <executionEnabled>true</executionEnabled>
    <loglevel>INFO</loglevel>
    <multipleExecutions>true</multipleExecutions>
    <name>$JOBNAME</name>
    <nodeFilterEditable>false</nodeFilterEditable>
    <nodefilters>
      <filter>ppal-expelb01.workit.fr</filter>
    </nodefilters>
    <nodesSelectedByDefault>true</nodesSelectedByDefault>
    <orchestrator>
      <configuration>
        <count>1</count>
      </configuration>
      <type>subset</type>
    </orchestrator>
    <schedule>
      <month month='*' />
      <time hour='*' minute='*' seconds='0/20' />
      <weekday day='*' />
      <year year='*' />
    </schedule>
    <scheduleEnabled>false</scheduleEnabled>
    <sequence keepgoing='false' strategy='node-first'>
      <command>
      <script>
	<![CDATA[
environnement=PROD
flux=$FLUX
plateforme=$PLATEFORME
cache=$ACTECACHE 
dryrun=$DRYRUN
memoire="-Xmx5120m -Xms5120m"
sudo -u wit-exporter /usr/bin/java \$memoire -jar /opt/workit/exporter/lib/exporter.jar --env  \$environnement --platform \$plateforme --feed \$flux  --enable-caches --dry-run]]></script>
      </command>
    </sequence>
  </job>
</joblist>"> $JOBNAME.xml

echo "Importing JOB $JOBNAME"
curl -v --header "X-Rundeck-Auth-Token:$TOKEN" -F xmlBatch=@"$JOBNAME.xml" $RUNDECKINSTANCE/api/20/project/$PROJECT/jobs/import 
done < $FILECONF

echo "Purge des fichier XML temporaires"
rm -f *.xml

}

		
if [ $# -ne 2 ];then
	usage
else
	migration
fi
