#!/bin/bash
# Variables utiles

export RD_URL=http://testrundeck01.workit.fr:4440/api/20
export RD_USER=admin
export RD_PASSWORD=admin

DATE=`date +%Y%m%d`
BACKUPDIRECTORY="/srv/rundeckconfbackup"
HOMEBACKUPDIRECTORY="/home/rdcli"
mkdir backup_tmp

echo "Création d'un DUMP de base"
mysqldump rundeck >> $HOMEBACKUPDIRECTORY/backup_tmp/rundeck.sql

echo "Récupération de la liste des projets en cours..."
rm -f list_projet.tmp
rd projects list | grep -v "#" >> $HOMEBACKUPDIRECTORY/list_projet.tmp
# On bidouille le fichier car rundeck cli n'est pas capable de generer une liste propre sans caractère bizzare!!!!!!!!
lineone=`head -1 list_projet.tmp | cut -c5-100 >> list_projet.tmp`
sed -i 1s/.*/$lineone/ $HOMEBACKUPDIRECTORY/list_projet.tmp

echo "Sauvegarde des projets en cours..."
while read PROJET
        do
                /usr/bin/rd jobs list -f $HOMEBACKUPDIRECTORY/backup_tmp/jobs_$PROJET.xml -p $PROJET 2> /dev/null
        done < $HOMEBACKUPDIRECTORY/list_projet.tmp
rm -f list_projet.tmp

# echo "Arret de  Rundeck en cours..."
#sudo service rundeckd stop

echo "Copie des répertoires logs et data"
sudo cp -r /var/lib/rundeck/data $HOMEBACKUPDIRECTORY/backup_tmp
sudo cp -r /var/lib/rundeck/logs $HOMEBACKUPDIRECTORY/backup_tmp
sudo cp -r /var/rundeck          $HOMEBACKUPDIRECTORY/backup_tmp

#echo "Démarrage de Rundeck en cours..."
#sudo service rundeckd start
sudo tar -czvf backuprundeck$DATE.tar.gz backup_tmp/*

echo "Déplacement du backup vers le serveur NFS"
sudo mv backuprundeck$DATE.tar.gz $BACKUPDIRECTORY

echo "Suppression du répertoire temporaire"
sudo rm -Rf backup_tmp
