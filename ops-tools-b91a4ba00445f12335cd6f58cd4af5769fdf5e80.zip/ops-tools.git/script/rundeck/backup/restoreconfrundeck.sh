#!/bin/bash

echo "Arret de rundeck"
sudo service rundeckd stop

echo "Récupération du dernier backup provenant du master"
FILETORESTORE=`ls -1t /srv/rundeckconfbackup | head -1`
cp -R /srv/rundeckconfbackup/$FILETORESTORE .
sudo tar -xf $FILETORESTORE

echo "Importation du DUMP de base"
mysql rundeck < ~/backup_tmp/rundeck.sql

echo "Démarrage de rundeck"
sudo service rundeckd start

# Rundeck est long à démarrer...
sleep 90

# Purge de tout les projets avant une resto propre
echo "Purge de la conf rundeck en cours..."
rd projects list | grep -v "#" >> list_projet.tmp

# On bidouille le fichier car rundeck cli n'est pas capable de generer une liste propre sans caractère bizzare!!!!!!!!
lineone=`head -1 list_projet.tmp | cut -c5-100 >> list_projet.tmp`
sed -i 1s/.*/$lineone/ list_projet.tmp
while read file
        do
                 PROJET=`echo $file | cut -d "_" -f2 | cut -d "." -f1` 2>/dev/null
                 rd projects delete -p $PROJET -y 2>/dev/null
        done < list_projet.tmp
rm -f list_projet.tmp


# On récupère le nom du projet via le nom du fichier XML et pour on importe le ou les jobs
cd ~/backup_tmp
for file in `ls *.xml`
        do
                PROJET=`echo $file | cut -d "_" -f2 | cut -d "." -f1`
                echo "Restauration du projet $PROJET"
                rd projects create -p $PROJET 2>/dev/null
                rd jobs load -f $file -p $PROJET 2>/dev/null
        done
# On recopies le répertoire /var/lib/rundeck ainsi que les logs des JOBS
echo "Copie des logs en cours"
sudo cp -R  ~/backup_tmp/logs /var/lib/rundeck
echo "Copie des datas en cours"
sudo cp -R  ~/backup_tmp/data /var/lib/rundeck && sudo chown -R rundeck:rundeck  /var/lib/rundeck
sudo cp -R  ~/backup_tmp/rundeck /var/ && sudo chown -R rundeck:rundeck /var/rundeck

echo "Restauration terminée"
cd ..

sudo rm -Rf ~/backup_tmp
if [ -f $FILETORESTORE ]; then
        sudo rm -f $FILETORESTORE
fi

