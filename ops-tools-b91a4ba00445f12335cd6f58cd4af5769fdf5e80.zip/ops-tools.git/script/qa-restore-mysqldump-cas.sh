#!/bin/bash
function usage {
	echo "sudo $0 <file to restore>"
	exit 1
}

if [[ $EUID -ne 0 ]]; then
	echo "You must be root or sudoers"
	exit 1;
fi

MYCNF="/etc/mysql/my.cnf"
DATADIR=`cat $MYCNF|grep -v "#"|grep datadir|cut -d"=" -f2|sed 's/ //g'`

if [ -z "$1" ]; then
	echo "File to restore mandatory";
	usage;
fi;

if [ ! -f "$1" ]; then
	echo "$1 is not a file";
fi

if [ ! -d "$DATADIR/workit_cas_users" ]; then
	echo "$DATADIR/workit_cas_users doesn't exist"
	exit
fi

echo "Stopping puppet (if already not)"
service puppet stop;
DATE=`date +%Y-%m-%d-%H-%M-%S`
USER='root'
PASS='W0rk1T!121!'
DUMP="/root/workit_cas_users.autorities.$DATE.sql"
echo "Dumping workit_cas_users.autorities"
mysqldump -u$USER -p$PASS workit_cas_users authorities  > $DUMP
zcat $1 |mysql -u root --password='W0rk1T!121!' workit_cas_users
mysql -u root --password='W0rk1T!121!' -e "TRUNCATE TABLE authorities;" workit_cas_users 
cat $DUMP |mysql -u root --password='W0rk1T!121!' workit_cas_users 
echo "Restoration complete"

exit 0;
