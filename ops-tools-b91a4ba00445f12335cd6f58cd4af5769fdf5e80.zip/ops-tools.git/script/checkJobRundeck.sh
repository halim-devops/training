#!/bin/bash
URL="http://pral-rdk01.workit.fr:4440"
TOKEN="yJHjyHmo0M4oe8sczSLRrG7bNCdv9GSd"
FLUX=$2
PROJECT=$1


function getLastStatus {
	curl -s -H "Accept: application/json" -X GET "$URL/api/20/project/$PROJECT/executions?authtoken=$TOKEN"|jq '.|[ .executions[]|select(.job.name != null)|select(.job.name|contains("'"$FLUX"'"))]|sort_by(.id)|reverse |.[0]|.status'|sed 's/"//g'
}


# get the token for quering Rundeck
# get the last status of $1

STATUS=$(getLastStatus)

case "$STATUS" in
	'incomplete')
		echo -1
	;;
	'aborted')
		echo -1
	;;
	'failed')
		echo -1
	;;
	'succeeded')
		echo 0
	;;
	*) echo 0
esac
exit 0
