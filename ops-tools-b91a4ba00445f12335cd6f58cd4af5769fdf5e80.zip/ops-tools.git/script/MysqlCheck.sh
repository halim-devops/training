#!/bin/bash

PLATFORM=$1
SERVER=$2
DB=$3

DATE=$(date +%Y%m%d);
LOG_FILE="/var/log/check_mysql_$DATE.log";
ERROR=0;
PACKAGE=$(dpkg -l | grep mysql | wc -l)
RESET=`tput sgr0`
RED=`tput setaf 1`
GREEN=`tput setaf 2`

if [ "$PACKAGE" == "0" ]; then
        echo "${RED}Error : missing Mysql module.${RESET}"
        exit 1
fi

if [ "$PLATFORM" == "" ]; then
        echo "${RED}Error : missing TARGET.${RESET}"
        exit 1
fi

if [ "$SERVER" == "" ]; then
        echo "${RED}Error : missing SERVER.${RESET}"
        exit 1
fi

if [ "$DB" == "" ]; then
        echo "${RED}Error : missing DB.${RESET}"
        exit 1
fi

echo "Check User on $(curl -s http://gitlab.workit.fr/ops-team/ops-tools/raw/master/hosts/zabbix-mysqlcheck/$PLATFORM/sqluser.txt | grep "db:" | cut -d';' -f2) at $(date +%H:%M)." >> $LOG_FILE
echo "Check Read users." >> $LOG_FILE
for i in $(curl -s http://gitlab.workit.fr/ops-team/ops-tools/raw/master/hosts/zabbix-mysqlcheck/$PLATFORM/sqluser.txt | grep "r:");
	do user=$(echo $i | cut -d';' -f2);
	pass=$(echo $i | cut -d';' -f3);
	readOutput=$(mysql -h $SERVER -e "select count(*) from automatchers" -u $user --password="$pass" $DB 2>&1)
	if [[ "$readOutput" =~ .*denied.* ]]; then
		if [[ "$readOutput" =~ .*Access.* ]]; then
	                echo "${RED}$user can't connect to database.${RESET}" >> $LOG_FILE;
			ERROR=1;
        	fi
	else
		echo "${GREEN}$user is OK.${RESET}" >> $LOG_FILE;
	fi
done;

echo "Check Write users." >> $LOG_FILE
for i in $(curl -s http://gitlab.workit.fr/ops-team/ops-tools/raw/master/hosts/zabbix-mysqlcheck/$PLATFORM/sqluser.txt | grep "w:");
	do user=$(echo $i | cut -d';' -f2);
	pass=$(echo $i | cut -d';' -f3);
	writeOutput=$(mysql -h $SERVER -e "INSERT INTO opsteam (user) VALUES (\"$user\");" -u $user --password="$pass" $DB 2>&1)
	if [[ "$writeOutput" =~ .*denied.* ]]; then
		if [[ "$writeOutput" =~ .*Access.* ]]; then
                        echo "${RED}$user can't connect to database.${RESET}" >> $LOG_FILE;
			ERROR=1;
                elif [[ "$writeOutput" =~ .*INSERT.* ]]; then
                        echo "${RED}$user is not allowed to write.${RESET}" >> $LOG_FILE;
			ERROR=1;
                fi
	else
		echo "${GREEN}$user is OK.${RESET}" >> $LOG_FILE;
        fi
done;

userdel=$(curl -s http://gitlab.workit.fr/ops-team/ops-tools/raw/master/hosts/zabbix-mysqlcheck/FR/sqluser.txt |grep "w:" | grep "ops" | cut -d ";" -f2 );
passdel=$(curl -s http://gitlab.workit.fr/ops-team/ops-tools/raw/master/hosts/zabbix-mysqlcheck/FR/sqluser.txt |grep "w:" | grep "ops" | cut -d ";" -f3 );

echo "Purge Opsteam table." >> $LOG_FILE
mysql -h $SERVER -e "DELETE FROM opsteam;" -u $userdel --password="$passdel" $DB 2>&1
echo "Purge Done." >> $LOG_FILE

find /var/log/ -type f -regex "check_mysql.*" -mtime +7 -delete

echo "All users have been checked." >> $LOG_FILE
exit $ERROR
