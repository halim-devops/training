#!/bin/bash
CONTACT="$1"
export SENDMAIL="/usr/sbin/sendmail"
export TEMP_DATE=$(date +%Y%m%d)
export TEMP_MAIL="/tmp/mail.$TEMP_DATE.msg"

function sendmessage {
        MSG="$1"
        echo "To: $CONTACT" > $TEMP_MAIL
        echo "Subject: [INCIDENT OVH] nous avons détecté un incident ovh sur l'interface travaux." >> $TEMP_MAIL
        echo "From: $HOSTNAME@workit.fr" >> $TEMP_MAIL
        echo "" >> $TEMP_MAIL
        echo "$MSG" >> $TEMP_MAIL
        $SENDMAIL -t < $TEMP_MAIL
}
# URL DE TRAVAIL
URL=$(JSON=$(curl -s http://travaux.ovh.net/|xmllint --html -xpath '/html/body/div[@id="content"]/div[@id="tasklist"]/form/div/table[@id="tasklist_table"]/tr' - |sed -e 's|<tr id="\(.*\)" class="[a-z1-9]*">|{ \r\n\t"taskId":"\1", \r\n\t"datas": { \r\n\t\t"default":null|g' -e "s|</tr>|\t}\r\n},|g" -e 's|<td class="\([a-z_]*\)">\(.*\)</td>|\t\t,"\1":"\2"|g' -e 's|<a href="\(.*\)">.*</a>|http://travaux.ovh.net\1|g'); echo "[${JSON}null]" |jq '.[]|select(.!=null)|select( (.datas.task_category|match( "(roubaix|rbx).*";"i") ) and (.datas.task_tasktype|match("incident";"i") ) and (.datas.task_status|match("in progress";"i") ) )|.datas.task_summary')
# URL DE TEST qui renvoit des data
#URL=$(JSON=$(curl -s http://travaux.ovh.net/|xmllint --html -xpath '/html/body/div[@id="content"]/div[@id="tasklist"]/form/div/table[@id="tasklist_table"]/tr' - |sed -e 's|<tr id="\(.*\)" class="[a-z1-9]*">|{ \r\n\t"taskId":"\1", \r\n\t"datas": { \r\n\t\t"default":null|g' -e "s|</tr>|\t}\r\n},|g" -e 's|<td class="\([a-z_]*\)">\(.*\)</td>|\t\t,"\1":"\2"|g' -e 's|<a href="\(.*\)">.*</a>|http://travaux.ovh.net\1|g'); echo "[${JSON}null]" |jq '.[]|select(.!=null)|select( (.datas.task_category|match( "(roubaix|rbx).*";"i") ) and ((.datas.task_tasktype|match("incident";"i")) ) )|.datas.task_summary')
MSG="Bonjour,"
MSG="${MSG}\r\nUn incident a été déclaré sur le site http://travaux.ovh.net."
MSG="${MSG}\r\nVoici les liens \"détectés\":"
for uri in $URL; do
	toadd=$(echo $uri|sed 's|\&amp;|\&|g')
	MSG="${MSG}\r\n $toadd"
done
#echo -e $MSG
sendmessage "$(echo -e ${MSG})"
