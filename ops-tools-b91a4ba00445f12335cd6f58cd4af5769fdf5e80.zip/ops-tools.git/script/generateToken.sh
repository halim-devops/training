#!/bin/bash
USER="zabbix"
PASS="zabbix"
URL="http://10.10.7.96:8081/automic-rest/api/awa"

TOKEN_FILE="/tmp/automic.token"
# Call URL
LOGIN_PARAM="login/v1/auth?login=$USER&pwd=$PASS&connection=WORKIT&client=1"
LOGOUT_PARAM="logout/v1/auth"

function callRest {
	curl -s "$URL/$1"
}

function getToken {
	callRest "$LOGIN_PARAM"|jq '.token'|sed 's/"//g'
}

function logout {
	callRest "$LOGOUT_PARAM?token=$1"|jq '.status'|sed 's/"//g'
}


if [ -f $TOKEN_FILE ]; then
	TOK=`cat $TOKEN_FILE`
	echo "Reading old token: $TOK"
	# Login out from rest server
	EXIT_STATE=`logout $TOKEN`
	if [ "$EXIT_STATE" != "success" ]; then
		echo "Cleaning token success"
	fi

fi

# get the token for quering automic
TOKEN=`getToken`
echo "Token generated $TOKEN"
echo $TOKEN > $TOKEN_FILE

exit 0
