
<?php
/**
 * First, download the latest release of PHP wrapper on github
 * And include this script into the folder with extracted files
 */
require __DIR__ . '/php-ovh/vendor/autoload.php';
use \Ovh\Api;

/**
 * Instanciate an OVH Client.
 * You can generate new credentials with full access to your account on
 * the token creation page
 */
$ovh = new Api( 'yBQN2OkcEWo1s06c',  // Application Key
                'rD0jyO8PcPuNGJYtFI4w3yWlRvr3IMDM',  // Application Secret
                'ovh-eu',      // Endpoint of API OVH Europe (List of available endpoints)
                '4QXJNzMPM2J2efc26V2nGo5TMJNMC7MC'); // Consumer Key

$result = $ovh->get('/dedicatedCloud/pcc-92-222-223-82/datacenter/1118/host/1706');
//$result = $ovh->get('/dedicatedCloud/pcc-92-222-223-82/serviceInfos');

print_r( $result );
?>

