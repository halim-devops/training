<?php
$sessionid=$_GET['sessionid'];
$taskid=$_GET['taskid'];
$command="curl --cookie 'JSESSIONID=$sessionid' -s -H 'Accept: application/json' -X GET 'http://pral-rdk01.workit.fr:4440/api/20/execution/$taskid/abort'";
echo shell_exec($command);
?>
