<?php
$user=$_GET['user'];
$password=$_GET['password'];
$command="curl -s -d'j_username=$user' -d'j_password=$password' -D- -o/dev/null 'http://pral-rdk01.workit.fr:4440/j_security_check'|grep Set-Cookie";
//echo $command;
preg_match('/.*JSESSIONID=(.*);.*/',shell_exec ($command),$jsession);
$sessionid=$jsession[1];
//echo $sessionid;
$command="curl --cookie 'JSESSIONID=$sessionid' -s -H 'Accept: application/json' -X GET 'http://pral-rdk01.workit.fr:4440/api/14/project/Exporter/jobs'|jq '.errorCode'|sed 's|null|true|g; s|.unauthorized.|false|g'";
echo $command;
$result=shell_exec($command);
if(strpos($result,"true")===false) {
	echo "null";
}
else {
	echo $sessionid;
}

?>
