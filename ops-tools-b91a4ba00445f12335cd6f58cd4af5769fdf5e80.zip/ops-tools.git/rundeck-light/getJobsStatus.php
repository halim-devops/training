<?php
$sessionid=$_GET['sessionid'];
$command="curl --cookie 'JSESSIONID=$sessionid' -s -H 'Accept: application/json' -X GET 'http://pral-rdk01.workit.fr:4440/api/20/project/Exporter/executions?recentFilter=2w?recentFilter=1w&max=400'|jq '.|[ .executions[]]'";
//echo $command;
echo shell_exec($command);
?>
