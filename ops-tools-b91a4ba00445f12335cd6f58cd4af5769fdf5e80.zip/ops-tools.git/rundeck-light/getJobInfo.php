<?php
$sessionid=$_GET['sessionid'];
$jobid=$_GET['jobid'];
$command="curl --cookie 'JSESSIONID=$sessionid' -s -H 'Accept: application/json' -X GET 'http://pral-rdk01.workit.fr:4440/api/18/job/$jobid/info'";
echo shell_exec($command);
?>
