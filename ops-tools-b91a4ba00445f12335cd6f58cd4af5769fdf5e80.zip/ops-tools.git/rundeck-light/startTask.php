<?php
$sessionid=$_GET['sessionid'];
$jobid=$_GET['jobid'];
$command="curl --cookie 'JSESSIONID=$sessionid' -s -H 'Accept: application/json' -X POST 'http://pral-rdk01.workit.fr:4440/api/14/job/$jobid/run'";
echo shell_exec($command);
?>
