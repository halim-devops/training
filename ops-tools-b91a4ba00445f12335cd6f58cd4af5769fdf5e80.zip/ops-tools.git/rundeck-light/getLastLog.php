<?php
$sessionid=$_GET['sessionid'];
$jobid=$_GET['jobid'];
$command="curl --cookie 'JSESSIONID=$sessionid' -s -H 'Accept: application/json' -X GET 'http://pral-rdk01.workit.fr:4440/api/5/execution/$jobid/output?format=text'";
echo shell_exec($command);
?>
