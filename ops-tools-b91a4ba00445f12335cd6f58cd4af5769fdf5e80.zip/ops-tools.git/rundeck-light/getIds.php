<?php
$sessionid=$_GET['sessionid'];
#$command="curl --cookie 'JSESSIONID=$sessionid' -s -H 'Accept: application/json' -X GET 'http://pral-rdk01.workit.fr:4440/api/20/project/Exporter/jobs'|jq '.[]|.id'";
$command="curl --cookie 'JSESSIONID=$sessionid' -s -H 'Accept: application/json' -X GET 'http://pral-rdk01.workit.fr:4440/api/20/project/Exporter/jobs'|jq '.[]|select (.enabled == true ) | .id'";
$result=shell_exec($command);
//echo $result;
$json="";
foreach(explode(";",str_replace("\n",";", $result)) as $id){
	if(strlen($id)>0){
		$json.="$id, ";
	}
}
$json.="null";
echo "{ \"data\": [".$json."] }";
?>
