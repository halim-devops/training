<?php
$user=$_GET['user'];
$password=$_GET['password'];
$command="curl -s -d'j_username=$user' -d'j_password=$password' -D- -o/dev/null 'http://pral-rdk01.workit.fr:4440/j_security_check'|grep Set-Cookie";
preg_match('/.*JSESSIONID=(.*);.*/',shell_exec ($command),$jsession);
$sessionid=$jsession[1];
//$command="curl --cookie 'JSESSIONID=$sessionid' -s -H 'Accept: application/json' -X GET 'http://pral-rdk01.workit.fr:4440/api/14/system/info'|jq '.errorCode'|sed 's|null|true|g; s|.unauthorized.|false|g'";
$command="curl --cookie 'JSESSIONID=$sessionid' -s -H 'Accept: application/json' -X GET 'http://pral-rdk01.workit.fr:4440/api/1/projects'|jq '.[]'|grep unauthorized|wc -l";
//echo $command;
$result=shell_exec($command);
//if(strpos($result,"true")===false) {
if($result == "1" ) {
	echo "null";
}
else {
	echo $sessionid;
}

?>
