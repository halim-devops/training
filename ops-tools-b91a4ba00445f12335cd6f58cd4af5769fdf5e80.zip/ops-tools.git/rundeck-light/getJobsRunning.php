<?php
$sessionid=$_GET['sessionid'];
$command="curl --cookie 'JSESSIONID=$sessionid' -s -H 'Accept: application/json' -X GET 'http://pral-rdk01.workit.fr:4440/api/20/project/Exporter/executions/running'|jq '.|[ .executions[]]'";
//$command="curl --cookie 'JSESSIONID=$sessionid' -s -H 'Accept: application/json' -X GET 'http://pral-rdk01.workit.fr:4440/api/20/project/Exporter/executions/running'|jq '.'";
//echo $command;
echo shell_exec($command);
?>
