#!/bin/bash
echo "Starting update zabbix active"

if grep -q "10.10.7.83" /etc/zabbix/zabbix_agentd.conf; then
	echo "Update already done";
else
	echo "Update not done";
	if [ -f /etc/zabbix/zabbix_agentd.conf ]; then
		sudo sed -i '/^Server=/ s/$/,10.10.7.83/' /etc/zabbix/zabbix_agentd.conf
		sudo sed -i '/^ServerActive=/ s/$/,10.10.7.83/' /etc/zabbix/zabbix_agentd.conf
		echo "Restarting zabbix-agent"
		sudo /etc/init.d/zabbix-agent restart
	fi
fi
echo "Exiting script"
exit
