#!/bin/bash

sudo -i 

echo 3600 > /sys/block/`basename /dev/sda`/device/timeout

wget http://gitlab.workit.fr/ops-team/ops-tools/raw/master/templates/rc.locale.vmware

cp /etc/rc.local ./rc.local.backup
cp rc.locale.vmware /etc/rc.local

cat /sys/block/sda/device/timeout


