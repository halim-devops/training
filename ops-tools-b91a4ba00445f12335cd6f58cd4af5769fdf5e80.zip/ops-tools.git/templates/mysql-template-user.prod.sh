#!/bin/bash
#echo "INSERT INTO user VALUES ('%','template','*7ACE763ED393514FE0C162B93996ECD195FFC4F5','Y','N','N','N','N','N','N','N','N','N','N','N','N','N','Y','N','N','N','N','N','N','N','N','N','N','N','N','N','N','','','','',0,0,0,0,'mysql_native_password',NULL,'N');"|mysql -u root --password='W0rk1T!121!' mysql
#echo "flush privileges;" |mysql -u root --password='W0rk1T!121!'

mysqldump -uroot -p'W0rk1T!121!' mysql user --where="user='frelin_vd'" --skip-comments|grep INSERT|sed 's/\*[A-F0-9]*/*7ACE763ED393514FE0C162B93996ECD195FFC4F5/g'|sed 's/frelin_vd/template/g'|mysql -u root --password='W0rk1T!121!' mysql
echo "flush privileges;" |mysql -u root --password='W0rk1T!121!'
