#!/bin/bash

GIT_HOME=/home/git/gitlab
BACKUP_DIR=/opt/git/backup
#BACKUP_REPOSITORY=/nas-e1-backup/GIT 
BACKUP_REPOSITORY=/net/backup/GIT 
BACKUP_DATE=$(date +%Y%m%d)

cd ${GIT_HOME}

sudo -u git -H bundle exec rake RAILS_ENV=production gitlab:backup:create

BACKUP_FILE=`find ${BACKUP_DIR}/ -maxdepth 1 -type f | sort -nr | head -1`

gzip ${BACKUP_FILE}

mv ${BACKUP_FILE}.gz ${BACKUP_REPOSITORY}/gitlab_backup_${BACKUP_DATE}.tar.gz

exit 0

