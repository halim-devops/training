#!/bin/bash
BGB_DB_USER=$1
export MYSQL_PWD="${2}"
query_url="$3"
dbhost="$4"
targetfile="$5"

PLATFORM=$(echo "${dbhost}" | sed -e 's/..\(..\).*/\1/')
BGB_DB_NAME="workit_${PLATFORM}_v4"
case "$PLATFORM" in
"fr")
  BGB_DB_NAME="workit_bgb_v4"
  ;;
"fa")
  BGB_DB_NAME="workit_fashion_v4"
  ;;
"ad")
  BGB_DB_NAME="workit_adhoc_v4"
  ;;
esac
if [ "${dbhost}" == "pral-crawlmys01.workit.fr" ]; then
	BGB_DB_NAME="crawl_input_data"
fi
	
echo "START"
sql_query=/tmp/query.sql.${$}
echo "Creating script: $sql_query"
curl -Ss -o $sql_query ${query_url}
if [ $? -ne 0 ]; then
    echo "ERROR cannot get SQL script from query_url : ${query_url}"
    exit 1
fi
echo "Ready to execute:"
echo "########################################"
cat $sql_query
echo "########################################"

MYSQL_OPTIONS=""
ret=1
echo "Executing script: /usr/bin/mysql -sN ${MYSQL_OPTIONS} --user=${BGB_DB_USER} --host=${dbhost}  --database=${BGB_DB_NAME} --  <  $sql_query (${targetfile})"
if [ "${targetfile}" != "" ]; then
	/usr/bin/mysql -sN ${MYSQL_OPTIONS} --user=${BGB_DB_USER} --host=${dbhost}  --database=${BGB_DB_NAME} --  <  $sql_query > "${targetfile}"
	ret=$?
else
	/usr/bin/mysql -sN ${MYSQL_OPTIONS} --user=${BGB_DB_USER} --host=${dbhost}  --database=${BGB_DB_NAME} --  <  $sql_query
	ret=$?
fi
rm $sql_query > /dev/null 2>&1
echo "Execution done. ($ret)"
exit $ret
