#!/bin/bash
user=$1
password=$2
platform=$3

if [ "${user}" == "" ]; then
	echo "Missing username as parameter!"
	exit 1
fi

if [ "${password}" == "" ]; then
	echo "Missing password as parameter!"
	exit 1
fi


if [ "${platform}" == "" ]; then
	echo "Missing platform as parameter!"
	exit 1
fi

export MYSQL_PWD=$password

BGB_DB_NAME="workit_${platform}_v4"
case "$platform" in
"fr")
  targethost=prfr-wv4mys01.workit.fr
  BGB_DB_NAME="workit_bgb_v4"
  ;;
"fa")
  targethost=prfa-wv4mys01.workit.fr
  BGB_DB_NAME="workit_fashion_v4"
  ;;
"ad")
  targethost=prad-wv4mys01.workit.Fr
  BGB_DB_NAME="workit_adhoc_v4"
  ;;
"ii")
  targethost=prii-wv4mys01.workit.fr
  BGB_DB_NAME="workit_ii_v4"
  ;;
"it")
  targethost=prit-wv4mys01.workit.fr
  BGB_DB_NAME="workit_it_v4"
  ;;
"uk")
  targethost=pruk-wv4mys01.workit.fr
  ;;
"de")
  targethost=prde-wv4mys01.workit.fr
  ;;
"cg")
  targethost=prcg-wv4mys01.workit.fr
  BGB_DB_NAME="workit_cg_v4"
  ;;
esac

# Deactivated - Sizing Meeting 06 Jun 18 - GS/SG/JDB

#/usr/bin/mysql -sN --silent --user=${user} -h ${targethost}  --database=${BGB_DB_NAME}  --execute='SELECT COUNT(*) FROM site_product_instances;' > /opt/workit/mysql/site_product_instances.sizing.${platform}.info
#/usr/bin/mysql -sN --silent --user=${user} -h ${targethost}  --database=${BGB_DB_NAME}  --execute='SELECT COUNT(*) FROM catalog_product_identifiers;' > /opt/workit/mysql/catalog_product_identifiers.sizing.${platform}.info
echo /usr/bin/mysql -sN --silent --user=${user} -h ${targethost} --database=${BGB_DB_NAME}  --execute="SELECT Round(Sum(data_length + index_length) / 1024 / 1024, 1) FROM   information_schema.tables  WHERE table_schema = '${BGB_DB_NAME}' GROUP  BY table_schema;" > /opt/workit/mysql/db_size.sizing.${platform}.info
/usr/bin/mysql -sN --silent --user=${user} -h ${targethost} --database=${BGB_DB_NAME}  --execute="SELECT Round(Sum(data_length + index_length) / 1024 / 1024, 1) FROM   information_schema.tables  WHERE table_schema = '${BGB_DB_NAME}' GROUP  BY table_schema;" > /opt/workit/mysql/db_size.sizing.${platform}.info
