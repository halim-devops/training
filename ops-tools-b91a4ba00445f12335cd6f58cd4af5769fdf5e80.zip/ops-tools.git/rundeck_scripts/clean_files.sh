#!/bin/bash

CP_COLLECTIONS_REPOSITORY=/mnt/nas-ovh/FILES

## Retention (3 days)

find ${CP_COLLECTIONS_REPOSITORY}/CP_collections -name "*offer_specifications*" -mtime +90 -ls -delete

exit 0
