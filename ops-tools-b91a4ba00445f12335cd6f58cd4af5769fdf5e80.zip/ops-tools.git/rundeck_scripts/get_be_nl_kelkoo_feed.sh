#!/bin/bash

#KELKOO FTP
host_kelkoo='ftp://Test-achats:jikWaft8swik@ftpkelkoo.kelkoo.net:21'
path_kelkoo='/'
folder_kelkoo='offer/nb'
folder_kelkoo_merchant='merchant/nb'

#NAS FTP
path_nas_kelkoo="/nas-e1-ftp/WORKIT-INPUT/adhoc/BE_NL_KELKOO"

#BE_NL
echo "Processing folder for KELKOO"

echo "Retrieving folder from KELKOO"

#Check if we can move to kelkoo folder
cd $path_nas_kelkoo
if [ $? -ne 0 ]; then
  echo "ERROR unable to move to $path_nas_kelkoo"
  exit 1
fi
ERROR=0

#Delete old folder
rm -rf ${folder_kelkoo}

#Get be_nl file
wget -r -nH -nv ${host_kelkoo}$path_kelkoo$folder_kelkoo
if [ $? -ne 0 ]; then
  echo "ERROR unable to get folder offer"
  ERROR=1
fi

echo "Retrieving merchant folder from KELKOO"

wget -r -nH -nv ${host_kelkoo}$path_kelkoo$folder_kelkoo_merchant
if [ $? -ne 0 ]; then
  echo "ERROR unable to get folder offer"
  ERROR=1
fi

exit 0
