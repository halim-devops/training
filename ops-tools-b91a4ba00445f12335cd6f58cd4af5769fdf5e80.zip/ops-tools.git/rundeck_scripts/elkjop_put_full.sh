#!/bin/sh

logdate="$(date +%Y%m%d%H%M%S)"
logfile="/var/log/workit/ELKJOP_ftp_${logdate}.log"

echo "FTP_ELKJOP_SCRIPT STARTED: $(date)"

filedate="$(date +%Y%m%d)"

remote_host="217.28.206.200"
remote_user="workit"
remote_passwd="4WDxc9Nj"
remote_dir="competitor_full"

target_dir="/nas-e1-ftp/OUT/elkjop/"

#ELKJOP PUT
cd $target_dir
if [ $? -ne 0 ]; then
  echo "ERROR: cannot change directory to $target_dir !"
  exit 0
fi

beforeC=$(ls | wc -l)

echo "CONNECTING TO REMOTE SITE ${remote_host}"
ftp -v -n $remote_host <<END_SCRIPT
quote USER $remote_user
quote PASS $remote_passwd
bin
prompt
cd $remote_dir/giganttiFI
mput *.csv
quit
END_SCRIPT

cd $target_dir
mv *.csv Archive/

#ELKJOP/ELKJOPNO PUT
cd $target_dir/elkjopno
if [ $? -ne 0 ]; then
  echo "ERROR: cannot change directory to $target_dir/elkjopno !"
  exit 0
fi

beforeC=$(ls | wc -l)

echo "CONNECTING TO REMOTE SITE ${remote_host}"
ftp -v -n $remote_host <<END_SCRIPT
quote USER $remote_user
quote PASS $remote_passwd
bin
prompt
cd $remote_dir/elkjopno/
mput *.csv
quit
END_SCRIPT

cd $target_dir
mv elkjopno/*.csv Archive/elkjopno/

#ELKJOP/elgigantenDK PUT
cd $target_dir/elgigantenDK
if [ $? -ne 0 ]; then
  echo "ERROR: cannot change directory to $target_dir/elgigantenDK !"
  exit 0
fi

beforeC=$(ls | wc -l)

echo "CONNECTING TO REMOTE SITE ${remote_host}"
ftp -v -n $remote_host <<END_SCRIPT
quote USER $remote_user
quote PASS $remote_passwd
bin
prompt
cd $remote_dir/elgigantenDK
mput *.csv
quit
END_SCRIPT

cd $target_dir
mv elgigantenDK/*.csv Archive/elgigantenDK/

#ELKJOP/elgigantenSE PUT
cd $target_dir/elgigantenSE
if [ $? -ne 0 ]; then
  echo "ERROR: cannot change directory to $target_dir/elgigantenSE !"
  exit 0
fi

beforeC=$(ls | wc -l)

echo "CONNECTING TO REMOTE SITE ${remote_host}"
ftp -n $remote_host <<END_SCRIPT
quote USER $remote_user
quote PASS $remote_passwd
bin
prompt
cd $remote_dir/elgigantenSE
mput *.csv
quit
END_SCRIPT

cd $target_dir
mv elgigantenSE/*.csv Archive/elgigantenSE/

if [ $? -ne 0 ]; then
  echo "-- ERROR DURING FTP OPERATION."
  exit 0
fi

echo "FTP_ELKJOP_SCRIPT SUCCESS: $(date)"
exit 0

