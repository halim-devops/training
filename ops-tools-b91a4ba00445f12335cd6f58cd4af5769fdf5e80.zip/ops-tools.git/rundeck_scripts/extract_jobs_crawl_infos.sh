#!/bin/bash
# Create Dryrun job for all existing jobs in EXPORTER PROJECT
# Token 30 days - 14 Jun 18
RD_TOKEN="2MGzINCChAqY7PO7kZLTblkD992vU08K"
RD_URL_BASE="http://rundeck3-prod.workit.fr"
RD_URL_14="${RD_URL_BASE}/api/14"
RD_URL_1="${RD_URL_BASE}/api/1"
RD_URL_18="${RD_URL_BASE}/api/18"
#
# First Get all job ID
jobidlist=$(curl --request POST \
  --url ${RD_URL_14}/project/Crawl/jobs \
  --header 'Cache-Control: no-cache' \
  --header "x-rundeck-auth-token: ${RD_TOKEN}" \
  -s | grep "<job id" | sed -e "s/<job id='\([^']*\)'.*/\1/")
if [ $? -ne 0 ]; then
  echo "Error getting job lists from Rundeck"
  exit 1
fi

cp /dev/null executionPlanCP.txt > /dev/null 2>&1

for jobid in $jobidlist
do
  #Get Job info
  jobinfo=$(curl --request GET \
    --url ${RD_URL_18}/job/{$jobid}/info \
    --header 'Cache-Control: no-cache' \
    --header "x-rundeck-auth-token: ${RD_TOKEN}" -s)
  group=$(echo $jobinfo | sed -e 's/<group>\(.*\)<\/group>/\1/' | grep  -i "Crawl" | grep -i -v disabled)
  if [ "$group" != "" ]; then
    name=$(echo $jobinfo | sed -e 's/.*<name>\(.*\)<\/name>.*/\1/')

    echo $jobinfo | grep 'scheduleEnabled="true"' > /dev/null 2>&1
    scheduleEnable=$?
    echo $jobinfo | grep 'scheduled="true"' > /dev/null 2>&1
    scheduled=$?
    echo $jobinfo | grep "averageDuration" > /dev/null 2>&1
    averageDuration=$?
    echo $jobinfo | grep "nextScheduledExecution" > /dev/null 2>&1
    nextScheduleExecution=$?



    if [ $scheduleEnable -eq 0 -a $scheduled -eq 0 ]; then
      # Scheduled enable
      if [ $averageDuration -eq 0 -a $nextScheduleExecution -eq 0 ]; then
        jobduration=$(echo $jobinfo | sed -e 's/.*averageDuration="\([^"]*\)\".*/\1/')
        nextschedule=$(echo $jobinfo | sed -e 's/.*nextScheduledExecution="\([^"]*\)\".*/\1/')
        jobduration_s=$(( jobduration / 1000 ))
        jobschedule=$(echo $nextschedule | sed -e 's/.*\(..:..\):\(..\).*/\1/')
        #printf -vch  "%${jobduration_s}s" ""
        # $(printf "%s\n" "${ch// /#}")
        echo "$name;$jobduration_s;$jobschedule" |tee -a executionPlanCP.txt
      fi
    fi
  fi
done
echo "###"
cat executionPlanCP.txt | sort -t ';' -k 3 > executionPlanCP.sorted
