#!/bin/bash

FTP_OUT_REPOSITORY=/mnt/nas-ovh/FTP-Data/IN/

find /mnt/nas-ovh/FTP-Data/IN//hp/historical/ -type f -mtime +60 -path '*historical*' -exec rm {} \;

exit 0
