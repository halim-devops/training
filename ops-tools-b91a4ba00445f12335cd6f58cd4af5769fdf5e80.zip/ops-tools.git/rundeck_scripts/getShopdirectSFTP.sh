#!/bin/sh
FILE=$1

logdate="$(date +%Y%m%d%H%M%S)"
logfile="/var/log/workit/SHOPDIRECT_get_sftp_${logdate}.log"
echo "GET FTP_SHOPDIRECT_SCRIPT STARTED $(date)"
filedate="$(date +%Y%m%d)"
remote_host="62.200.74.71"
remote_user="WorkIT"
#remote_passwd="4WDxc9Nj"
remote_dir="outgoing"
target_dir="/nas-e1-ftp/IN/shopdirect_catalogue/"

mkdir -p $target_dir/bkp
if [ -f $target_dir/$FILE ]; then
        mv $target_dir/$FILE $target_dir/bkp/${filedate}_$FILE
fi

cd $target_dir

if [ $? -ne 0 ]; then
  echo "ERROR: cannot change directory to $target_dir !"
  exit 0
fi
echo "CONNECTING TO REMOTE SITE ${remote_host}"
sftp -o StrictHostKeyChecking=no -oIdentityFile=/home/wit/.ssh/workit_shopdirect_nopass.key ${remote_user}@${remote_host} <<END_SCRIPT
get ${remote_dir}/${FILE}
quit
END_SCRIPT
if [ $? -ne 0 ]; then
  echo "-- ERROR DURING FTP OPERATION."
  exit 1
fi
#zabbix_sender -z "pral-opszab.workit.fr" -p 10051 -s "freenas" -k "elkjop.15.status" -o "1"
echo "GET FTP_SHOPDIRECT_SCRIPT STARTED $(date)"
exit 0
