#!/usr/bin/env bash

BRANCH="${1}"
VERSION="${2}"
REPOSITORY="${3}"
ERROR=0
ELSHOST="${4}"
CONFIG="${5}"

if [ "$BRANCH" == "" ]; then
	echo "Error missing BRANCH parameter."
	ERROR=1	
fi

if [ "${VERSION}" == "" ] ;then
	echo "Error missing VERSION parameter."
	ERROR=1
fi

if [ "${REPOSITORY}" == "" ]; then
	echo "Error missing REPOSITORY parameter."
	ERROR=1
fi


if [ "${ELSHOST}" == "" ]; then
	echo "Error missing ELSHOST parameter."
	ERROR=1
fi


if [ "${CONFIG}" == "" ]; then
	CONFIG="insight-demo"
fi

	
if [ $ERROR -eq 1 ]; then
	exit 1;
fi

set +e
pkill -f DataPumpApp
set -e

cd $(mktemp -d)

curl -O "http://gitlab.workit.fr/data-lake/routing/raw/${BRANCH}/w2p/data-pump/src/main/resources/scripts/routing-data-pump.sh"

chmod +x routing-data-pump.sh

time ./routing-data-pump.sh --config="${CONFIG}" --es-host="${ELSHOST}" --es-port="9200"  --forge-repository="libs-${REPOSITORY}-local" --version="${VERSION}"  --git-branch="${BRANCH}"
