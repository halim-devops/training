#!/bin/bash

client=$1
platform=$2
client_pubkey=$3

error=0
if [ "$client" == "" ]; then
  error=1
  echo "Missing Client."
fi

if [ "$platform" == "" ]; then
  error=1
  echo "Missing Platform."
fi

if [ "$client_pubkey" == "" ]; then
  error=1
  echo "Missing Public Key."
fi

if [ $error -eq 1 ]; then
  echo "Usage: $0 ${client} ${platform} <public key>"
  exit 1
fi

id $client > /dev/null 2>&1
if [ $? -eq 0 ]; then
  echo "Error client already exists."
  exit 1
fi

SSH_CONFIG="/etc/ssh/sshd_config"
conf_ssh_test=$(grep -i "Match group ${client}sftp" ${SSH_CONFIG})
if [ $? -eq 0 ]; then
  echo "Configuration in /etc/ssh/sshd_config exists. Weird !"
  exit 1
fi

cp ${SSH_CONFIG} ${SSH_CONFIG}.$$.backup
if [ $? -eq 1 ]; then
  echo "Error backuping ${SSH_CONFIG}."
  exit 1
fi

echo "Adding user."
addgroup ${client}sftp
useradd -d /home/${client} -m ${client}
adduser ${client} ${client}sftp
adduser workitfr ${client}sftp

echo "Creating user directories."
mkdir -p /data/sftp/${platform}/${client}/upload
mkdir -p /data/sftp/${platform}/${client}/download
chown -R wit-exporter:${client}sftp /data/sftp/${platform}/${client}
chmod -R g+rwx /data/sftp/${platform}/${client}/*
chown root:root /data/sftp/${platform}/${client}

echo "Adding Public Key to user."
mkdir /home/${client}/.ssh
echo "${client_pubkey}" >> /home/${client}/.ssh/authorized_keys
chown -R ${client}:${client} /home/${client}/.ssh
chmod 700 .ssh

echo "Adding Feed Watcher Public Key."
echo "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCyeJAMUioMpEXlTMY81GhE6j5yvDre8dQJeG9hPXLSP2IvCxGJ9OU8J4BKMlqfgCwIpZsIhhRxsGoIm6uXpIvr2DjmaZO6X4v2zpXPiHBNnj0eCv2O5t0RZGd1hneOCJYzBB6dM/SNHbFcnUN/LDqljxVRyzD061PYYjwFN8vjVzC3lqOHatPZbO7V0/LHMLPXqmTLp0Q+0RjiE9TrRJHqrKpVX2XRL9suGEg+FJi82Hr+A5VfNhOjMUZyKc3/+oCIx+aVmDAeERoTePssQHgSGXbGiXKO90wNAxOz9PAEDRtJmEZqb2VasP0nmOSgKeZS80OlB/SebbhAm4Rn8kmB wit@pral-expdata
" >> /home/${client}/.ssh/authorized_keys

echo "Updating SSH configuration"
cat >> ${SSH_CONFIG} <<EOF

Match group ${client}sftp
   ChrootDirectory /data/sftp/${platform}/${client}
   ForceCommand internal-sftp
   AllowTcpForwarding no
   X11Forwarding no
EOF

echo "Restarting SSH"
service ssh restart
