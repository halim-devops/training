#!/usr/bin/env bash 
# WorkIT
# (C)2015 Anthony Lapenna

HELP_VERSION=1.2.1

## ================================================
## CONSTANTS
## ================================================

## ================================================
## LIBRARIES
## ================================================
SHFLAGS_LIB_PATH=/usr/lib/workit/bash-libraries/shflags
BSFL_LIB_PATH=/usr/lib/workit/bash-libraries/bsfl
CBL_LIB_PATH=/usr/lib/workit/bash-libraries/cbl

source ${CBL_LIB_PATH}
if [[ $? -ne 0 ]]; then
  echo "Unable to source cbl library: ${CBL_LIB_PATH}"
  exit ${_EXEC_FAILURE}
fi

source ${BSFL_LIB_PATH}
if [[ $? -ne 0 ]]; then
  echo "Unable to source bsfl library: ${BSFL_LIB_PATH}"
  exit ${_EXEC_FAILURE}
fi

source ${SHFLAGS_LIB_PATH}
if [[ $? -ne 0 ]]; then
  echo "Unable to source shFlags library: ${SHFLAGS_LIB_PATH}"
  exit ${_EXEC_FAILURE}
fi

## ================================================
## FLAGS
## ================================================
DEFINE_string 'host' '' 'MongoDB host to connect to' '' 'required'
DEFINE_string 'port' '' 'Server port' '' 'required'
DEFINE_string 'repository' '' 'Backup repository' 'r' 'required'
DEFINE_string 'user' '' 'Username' 'u'
DEFINE_string 'password' '' 'Password' 'p'
DEFINE_string 'log-file' '/var/log/workit/backup-mongodb.log' 'Log file'
DEFINE_string 'tmp-dir' '/tmp/mongodump' 'Temporary directory'
DEFINE_string 'webhook' '' 'URL to send a POST request after the backup is finished' 'w'

FLAGS "$@" || exit $?
eval set -- "${FLAGS_ARGV}"


## ================================================
## BSFL
## LOG_ENABLED: Enable/disable the logging via BSFL.
## LOG_FILE: Where to log messages. You should define a flag to specify the log file path.
## ================================================
LOG_ENABLED=y
LOG_FILE=${FLAGS_log_file}

## ================================================
## GLOBAL VARIABLES
## ================================================
_mongodump_binary=''
_curl_binary=''
_backup_path=''
_archive_name=''

## ================================================
## METHODS
## ================================================
###################################################
# Check if the required binaries are installed.
# Output:
#     Error messages for each missing binary.
check_binaries() {
  _mongodump_binary=$(command -v mongodump) || bail "Could not locate mongodump binary."
  _curl_binary=$(command -v curl) || bail "Could not locate curl binary."
}

###################################################
# Backup the MongoDB server inside the temporary
# directory.
backup_server() {
  local backup_options="--host ${FLAGS_host} --port ${FLAGS_port} --out ${FLAGS_tmp_dir}/${FLAGS_host}"
  if [[ "${FLAGS_user}" != "" ]]; then
    backup_options="${backup_options} -u ${FLAGS_user}"
  fi
  if [[ "${FLAGS_password}" != "" ]]; then
    backup_options="${backup_options} -p ${FLAGS_password}"
  fi 
  "${_mongodump_binary}" ${backup_options} >> "${FLAGS_log_file}" 2>&1|| bail "backup_server() method failed."
}

###################################################
# Archive and compress the backup.
archive_backup() {
  tar czf "${_backup_path}/${_archive_name}" -C "${FLAGS_tmp_dir}/${FLAGS_host}" . >> "${FLAGS_log_file}" 2>&1|| bail "archive_backup() method failed."
}

###################################################
# Prepare the backup requirements.
prepare() {
  local backup_date=$(date +%Y%m%d)
  _backup_path="${FLAGS_repository}/${backup_date}"
  _archive_name="mongodb_backup_${FLAGS_host}_${backup_date}.tar.gz"
  mkdir -p "${_backup_path}"
  mkdir -p "${FLAGS_tmp_dir}/${FLAGS_host}"
}

###################################################
# Clean the temporary directory.
clean() {
  rm -rf "${FLAGS_tmp_dir}/${FLAGS_host}"
}

###################################################
# Trigger a webhook by sending a POST request.
# Will send the archive_path in JSON.
trigger_webhook() {
  "${_curl_binary}" -d "{\"archive_path\": \"${_backup_path}/${_archive_name}\"}" -H 'Content-Type: application/json' "${FLAGS_webhook}"
}

## ================================================
## MAIN
## ================================================

main() {
  check_binaries
  prepare
  backup_server
  archive_backup
  clean
  if [[ "${FLAGS_webhook}" != "" ]]; then
    trigger_webhook
  fi 
  exit ${_EXEC_SUCCESS}
}

main
