#!/bin/sh

logdate="$(date +%Y%m%d%H%M%S)"
logfile="/var/log/workit/DIXONS_sftp_${logdate}.log"

echo "SFTP_DIXONS_SCRIPT STARTED: $(date)"

filedate="$(date +%Y%m%d)"

remote_host="sftp.pollux.revionics.com"
remote_user="DixonsUK_WorkIT"
remote_passwd="2uJ6z7jVjqJrj3"
remote_key="/nas-e1-ftp/SFTP/key/workitfr.key"
remote_passph="workit2012"
remote_dir="inbox"

target_dir="/nas-e1-ftp/OUT/dixons/"

#ELKJOP PUT
cd $target_dir
if [ $? -ne 0 ]; then
  echo "ERROR: cannot change directory to $target_dir !"
  exit 0
fi

beforeC=$(ls | wc -l)

echo "CONNECTING TO REMOTE SITE ${remote_host}"
sshpass -p ${remote_passwd} sftp -v ${remote_user}@${remote_host} <<END_SCRIPT
#sftp -v -i ${remote_key} ${remote_user}@${remote_host} <<END_SCRIPT
#quote PASSPHRASE ${remote_passph}
cd $remote_dir
mput *.psv
quit
END_SCRIPT

if [ $? -ne 0 ]; then
  echo "-- ERROR DURING SFTP OPERATION."
  exit 1
fi

cd $target_dir
mv *.psv Archive/

if [ $? -ne 0 ]; then
  echo "-- ERROR DURING MV OPERATION."
  exit 1
fi

echo "SFTP_DIXONS_SCRIPT SUCCESS: $(date)"
exit 0

