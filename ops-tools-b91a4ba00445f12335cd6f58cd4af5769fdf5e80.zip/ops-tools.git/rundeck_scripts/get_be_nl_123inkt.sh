#!/bin/bash

#FEEDONOMICS FTP
host_feedonomics='ftp2.feedonomics.com'
username_feedonomics='807aa59e17890'
password_feedonomics='762c467d73bc6dbc6ba5aba5'
path_feedonomics_123inkt_be_nl_fr='/'
filename_feedonomics_123inkt_be_nl='123inkt_nl_testaankoop.csv'
filename_feedonomics_123inkt_be_fr='123inkt_be_testaankoop.csv'

#NAS FTP
path_nas_123inkt_be_nl="/nas-e1-ftp/WORKIT-INPUT/adhoc/123INKT_FEED/BE_NL"
path_nas_123inkt_be_fr="/nas-e1-ftp/WORKIT-INPUT/adhoc/123INKT_FEED/BE_FR"

#BE_NL
echo "Processing file for BE_NL"

echo "Retrieving file from be_nl"

#Check if we can move to be_nl folder
cd $path_nas_123inkt_be_nl
if [ $? -ne 0 ]; then
  echo "ERROR unable to move to $path_nas_123inkt_be_nl"
  exit 1
fi
ERROR=0

#Delete old file be_nl
rm -f ${filename_feedonomics_123inkt_be_nl}

#Get be_nl file
wget -nv ftp://$username_feedonomics:$password_feedonomics@$host_feedonomics:21$path_feedonomics_123inkt_be_nl_fr$filename_feedonomics_123inkt_be_nl
if [ $? -ne 0 ]; then
  echo "ERROR unable to get file 123inkt_nl_testaankoop.csv"
  ERROR=1
fi

#BE_FR
echo "Processing file for BE_FR"

echo "Retrieving file from be_fr"

#Check if we can move to be_fr folder
cd $path_nas_123inkt_be_fr
if [ $? -ne 0 ]; then
  echo "ERROR unable to move to $path_nas_123inkt_be_fr"
  exit 1
fi
ERROR=0

#Delete old file be_fr
rm -f ${filename_feedonomics_123inkt_be_fr}

#Get be_fr file
wget -nv ftp://$username_feedonomics:$password_feedonomics@$host_feedonomics:21$path_feedonomics_123inkt_be_nl_fr$filename_feedonomics_123inkt_be_fr
if [ $? -ne 0 ]; then
  echo "ERROR unable to get file 123inkt_be_testaankoop.csv"
  ERROR=1
fi

exit 0
