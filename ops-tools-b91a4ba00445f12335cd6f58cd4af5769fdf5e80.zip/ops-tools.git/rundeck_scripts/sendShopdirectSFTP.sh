#!/bin/sh
FILE=$1
HOUR=$2

#Switch pour prise en charge par JobExporter
echo "Script deactivated"
exit 0

logdate="$(date +%Y%m%d%H%M%S)"
logfile="/var/log/workit/SHOPDIRECT_ftp_${logdate}.log"
echo "FTP_SHOPDIRECT_SCRIPT STARTED $(date)"
filedate="$(date +%Y%m%d)"
remote_host="62.200.74.71"
remote_user="WorkIT"
#remote_passwd="4WDxc9Nj"
remote_dir="incoming"
target_dir="/nas-e1-ftp/OUT/shopdirect/"
if [[ $FILE == *"full"* ]]; then
suffixe="dat"
fi

if [[ $FILE == *"argos"* ]]; then
suffixe="csv"
fi

cd $target_dir
if [ $? -ne 0 ]; then
  echo "ERROR: cannot change directory to $target_dir !"
  exit 0
fi
echo "CONNECTING TO REMOTE SITE ${remote_host}"
sftp -o StrictHostKeyChecking=no -oIdentityFile=/home/wit/.ssh/workit_shopdirect_nopass.key ${remote_user}@${remote_host} <<END_SCRIPT
cd $remote_dir
put ${FILE}_${filedate}_${HOUR}.${suffixe}
quit
END_SCRIPT
if [ $? -ne 0 ]; then
  echo "-- ERROR DURING FTP OPERATION."
  exit 1
fi
#zabbix_sender -z "pral-opszab.workit.fr" -p 10051 -s "freenas" -k "elkjop.15.status" -o "1"
echo "FTP_SHOPDIRECT_SCRIPT SUCCESS $(date)"
exit 0
