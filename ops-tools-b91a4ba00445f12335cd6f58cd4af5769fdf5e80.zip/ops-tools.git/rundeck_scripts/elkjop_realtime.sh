#!/bin/bash -x
JOBNAME=$1
echo "Starting REALTIME JOB for ${JOBNAME}"
echo "current Directory: $(pwd)"
java -jar /usr/lib/workit/bulk/realtime/realtimeimporter.jar --realtime.job.name=${JOBNAME}
echo "FINISHED."
