#!/bin/bash
#
BASE_DIR="/mnt/nas-e1-input"
TARGET_FILENAME="productfeed.xml"

BE_NL_DIR="${BASE_DIR}/adhoc/artencraft_feed/be_nl"
BE_NL_URL="https://pf.tradetracker.net/?aid=254612&encoding=utf-8&type=xml-v2&fid=1081468&categoryType=2&additionalType=2"

BE_FR_DIR="${BASE_DIR}/adhoc/artencraft_feed/be_fr"
BE_FR_URL="http://pf.tradetracker.net/?aid=254612&encoding=utf-8&type=xml-v2&fid=1081687&categoryType=2&additionalType=2"

echo "Processing file for ARTENCRAFT"

echo "Retrieving file from ${BE_NL_URL}"
cd $BE_NL_DIR
if [ $? -ne 0 ]; then
  echo "ERROR cannot go to $BE_NL_DIR"
  exit 1
fi
ERROR=0
curl -k -L -o ${TARGET_FILENAME} "${BE_NL_URL}" > /dev/null 2>&1
if [ $? -ne 0 ]; then
  echo "ERROR cannot get file $TARGET_FILENAME for BE/NL"
  ERROR=1
fi

echo "Retrieving file from ${BE_FR_URL}"
cd $BE_FR_DIR
if [ $? -ne 0 ]; then
        echo "ERROR cannot go to $BE_FR_DIR"
        exit 1
fi

curl -L -o ${TARGET_FILENAME} "${BE_FR_URL}" > /dev/null 2>&1
if [ $? -ne 0 ]; then
        echo "ERROR cannot get file $TARGET_FILENAME for BE/FR"
  ERROR=1
fi

if [ $ERROR -eq 1 ]; then
  exit 1
fi
exit 0

