#!/bin/bash
#
BASE_DIR="/mnt/nas-e1-input"

function getValue {
	STR=$1
	echo ${!STR}
}

#TARGET_FILENAME="productfeed.xml"

if [ -f $1 ]; then
	echo "Reading configuration from file $1"
	. $1
else
	echo "Reading configuration from url $1"
	curl -L -o /tmp/$$.conf $1 > /dev/null 2>&1
	. /tmp/$$.conf
fi
echo ""
echo "Processing file for $PROJECT"
echo ""
echo "Information from configuration"
echo "**************************************************************************"
echo "$DESCRIPTION"
echo "**************************************************************************"
echo ""
echo "Processing file for $PROJECT"
echo ""
ERROR=0
for feed in ${LIST};
do
	URL=$(getValue "${feed}_URL")
	DEST=${BASE_DIR}/$(getValue "${feed}_PATH")
	COMPRESSION=$(getValue "${feed}_COMPRESSION")
	OUTPUT=$(getValue "${feed}_OUTPUT")
	echo "Configuration for $feed"
	echo "External URL : $URL"
	echo "Output PATH : $DEST"
	echo "Output FILENAME : $OUTPUT"
	DOWNLOAD="$OUTPUT"
	if [ ! -z $COMPRESSION ]; then
		echo "The file is compressed $COMPRESSION"
		DOWNLOAD="$OUTPUT.$COMPRESSION"
	fi
	echo "Downloaded FILENAME: $DOWNLOAD"
	cd $DEST
	if [ $? -ne 0 ]; then
		echo "ERROR cannot go to $DEST"
		exit 1
	fi
	curl -L -o ${DOWNLOAD} "${URL}" > /dev/null 2>&1
	if [ $? -ne 0 ]; then
		echo "ERROR cannot get file $DOWNLOAD for $feed"
		ERROR=1
	fi
	if [ ! -z $COMPRESSION ]; then
		echo ""
		echo "File is compressed we un${COMPRESSION} the file"
		echo "from $DOWNLOAD to $OUTPUT"
		if [ $COMPRESSION == "zip" ]; then
			unzip -o ${DOWNLOAD}
			if [ $? -ne 0 ]; then
				echo "Error decompressing."
			fi
		else
			echo "$COMPRESSION NOT IMPLEMENTED"
		fi
		if [ -f ${DOWNLOAD} ]; then
			echo "Removing compressed file ${DOWNLOAD}"
			rm ${DOWNLOAD}
		fi
		echo ""
	fi
	echo "${OUTPUT} File available."
	echo "Transfert complete"
	echo ""
done;

if [ $ERROR -eq 1 ]; then
	echo "There were some errors"
	exit 1
fi
exit 0

