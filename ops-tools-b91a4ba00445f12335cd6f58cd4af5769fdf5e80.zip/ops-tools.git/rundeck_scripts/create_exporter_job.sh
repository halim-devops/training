#!/bin/bash

## INPUT ##
typeset -u platform
platform=$1
schedule_hour=$(printf "%02d\n" $2)
schedule_minute=$(printf "%02d\n" $3)
feed_name=$4
metrics=$5
memory=$6

error=0
if [ "$platform" == "" ]; then
  echo "Platform not defined."
  error=1
fi

if [ "$schedule_hour" == "" ]; then
  echo "Schedule Hour not defined."
  error=1
fi

if [ "$schedule_minute" == "" ]; then
  echo "Schedule Minute not defined."
  error=1
fi

if [ "$feed_name" == "" ]; then
  echo "Feed name not defined."
  error=1
fi

if [ $error -eq 1 ]; then
  exit 1
fi

###################

schedule_seconde=0
schedule_day='*'
schedule_year='*'
environement="PROD"

###################

jobname_dryrun="${feed_name}_dryrun"
jobname_dryrun=$(echo "${jobname_dryrun}" | sed -e 's/\//_/g')

jobname=""
if [ "${metrics}" == "yes" ]; then
  jobname="metrics_"
fi
jobname="${jobname}${feed_name}_${schedule_hour}h${schedule_minute}"
# Replace in feed name slash by underscore
jobname=$(echo "${jobname}" | sed -e 's/\//_/g')


if [ "$memory" != "0" ]; then
  memory_set="-Xmx${memory}g -Xms${memory}g"
fi

# First no dryrun
dryrun="disabledryrun"

feed_command="<command><exec>bash launch_exporterv2.sh ${environement} ${platform} ${feed_name} ${dryrun} enablecache ${memory_set}</exec></command>"
metrics_command=""
if [ "${metrics}" == "yes" ]; then
  metrics_command="<command><exec>bash launch_exporter_metrics.sh ${feed_name}</exec></command>"
fi

tmp_job_def="/tmp/temporary_job_${jobname}.$$.xml"
tmp_job_def_dryrun="/tmp/temporary_job_${jobname}.dryrun.$$.xml"

echo "Creating job for ${feed_name} with metrics to ${metrics}, scheduled at ${schedule_hour}:${schedule_minute} - Memory : ${memory}g (if 0 not set)."

cat > ${tmp_job_def} <<EOF
<joblist>
	<job>
		<description/>
		<dispatch>
			<excludePrecedence>true</excludePrecedence>
			<keepgoing>false</keepgoing>
			<rankOrder>ascending</rankOrder>
			<successOnEmptyNodeFilter>true</successOnEmptyNodeFilter>
			<threadcount>1</threadcount>
		</dispatch>
		<executionEnabled>true</executionEnabled>
		<group>${platform}</group>
		<loglevel>INFO</loglevel>
		<name>${jobname}</name>
		<nodeFilterEditable>false</nodeFilterEditable>
		<nodefilters>
			<filter>name: pral-haexp01.workit.fr:2222</filter>
		</nodefilters>
		<nodesSelectedByDefault>true</nodesSelectedByDefault>
		<retry delay="20s">2</retry>
		<schedule>
			<month month="*" />
			<time hour="${schedule_hour}" minute="${schedule_minute}" seconds="0" />
			<weekday day="*" />
			<year year="*" />
		</schedule>
		<scheduleEnabled>true</scheduleEnabled>
		<sequence keepgoing="false" strategy="node-first">
			  ${feed_command}
			  ${metrics_command}
		</sequence>
	</job>
</joblist>
EOF

# Dry Run version
dryrun="enabledryrun"
feed_command="<command><exec>bash launch_exporterv2.sh ${environement} ${platform} ${feed_name} ${dryrun} enablecache ${memory_set}</exec></command>"

cat > ${tmp_job_def_dryrun} <<EOF
<joblist>
	<job>
		<description/>
		<dispatch>
			<excludePrecedence>true</excludePrecedence>
			<keepgoing>false</keepgoing>
			<rankOrder>ascending</rankOrder>
			<successOnEmptyNodeFilter>true</successOnEmptyNodeFilter>
			<threadcount>1</threadcount>
		</dispatch>
		<executionEnabled>true</executionEnabled>
		<group>${platform}/DRYRUN</group>
		<loglevel>INFO</loglevel>
		<name>${jobname_dryrun}</name>
		<nodeFilterEditable>false</nodeFilterEditable>
		<nodefilters>
			<filter>name: pral-haexp01.workit.fr:2222</filter>
		</nodefilters>
		<nodesSelectedByDefault>true</nodesSelectedByDefault>
		<retry delay="20s">2</retry>
		<scheduleEnabled>false</scheduleEnabled>
		<sequence keepgoing="false" strategy="node-first">
			${feed_command}
		</sequence>
	</job>
</joblist>
EOF

#Now import in rundeck
export RD_URL=http://pral-rdk01.workit.fr:4440/api/14
export RD_TOKEN=yJHjyHmo0M4oe8sczSLRrG7bNCdv9GSd
echo "Creating standard feed job for ${feed_name} as ${jobname}"
rd jobs load -p Exporter --duplicate skip --file ${tmp_job_def} >/dev/null
if [ $? -ne 0 ]; then
  echo "Error while creating job."
  exit 1
fi

echo "Creating dryrun feed job for ${feed_name} as ${jobname_dryrun} - No Schedule"
rd jobs load -p Exporter --duplicate skip --file ${tmp_job_def_dryrun}  >/dev/null
if [ $? -ne 0 ]; then
  echo "Error while creating dryrun job."
  exit 1
fi

# End
rm ${tmp_job_def_dryrun} > /dev/null 2>&1
rm ${tmp_job_def} > /dev/null 2>&1

echo "Job created successfully."
exit 0
