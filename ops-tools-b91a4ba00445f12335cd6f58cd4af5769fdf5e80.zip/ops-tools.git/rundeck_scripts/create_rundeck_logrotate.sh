#!/bin/sh


#Ensure Log Rotate for Tomcat
sudo  -- sh -c 'printf "/var/log/rundeck/*.log {
    copytruncate
    rotate 14
    compress
    missingok
    size 500M
    }" > /etc/logrotate.d/rundeck'

exit \0
