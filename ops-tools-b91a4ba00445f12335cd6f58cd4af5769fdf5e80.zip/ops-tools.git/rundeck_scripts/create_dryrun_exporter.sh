#!/bin/bash
# Create Dryrun job for all existing jobs in EXPORTER PROJECT
RD_TOKEN="yJHjyHmo0M4oe8sczSLRrG7bNCdv9GSd"
RD_URL_BASE="http://pral-rdk01.workit.fr:4440"
RD_URL_14="${RD_URL_BASE}/api/14"
RD_URL_1="${RD_URL_BASE}/api/1"
#
# First Get all job ID
joblist=$(curl --request POST \
  --url ${RD_URL_14}/project/Exporter/jobs \
  --header 'Cache-Control: no-cache' \
  --header "x-rundeck-auth-token: ${RD_TOKEN}" \
  -s \
  | grep "<job id" | sed -e "s/<job id='\([^']*\)'.*/\1/")
if [ $? -ne 0 ]; then
  echo "Error getting job lists from Rundeck"
  exit 1
fi

for job in ${joblist}
do
  echo "Creating Dryrun for job id : ${job}"
  ./create_dryrun_for_job.sh "${job}"
done
