INSERT INTO mysql_slow_queries (query_id, catch_date, user, host, command, time, state, info)
SELECT *
FROM (
        SELECT ID, now(), USER, HOST, COMMAND, TIME, STATE, INFO
        FROM information_schema.PROCESSLIST
        WHERE TIME > 120 and INFO <> ""
) as running_slow_queries;
