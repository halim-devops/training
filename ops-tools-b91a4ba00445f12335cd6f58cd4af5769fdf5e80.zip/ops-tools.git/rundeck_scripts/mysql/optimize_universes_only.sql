optimize table universes;
