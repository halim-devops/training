/**
* Daily Script 3
**/
insert into matching_log_analysis (instances_id,
    identifiers_id ,
    created_date,
    created ,
    sku ,
    site_id ,
    catalog_product_id ,
    site_title ,
    first_matching_key ,
    first_matching_date ,
    first_matching_source ,
    matching_type)

SELECT
    instances.ID AS instances_ID,
    identifiers.ID AS identifiers_id,
    DATE(instances.CREATED) AS CREATED_DATE,
    instances.CREATED AS CREATED,
    identifiers.SKU AS SKU,
    identifiers.SID AS SID,
    identifiers.CPID AS identifiers_CPID,
    sites.TITLE AS site,
    first_match.matching_key as first_matching_key,
    first_match.match_date as first_matching_date,
    first_match.source as first_matching_source,
    case when first_match.type is not null then first_match.type else 'NOT_MATCHED' end AS matching_type
FROM
    site_product_instances AS instances
        JOIN
    site_product_identifiers AS identifiers ON instances.SITE_PRODUCT_IDENTIFIER_ID = identifiers.ID and instances.CREATED >= DATE_ADD( DATE_FORMAT(now(), '%Y-%m-%d 00:00:00') , interval -1 DAY ) and instances.CREATED and instances.CREATED  < DATE_FORMAT(now(), '%Y-%m-%d 00:00:00')
        JOIN
    sites ON sites.ID = identifiers.SID AND sites.DATE <= DATE_ADD( DATE_FORMAT(now(), '%Y-%m-%d 00:00:00') , interval -2 MONTH )
 LEFT JOIN
( SELECT
    instances.ID      AS ID,
    matching_log.matching_key,
    matching_log.match_date,
    matching_log.source,
    matching_log.success,
    CASE WHEN was_set_unmatchable = TRUE AND SOURCE ='MATCHING_TOOL' THEN 'SET_UNMATCHABLE_MANUAL'
        WHEN was_set_unmatchable = TRUE AND SOURCE !='MATCHING_TOOL' THEN 'SET_UNMATCHABLE_AUTOMATIC'
        WHEN matching_log.catalog_product_id IS NOT NULL THEN 'MATCH'
     END AS TYPE
FROM
    site_product_instances AS instances
JOIN
    matching_log
ON
    matching_log.site_product_instance_id = instances.id
WHERE
    instances.CREATED >=  DATE_ADD( DATE_FORMAT(now(), '%Y-%m-%d 00:00:00') , interval -1 DAY ) and instances.CREATED  < DATE_FORMAT(now(), '%Y-%m-%d 00:00:00')
AND matching_log.success=true
AND matching_log.id =
    (
        SELECT
            MIN(matching_log.id)
        FROM
            matching_log
        WHERE
            matching_log.site_product_instance_id = instances.id)) as first_match
on instances.id = first_match.id
where NOT EXISTS
    (
        SELECT
            1
        FROM
            site_product_instances AS old_instances
        JOIN
            site_product_identifiers AS old_identifiers
        ON
            old_instances.SITE_PRODUCT_IDENTIFIER_ID = old_identifiers.ID
        WHERE
            old_instances.CREATED < DATE_ADD( DATE_FORMAT(now(), '%Y-%m-%d 00:00:00') , interval -2 DAY )
        AND old_identifiers.SID = identifiers.SID
        AND old_identifiers.SKU = identifiers.SKU
        AND SKU != '');
