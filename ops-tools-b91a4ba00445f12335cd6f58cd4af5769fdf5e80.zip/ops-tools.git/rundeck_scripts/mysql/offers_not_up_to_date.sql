select 
sites.title as site, universes.title as univers, 
case sites.active_offer_datasources when 1 then 'W2P' when 2 then 'CP' else 'unknown' end as datasource,
case parent.id when universes.id then '' else parent.title end as parent_segment, concat(segment.title, ' (', segment.id, ')') as segment, 
max(inst.MODIFIED) as last_crawled_offer 
from 
site_product_identifiers ids 
join site_product_instances inst on inst.SITE_PRODUCT_IDENTIFIER_ID = ids.id 
join universes segment on segment.id = inst.pid 
join universes parent on parent.id = segment.pid 
join universes on universes.id = inst.rpid 
join sites on sites.id = ids.sid 
join site_types on site_types.id = sites.site_type_id 
where inst.DELETED = false 
and inst.MODIFIED < date_sub(now(), interval 5 day)
and site_types.name not in ("CATALOG", "NON STANDARD") 
group by sites.id, universes.id, segment.id;
