update site_product_identifiers ids left join catalog_product_identifiers cpids on ids.cpid = cpids.id set ids.cpid = -1, ids.ISMATCHABLE = true where cpids.id is null and ids.cpid > 0;
