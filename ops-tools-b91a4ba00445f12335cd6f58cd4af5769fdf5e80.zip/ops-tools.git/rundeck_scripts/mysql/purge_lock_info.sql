delete from MYSQL_TRX_LOCKS where trx_start < DATE_SUB(CURDATE(),INTERVAL 1 WEEK);
