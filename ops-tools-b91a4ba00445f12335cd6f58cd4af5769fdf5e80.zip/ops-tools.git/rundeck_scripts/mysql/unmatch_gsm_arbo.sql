UPDATE
 site_product_instances instances
INNER JOIN site_product_identifiers ids
     ON instances.site_product_identifier_id = ids.id
SET  ids.cpid = -1
WHERE instances.rpid = '30724' AND  ids.cpid>0;
