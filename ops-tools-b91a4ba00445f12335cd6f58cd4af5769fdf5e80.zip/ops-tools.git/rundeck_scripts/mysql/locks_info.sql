insert into MYSQL_TRX_LOCKS (lock_id,lock_trx_id,trx_start,user,host,lock_table,lock_mode,lock_query,count_locked_trx,locked_queries)
select *
from (
        SELECT INNODB_LOCKS.lock_id,
         locking_trx.TRX_ID as lock_trx_id,
         locking_trx.TRX_STARTED as trx_start,
         PROCESSLIST.USER ,
         PROCESSLIST.HOST,
         INNODB_LOCKS.LOCK_TABLE as locked_table,
         lock_mode,
         locking_trx.TRX_QUERY as lock_query
        , count(*) as count_locked_trx ,
         SUBSTRING(group_concat(distinct locked_trx.TRX_QUERY), 1, 20000) as locked_queries
        from information_schema.INNODB_LOCKS
        JOIN information_schema.INNODB_LOCK_WAITS on INNODB_LOCK_WAITS.BLOCKING_LOCK_ID = INNODB_LOCKS.LOCK_ID
        JOIN information_schema.INNODB_TRX as locking_trx on locking_trx.TRX_ID = INNODB_LOCKS.LOCK_TRX_ID
        JOIN information_schema.INNODB_TRX as locked_trx on locked_trx.TRX_ID = INNODB_LOCK_WAITS.REQUESTING_TRX_ID
        JOIN information_schema.PROCESSLIST on  PROCESSLIST.ID = locking_trx.TRX_MYSQL_THREAD_ID
        group by locking_trx.TRX_ID, INNODB_LOCKS.LOCK_TABLE, lock_mode
) as locking_trx;

