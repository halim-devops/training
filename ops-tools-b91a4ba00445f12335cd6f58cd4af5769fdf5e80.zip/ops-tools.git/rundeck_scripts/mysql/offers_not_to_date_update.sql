update site_product_instances join universes on universes.id = site_product_instances.pid and universes.CRAWLED=false set site_product_instances.deleted = true where site_product_instances.deleted=false;
update site_product_instances set deleted = true where not exists (select 1 from universes segment where segment.id = site_product_instances.pid) and deleted = false;
update site_product_instances set deleted = true where not exists (select 1 from universes segment where segment.id = site_product_instances.pid and segment.lft + 1 = segment.rgt) and deleted = false;
