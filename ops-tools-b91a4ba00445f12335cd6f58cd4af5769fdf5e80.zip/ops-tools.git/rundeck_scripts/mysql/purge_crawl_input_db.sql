SET FOREIGN_KEY_CHECKS=false;
truncate table crawl_input_data.crawl_connection_errors;
truncate table crawl_input_data.crawl_data_errors;
truncate table crawl_input_data.crawl_format_errors;
truncate table crawl_input_data.crawl_page_errors;
truncate table crawl_input_data.crawl_item_result;

delete from crawl_items, crawl_item_delivery_cost, crawl_identifier
using crawl_input_data.crawl_items
left join crawl_input_data.crawl_item_delivery_cost
       on crawl_item_delivery_cost.crawl_item_id = crawl_items.id
left join crawl_input_data.crawl_identifier
       on crawl_identifier.crawl_item_id = crawl_items.id
where  modified < DATE_ADD(now(), INTERVAL -45 DAY);

SET FOREIGN_KEY_CHECKS=true;
