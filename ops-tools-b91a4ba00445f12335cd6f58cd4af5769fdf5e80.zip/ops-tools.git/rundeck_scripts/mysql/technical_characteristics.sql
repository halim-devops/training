SELECT audit_date, login, action, root_catalog, catalog, reference, charac_type, previous_value, new_value
FROM characteristic_values_audit
WHERE audit_date >= DATE_SUB(now(), INTERVAL 1 day)
ORDER BY audit_date DESC;
