optimize table statistics_matching_progression;
delete from siteproduct_suggestions where date < DATE_ADD(CURDATE(), INTERVAL -2 DAY);
delete from logs_engine where analysisDate < DATE_ADD(CURDATE(), INTERVAL -60 DAY);
delete from statistics_matching_progression where date < DATE_ADD(CURDATE(), INTERVAL -30 DAY);
delete from logs_board where date < DATE_ADD(CURDATE(), INTERVAL -60 DAY);
delete from statistics_matching_site_only_progression where date < DATE_ADD(CURDATE(), INTERVAL -30 DAY);
delete from statistics_matching_marketplace_only_progression where date < DATE_ADD(CURDATE(), INTERVAL -30 DAY);
delete from trr_navigation where date < DATE_ADD(CURDATE(), INTERVAL -13 MONTH);
