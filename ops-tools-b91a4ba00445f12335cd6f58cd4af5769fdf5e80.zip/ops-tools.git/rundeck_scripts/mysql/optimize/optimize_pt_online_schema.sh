#!/bin/bash
HOST=$1
USER=$2
PASSWORD=$3
DATABASE=$4
LIST=$5
#
# Table must not have any triggers in order to work with pt-online-schema-change, else use mysql optimize table in SQL scripts
#
tables_list="$(curl $5)"
for tablename in $tables_list
do
	pt-online-schema-change --alter-foreign-keys-method auto --max-load "Threads_running=800" --critical-load "Threads_running=2400" -h ${HOST} --user ${USER} --password "${PASSWORD}" --alter="ENGINE=InnoDB" D=${DATABASE},t=${tablename} --execute
done


