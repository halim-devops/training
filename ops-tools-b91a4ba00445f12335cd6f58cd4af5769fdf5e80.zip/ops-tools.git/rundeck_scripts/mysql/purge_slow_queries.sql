delete from mysql_slow_queries where catch_date < DATE_SUB(CURDATE(),INTERVAL 1 WEEK);
