#!/bin/bash

FEED_DATA=/mnt/nas-ovh/Feed-Data

find ${FEED_DATA} -type f -mtime +15 -delete -ls;

exit 0
