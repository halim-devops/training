#!/bin/bash
ELKJOP_FTP_GET_SCRIPT_URL="http://gitlab.workit.fr/ops-team/ops-tools/raw/master/rundeck_scripts/elkjop_get_ftp.sh"
ELKJOP_REALTIME_SCRIPT_URL="http://gitlab.workit.fr/ops-team/ops-tools/raw/master/rundeck_scripts/elkjop_realtime.sh"
#
launch_curl_script_func_res=""
function launch_curl_script {
	launch_curl_script_func_res=0
	if [ "$1" == "" ]; then
		echo "Error missing parameter in launch_curl_script"
		launch_curl_script_func_res="1"	
	else
	    urlscript=$1
	    shift
	    echo "Parameter for target script: $@"
	    scriptname=$(basename $urlscript)
	    localscriptname=/tmp/$scriptname.${$}
	    echo "Downloading script $scriptname into temporary directory from $urlScript in $localscriptname"
	    curl -sS -L -o $localscriptname $urlscript
	    if [ ! -f $localscriptname ]; then
		echo "Error error while downloading script in launch_curl_script!"
		launch_curl_script_func_res="1"
	    else
		echo "Executing $localscriptname"
		/bin/bash $localscriptname $@
		launch_curl_script_func_rec=$?
		rm -f $localscriptname &> /dev/null
	    fi
	fi
}

launch_curl_script "${ELKJOP_FTP_GET_SCRIPT_URL}"
exit $launch_curl_script_func_res

