#!/bin/bash
dbuser=$1
export MYSQL_PWD="${2}"
query_url="$3"
dbhost="$4"
targetfile="$5"
dbname="$6"

PLATFORM=$(echo "${dbhost}" | sed -e 's/..\(..\).*/\1/')
fdbname="workit_${PLATFORM}_v4"
case "$PLATFORM" in
"fr")
  fdbname="workit_bgb_v4"
  ;;
"fa")
  fdbname="workit_fashion_v4"
  ;;
"ad")
  fdbname="workit_adhoc_v4"
  ;;
esac

if [ "$dbname" != "" ]; then
	echo "Overwriting DBNAME to $dbname"
	fdbname="$dbname";
else
	echo "DBNAME set to $fbname"
fi
	
sql_query=/tmp/query.sql.${$}
echo "Creating script: $sql_query"
curl -Ss -o $sql_query ${query_url}
if [ $? -ne 0 ]; then
    echo "ERROR cannot get SQL script from query_url : ${query_url}"
    exit 1
fi
echo "Ready to execute:"
echo "########################################"
cat $sql_query
echo "########################################"

MYSQL_OPTIONS=""
if [ "${targetfile}" != "NULL" ]; then
	echo "Executing script: /usr/bin/mysql -sN ${MYSQL_OPTIONS} --user=${dbuser} --host=${dbhost}  --database=${fdbname} --  <  $sql_query (${targetfile})"
	/usr/bin/mysql -sN ${MYSQL_OPTIONS} --user=${dbuser} --host=${dbhost}  --database=${fdbname} --  <  $sql_query > "${targetfile}"
else
	echo "Executing script: /usr/bin/mysql -sN ${MYSQL_OPTIONS} --user=${dbuser} --host=${dbhost}  --database=${fdbname} --  <  $sql_query"
	/usr/bin/mysql -sN ${MYSQL_OPTIONS} --user=${dbuser} --host=${dbhost}  --database=${fdbname} --  <  $sql_query
fi
exit $?
