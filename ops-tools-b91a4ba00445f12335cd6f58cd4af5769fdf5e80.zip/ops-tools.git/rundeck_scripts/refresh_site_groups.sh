#!/bin/bash
typeset -u w2p_u
for w2p in fr de ii uk ad fa it cg 
do  
    w2p_u=$w2p
    echo "Refresh site on $w2p_u"
    url="pr$w2p-wv4mat01.workit.fr:8080"
    curl http://${url}/json/syncSiteGroups.jsp
done
echo "Refresh site on TRUK"
curl http://truk-wv4mat01.workit.fr:8080/json/syncSiteGroups.jsp
