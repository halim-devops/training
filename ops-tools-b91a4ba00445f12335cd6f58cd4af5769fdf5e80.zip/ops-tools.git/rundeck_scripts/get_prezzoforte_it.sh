#!/bin/bash
#
BASE_DIR="/mnt/nas-e1-input"

IT_DIR="${BASE_DIR}/adhoc/IT_PREZZOFORTE_FEED"
IT_URL="https://www.prezzoforte.it/export_ac.php?token=d5e650edda31e2e768c9cedff5dfa91a2d935012"

echo "Processing file for PREZZOFORTE"

echo "Retrieving file from ${IT_URL}"
cd $IT_DIR
if [ $? -ne 0 ]; then
  echo "ERROR cannot go to $IT_DIR"
  exit 1
fi
ERROR=0
TARGET_FILENAME="feed_altroconsumo.xml"
curl -L -o ${TARGET_FILENAME} "${IT_URL}" > /dev/null 2>&1
if [ $? -ne 0 ]; then
  echo "ERROR cannot get file $TARGET_FILENAME"
  ERROR=1
fi

if [ $ERROR -eq 1 ]; then
  exit 1
fi
exit 0
