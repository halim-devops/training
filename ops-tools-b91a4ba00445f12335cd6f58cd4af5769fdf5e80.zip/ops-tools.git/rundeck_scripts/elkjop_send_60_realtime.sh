#!/bin/sh

logdate="$(date +%Y%m%d%H%M%S)"
logfile="/var/log/workit/ELKJOP_ftp_${logdate}.log"

echo "FTP_ELKJOP_SCRIPT STARTED: REALTIME 60 $(date)"

filedate="$(date +%Y%m%d)"

remote_host="217.28.206.200"
remote_user="workit"
remote_passwd="4WDxc9Nj"
remote_dir="in"

target_dir="/nas-e1-ftp/OUT/elkjop/realtime"

#
cd $target_dir
if [ $? -ne 0 ]; then
  echo "ERROR: cannot change directory to $target_dir !"
  exit 0
fi

beforeC=$(ls | wc -l)

echo "CONNECTING TO REMOTE SITE ${remote_host}"
ftp -v -n $remote_host <<END_SCRIPT
quote USER $remote_user
quote PASS $remote_passwd
bin
prompt
cd $remote_dir
mput *_60_*.csv
quit
END_SCRIPT

if [ $? -ne 0 ]; then
  echo "-- ERROR DURING FTP OPERATION."
  exit 0
fi

afterC=$(ls | wc -l)
delta=$((afterC - beforeC))
#if [ $delta -ne 8 ]; then
#  echo "ERROR: There is something wrong in my kingdom !"
#  exit 0
#fi



cd $target_dir
rm $target_dir/*60*.csv >/dev/null 2>&1
if [ $? -ne 0 ]; then
  echo "-- WARNING CANNOT REMOVE FILES"
  exit 0
fi

#zabbix_sender -z "pral-opszab.workit.fr" -p 10051 -s "freenas" -k "elkjop.15.status" -o "1"

echo "FTP_ELKJOP_SCRIPT SUCCESS: REALTIME 60 $(date)"
exit 0

