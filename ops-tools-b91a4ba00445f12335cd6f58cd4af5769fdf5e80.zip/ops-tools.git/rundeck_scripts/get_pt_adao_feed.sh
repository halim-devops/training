#!/bin/bash

#ADAO FTP
host_adao='ftp://adaodeco:iufl1zk@adao.pt/'
path_adao='/'
folder_adao='offer'


#NAS FTP
path_nas_adao="/nas-e1-ftp/WORKIT-INPUT/adhoc/PT_ADAO_FEED"

#PT
echo "Processing folder for ADAO"

echo "Retrieving folder from ADAO"

#Check if we can move to ADAO folder
cd $path_nas_adao
if [ $? -ne 0 ]; then
  echo "ERROR unable to move to $path_nas_adao"
  exit 1
fi
ERROR=0

#Delete old folder
#rm -rf ${folder_adao}

#Get pt file
wget -r -nH -nv ${host_adao}$path_adao
if [ $? -ne 0 ]; then
  echo "ERROR unable to get folder"
  ERROR=1
fi


exit 0