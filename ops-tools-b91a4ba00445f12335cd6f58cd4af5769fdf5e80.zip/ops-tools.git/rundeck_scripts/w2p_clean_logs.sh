#!/bin/sh


TOMCAT_LOG_FOLDER=/var/log/tomcat9/

LOG_FOLDER=/var/log/workit/w2p

#Ensure Log Rotate for Tomcat

sudo find ${TOMCAT_LOG_FOLDER}/ -type f -name "host-manager.*" -mtime +1 -exec rm {} \;
sudo find ${TOMCAT_LOG_FOLDER}/ -type f -name "manager.*" -mtime +1 -exec rm {} \;
sudo find ${TOMCAT_LOG_FOLDER}/ -type f -name "localhost.*" -mtime +3 -exec rm {} \;
sudo find ${TOMCAT_LOG_FOLDER}/ -type f -name "*.txt" -mtime +3 -exec rm {} \;
sudo find ${TOMCAT_LOG_FOLDER}/ -type f -name "*.log.gz" -mtime +7 -exec rm {} \;
sudo find ${TOMCAT_LOG_FOLDER}/ -type f -name "*.gz" -mtime +7 -exec rm {} \;

sudo find ${LOG_FOLDER}/process/ -type f -mtime +1 -exec rm {} \;
sudo find ${LOG_FOLDER}/process/ -type d -empty -delete \;
sudo find ${LOG_FOLDER}/app/ -type f -name "w2p-*" -mtime +1 -exec rm {} \;
sudo find ${LOG_FOLDER}/matching/automatching/ -type f -mtime +5 -exec rm {} \;
sudo find ${LOG_FOLDER}/matching/cp/ -type f -mtime +5 -exec rm {} \;
sudo find ${LOG_FOLDER}/matching/sp/ -type f -mtime +5 -exec rm {} \;

#Ensure Log Rotate for Tomcat
sudo  -- sh -c 'printf "/var/log/tomcat9/catalina.out {
    copytruncate
    rotate 7
    compress
    missingok
    size 500M
    }" > /etc/logrotate.d/tomcat'


exit \0
