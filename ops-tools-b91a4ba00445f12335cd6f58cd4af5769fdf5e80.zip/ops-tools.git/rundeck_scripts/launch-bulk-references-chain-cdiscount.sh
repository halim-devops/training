#!/bin/sh
#################################################################################
################### Lancement de la chaine bulk references ######################
#################################################################################
. /lib/lsb/init-functions

FILE=$(basename ${0})
FILE="${FILE%.*}"
BASE_DIR=$(dirname ${0})

DEFAULT_TARGET_DIR="/tmp"

if [ -z $CSV_EXT ]; then
  CSV_EXT="csv"
fi
#DEFAULT_FTP_IMPORT_FILE_DIR="/nas-e1-ftp/workit/fichier\ cdiscount"

# FILE TO REGISTER LAST IMPORTED FILE
LAST_IMPORTED_FILE_RECORD_NAME_PREFIX="conf/do_not_delete_me_"

# BATCHS TO LAUNCH
IMPORT_BULK_VALIDATOR_BATCH="/opt/workit/batchs/bulk-input-validator/execute-import-bulk-batch.sh"
CROSS_REFERENCER_BATCH="cross-reference-import.sh"

# LOGS DIRECTORY
LOG_DIRECTORY_BASE="/var/log/workit"


# ENVIRONMENT VARIABLES
PATH=/bin:/usr/bin:/sbin:/usr/sbin
#Si fail On Error est vrai quand un script échoue le processus terminer, ou il fait toutes les etapes
# ?? 
export JAVA_HOME=/usr/lib/jvm/jdk1.7.0_15

# OTHER VARIABLES TO INITIALIZE (depends on script parameters)
FAIL_ON_ERROR="true"

help(){
  cat <<HELP

${FILE} -- launch all the bulk-references chain.

The platform is supposed to be \$PLATFORM (no default value)
The customer is supposed to be named \$CUSTOMER_NAME (no default value)
The file to import is supposed to be named \$IMPORT_FILE_NAME_PATTERN-(date).$CSV_EXT (no default value). 
The file to import is supposed to be in the \$FTP_IMPORT_FILE_DIR (no default value).
The "batchs base" directory is supposed to be \$BATCH_BASE (by default $BASE_DIR)
The file to import will be copied in the \$TARGET_DIR (by default ${DEFAULT_TARGET_DIR}).
The launcher checks if a new file has arrived, if a new file is found, the whole process is launched, else nothing happens. 
/!\ Whitespaces in folder or file names shall be replaced with the "[[:space:]]" string  /!\

USAGE: ${FILE} [OPTIONS] [PLATFORM_ID] [CUSTOMER_NAME] [IMPORT_FILE_NAME_PATTERN] [FTP_IMPORT_FILE_DIR] [BATCH_BASE] [TARGET_DIR]

OPTIONS:
        -h this very help message

Example :
        # ${FILE} BGB_DEV ACUSTOMER import_file_name-* /import/file/dir /target/dir /opt/batchs

        import the file from customer "ACUSTOMER" on platform BGB_DEV:
        - check if there is a new file whose name matches "import_file_name-*.$CSV_EXT" in "/import/file/dir" folder. If no file is found, the process stopped, else
        - copy the last file named "import_file_name-*.$CSV_EXT" from "/import/file/dir" to "/target/dir"
	- launch the /opt/batchs/$IMPORT_BULK_VALIDATOR_BATCH batch with the following parameters: PLATFORM_ID=BGB_DEV CUSTOMER_NAME=ACUSTOMER BASE_DIR=/opt/batchs/bulk-input-validator BULK_IMPORT_FILES='/target/dir/import_file_name-*.$CSV_EXT'
        - record the imported file name in opt/batchs/bulk-input-validator/${LAST_IMPORTED_FILE_RECORD_NAME_PREFIX}CDISCOUNT
        - launch the /opt/batchs/$CROSS_REFERENCER_BATCH cross-references batch with the following parameters: PLATFORM_ID=BGB_DEV CUSTOMER_NAME=CDISCOUNT BASE_DIR=/opt/batchs/input-crawl-crossreferencing

HELP
  exit 0
}

error(){
    # print an error and exit
    log_failure_msg "`date` $1"
    exit 1
}

info(){
    # print an information message
    echo "`date` $1 \n"
}

# The option parser
# -h take no arguments
while [ -n "$1" ]; do
case $1 in
    -h) help;shift 1;; # function help is called
    --) shift;break;; # end of options
    -*) error "error: no such option $1. -h for help";exit 1;;
    *)  break;;
esac
done


# VARIABLES LOCALES
PLATFORM_ID="BGB_FR"
if [ -z "$PLATFORM_ID" ]; then
  error "PLATFORM_ID is not set"
fi
info "`date` PLATFORM_ID: $PLATFORM_ID "

CUSTOMER_NAME="CDISCOUNT"
if [ -z "$CUSTOMER_NAME" ]; then
  error "CUSTOMER_NAME is not set"
fi
info "`date` CUSTOMER_NAME: $CUSTOMER_NAME "

IMPORT_FILE_NAME_PATTERN='cdiscount_amazon_EAN_*'
if [ -z "$IMPORT_FILE_NAME_PATTERN" ]; then
  error "IMPORT_FILE_NAME_PATTERN is not set"
fi
echo "`date` IMPORT_FILE_NAME_PATTERN: $IMPORT_FILE_NAME_PATTERN "

FTP_IMPORT_FILE_DIR="/nas-e1-ftp/workit/fichier cdiscount"

if [ -z "$FTP_IMPORT_FILE_DIR" ]; then
  error "FTP_IMPORT_FILE_DIR is not set"
fi
info "`date` FTP_IMPORT_FILE_DIR: $FTP_IMPORT_FILE_DIR "

BATCH_BASE="/opt/workit/batchs"
if [ -z "$BATCH_BASE" ]; then
  info "BATCH_BASE is forced to ${BASE_DIR}"
  BATCH_BASE=${BASE_DIR}
fi
info "`date` BATCH_BASE: $BATCH_BASE "

TARGET_DIR="$6"
if [ -z "$TARGET_DIR" ]; then
  info "TARGET_DIR is forced to ${DEFAULT_TARGET_DIR}"
  TARGET_DIR=${DEFAULT_TARGET_DIR}
fi
info "`date` TARGET_DIR: $TARGET_DIR "

# LOGS DIRECTORY
IMPORT_BULK_VALIDATOR_LOG_FILE="$LOG_DIRECTORY_BASE/$(basename $IMPORT_BULK_VALIDATOR_BATCH)-$PLATFORM_ID-$CUSTOMER_NAME.log"
CROSS_REFERENCER_BATCH_LOG_FILE="$LOG_DIRECTORY_BASE/$CROSS_REFERENCER_BATCH-$PLATFORM_ID-$CUSTOMER_NAME.log"
# BATCHS_BASE
IMPORT_BULK_VALIDATOR_BATCH_BASE="$BATCH_BASE/bulk-input-validator"
CROSS_REFERENCER_BATCH_BASE="$BATCH_BASE/input-crawl-crossreferencing"


#errase that weirdness
cp /opt/workit/batchs/bulk-input-validator/conf/do_not_keep_me_CDISCOUNT /opt/workit/batchs/bulk-input-validator/conf/do_not_delete_me_CDISCOUNT 

# Check if a new file to import exists
info "`date` check if there is a new file to import..."
FTP_IMPORT_FILE_PATH="`ls -1r --file-type "${FTP_IMPORT_FILE_DIR}"/*.${CSV_EXT} | grep -m 1 $IMPORT_FILE_NAME_PATTERN`"
if [ -z "$FTP_IMPORT_FILE_PATH" ] || [ ! -s "$FTP_IMPORT_FILE_PATH" ]; then
  error "No file to import found in $FTP_IMPORT_FILE_DIR or the file size is 0 byte. \n Nothing to do see you tomorrow!"
  exit 1
fi
info "`date` FTP_IMPORT_FILE_PATH: $FTP_IMPORT_FILE_PATH"

NEW_IMPORT_FILE_NAME="${FTP_IMPORT_FILE_PATH#$FTP_IMPORT_FILE_DIR/}"
info "`date` NEW_IMPORT_FILE_NAME: '$NEW_IMPORT_FILE_NAME'"


# Copy the import file to target directory
info "`date` Moving '$FTP_IMPORT_FILE_PATH' to $TARGET_DIR"
cp "$FTP_IMPORT_FILE_PATH" "$TARGET_DIR"

TARGET_FILE_TO_IMPORT="$TARGET_DIR/$NEW_IMPORT_FILE_NAME"
info "`date` TARGET_FILE_TO_IMPORT: $TARGET_FILE_TO_IMPORT"

set -e

# OK Launch import-bulk-validator batch
info "`date` LAUNCHING $IMPORT_BULK_VALIDATOR_BATCH BATCH [platform=$PLATFORM_ID, CUSTOMER_NAME=$CUSTOMER_NAME, BATCH_BASE=$IMPORT_BULK_VALIDATOR_BATCH_BASE, FILE_TO_IMPORT=$TARGET_FILE_TO_IMPORT]... \n Logs can be found in $IMPORT_BULK_VALIDATOR_LOG_FILE file."

START_IMPORT_BULK_VALIDATOR_DATE=`date +%s`
$IMPORT_BULK_VALIDATOR_BATCH $PLATFORM_ID $CUSTOMER_NAME $IMPORT_BULK_VALIDATOR_BATCH_BASE $TARGET_FILE_TO_IMPORT >> $IMPORT_BULK_VALIDATOR_LOG_FILE
FAILED=$?
END_IMPORT_BULK_VALIDATOR_DATE=`date +%s`
echo "`date` End of $IMPORT_BULK_VALIDATOR_BATCH platform=$PLATFORM_ID failed=$FAILED failOnError=$FAIL_ON_ERROR in $(($END_IMPORT_BULK_VALIDATOR_DATE-$START_IMPORT_BULK_VALIDATOR_DATE)) ms"


if [ $FAIL_ON_ERROR = "true" ]; then
 if [ $FAILED != 0 ]; then
    error "`date` Script $IMPORT_BULK_VALIDATOR_BATCH failed."
    exit 1
  fi
fi

info "archiving imported file $TARGET_FILE_TO_IMPORT"
gzip $TARGET_FILE_TO_IMPORT
mv $TARGET_FILE_TO_IMPORT.gz $TARGET_FILE_TO_IMPORT.gz_$(date +%T) 
find /tmp -maxdepth 1 -mtime +1 -name 'cdiscount_amazon_EAN_*' -mtime +7 -exec rm -f {} \; 

# OK Launch cross referencer batch
info "`date` LAUNCHING $CROSS_REFERENCER_BATCH BATCH [platform=$PLATFORM_ID, CUSTOMER_NAME=$CUSTOMER_NAME, BATCH_BASE=$CROSS_REFERENCER_BATCH_BASE]... \n Logs can be found in $CROSS_REFERENCER_BATCH_LOG_FILE file."

START_CROSS_REFERENCER_DATE=`date +%s`
$CROSS_REFERENCER_BATCH_BASE/$CROSS_REFERENCER_BATCH $PLATFORM_ID $CUSTOMER_NAME $CROSS_REFERENCER_BATCH_BASE >> $CROSS_REFERENCER_BATCH_LOG_FILE
FAILED=$?
END_CROSS_REFERENCER_DATE=`date +%s`
echo "`date` End of $CROSS_REFERENCER_BATCH platform=$PLATFORM_ID failed=$FAILED failOnError=$FAIL_ON_ERROR in $(($END_CROSS_REFERENCER_DATE-$START_CROSS_REFERENCER_DATE)) ms"

if [ $FAILED != 0 ]; then
    error "`date` Script $CROSS_REFERENCER_BATCH failed."
    exit 1
fi

exit 0

