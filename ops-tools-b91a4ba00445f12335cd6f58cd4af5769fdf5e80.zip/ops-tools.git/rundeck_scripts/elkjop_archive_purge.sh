#!/bin/bash 

# FOR ARCHIVE ONLY NOT USED - DOES NOT WORK AS IS.

echo "Starting PURGE &JOBNAME# directory"

TGT_PATH=/nas-e1-ftp/IN/elkjop_realtime_&JOBNAME#/

# Test if Target Exists
if [ ! -d $TGT_PATH ]; then
  $ERRECHO "Error cannot create target directory $TGT_PATH."
  exit 1
fi

# Purge older archive > 1 day
find $TGT_PATH -maxdepth 1  -type f -ctime +1 -exec rm -rf {} \;
exit 0

