#!/bin/bash -x
# $1 : Date formatted as YYYYMMDD (20161102)
#

CURDATE=$(date +%d%m%Y)
SRCFILE="/data/output/cora/CORA-${CURDATE}.xml"

TGT_FILE_PATH="/SFTP_Provera/IN/"
CORA_SITE="81.80.135.243"

CORA_USER="workit"
## BAD BAD BAD
CORA_PASSWD="Gj57pk"

# Check if SSHPASS installed
sshpass >/dev/null 2>&1
if [ $? -ne 0 ]; then
  apt-get -y install sshpass >/dev/null 2>&1
  if [ $? -ne 0 ]; then
    echo "Error: not sshpass and can be installed." > 2
    exit 1
  fi
fi

# Get the file
if [ ! -f $SRCFILE ]; then
  echo "Error $SRCFILE not found."
  exit 1
fi


echo "Putting file ${SRCFILE} to ${CORA_SITE} in ${TGT_FILE_PATH}"

sshpass -p "${CORA_PASSWD}" sftp -vvv -oHostKeyAlgorithms=+ssh-dss -o StrictHostKeyChecking=no ${CORA_USER}@${CORA_SITE} <<EOF
cd ${TGT_FILE_PATH}
put ${SRCFILE}
EOF

if [ $? -ne 0 ]; then
        echo "Error with SFTP send."
        #exit 1
	exit 0
fi



exit 0

