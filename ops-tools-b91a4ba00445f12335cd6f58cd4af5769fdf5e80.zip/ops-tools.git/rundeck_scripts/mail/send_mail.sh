#!/bin/bash

_from="scheduler.PRODUCTION@workit-services.com"
_to="$1"
_file="$2"
_content_tmpl="$3"
_title="$4"
if [ "$_to" == "" ]; then
	echo "Missing recipient"
	exit 1
fi
attach=""
if [ "$_file" != "" ]; then
	attach="-a $_file"
fi
if [ "$_content_tmpl" != "" ]; then
	curl -sS -o /tmp/_content_tmpl_$$.html $_content_tmpl
else
	echo "Send by RUNDECK." > /tmp/_content_tmpl_$$.html
fi

if [ "$_title" == "" ]; then
	$_title="JOB RUNDECK - RESULT"
fi

cat /tmp/_content_tmpl_$$.html |  mutt $_to -s "$_title" $attach -e "my_hdr From: SCHEDULER <scheduler.PRODUCTION@workit-services.com>"   -e 'set content_type=text/html'
res=$?
rm -f /tmp/_content_tmpl_$$.html
exit $?

