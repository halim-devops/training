#!/bin/bash
#
BASE_DIR="/mnt/nas-e1-input"

BE_NL_DIR="${BASE_DIR}/adhoc/coolblue_feed/be_nl"
BE_NL_URL="http://feeds.performancehorizon.com/pramos/1011l124/cdd0a0df2767fef7d9f477eb34e93c55.xml"

BE_FR_DIR="${BASE_DIR}/adhoc/coolblue_feed/be_fr"
BE_FR_URL="http://feeds.performancehorizon.com/pramos/1011l124/5ad3f8b0afb269df5d3c3cdb2ee7c1d8.xml"

echo "Processing file for COOLBLUE"

echo "Retrieving file from ${BE_NL_URL}"
cd $BE_NL_DIR
if [ $? -ne 0 ]; then
  echo "ERROR cannot go to $BE_NL_DIR"
  exit 1
fi
ERROR=0
TARGET_FILENAME="cdd0a0df2767fef7d9f477eb34e93c55.xml"
curl -L -o ${TARGET_FILENAME} "${BE_NL_URL}" > /dev/null 2>&1
if [ $? -ne 0 ]; then
  echo "ERROR cannot get file $TARGET_FILENAME for BE/NL"
  ERROR=1
fi

echo "Retrieving file from ${BE_FR_URL}"
cd $BE_FR_DIR
if [ $? -ne 0 ]; then
        echo "ERROR cannot go to $BE_FR_DIR"
        exit 1
fi

TARGET_FILENAME="5ad3f8b0afb269df5d3c3cdb2ee7c1d8.xml"
curl -L -o ${TARGET_FILENAME} "${BE_FR_URL}" > /dev/null 2>&1
if [ $? -ne 0 ]; then
        echo "ERROR cannot get file $TARGET_FILENAME for BE/FR"
  ERROR=1
fi

if [ $ERROR -eq 1 ]; then
  exit 1
fi
exit 0

