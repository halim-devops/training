#!/bin/bash
#
BASE_DIR="/mnt/nas-e1-input"

BE_NL_DIR="${BASE_DIR}/adhoc/tradetracker_feed/bandenexpert_feed"
BE_NL_URL="http://pf.tradetracker.net/?aid=254612&encoding=utf-8&type=xml-v2&fid=1350588&categoryType=2&additionalType=2"

BE_FR_DIR="${BASE_DIR}/adhoc/BE_FR_BANDENEXPERT_FEED"
BE_FR_URL="http://pf.tradetracker.net/?aid=254627&encoding=utf-8&type=xml-v2&fid=1350588&categoryType=2&additionalType=2"

echo "Processing file for BANDENEXPERT"

echo "Retrieving file from ${BE_NL_URL}"
cd $BE_NL_DIR
if [ $? -ne 0 ]; then
  echo "ERROR cannot go to $BE_NL_DIR"
  exit 1
fi
ERROR=0
TARGET_FILENAME="productfeed.xml"
curl -L -o ${TARGET_FILENAME} "${BE_NL_URL}" > /dev/null 2>&1
if [ $? -ne 0 ]; then
  echo "ERROR cannot get file $TARGET_FILENAME for BE/NL"
  ERROR=1
fi

echo "Retrieving file from ${BE_FR_URL}"
cd $BE_FR_DIR
if [ $? -ne 0 ]; then
        echo "ERROR cannot go to $BE_FR_DIR"
        exit 1
fi

TARGET_FILENAME="productfeed.xml"
curl -L -o ${TARGET_FILENAME} "${BE_FR_URL}" > /dev/null 2>&1
if [ $? -ne 0 ]; then
        echo "ERROR cannot get file $TARGET_FILENAME for BE/FR"
  ERROR=1
fi

if [ $ERROR -eq 1 ]; then
  exit 1
fi
exit 0

