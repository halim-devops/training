#!/bin/sh
platform=$1
database=$2
target=$3
password=$4

logdate="$(date +%Y%m%d)"
logfile="/var/log/workit/StatsExp${platform}_${logdate}.log"

query="/var/lib/characteristics_stats/charac_stats_${platform}.sql"
result="charac_stats_${platform}.csv"

echo "statistics export ${platform} : Start"

cd /tmp

mysql --host=${target} --user=crawl-stats --password="${password}" ${database} < $query | sed 's/\t/;/g' > $result

chmod 0666 $result

echo "SQL_FR_SCRIPT SUCCESS: $(date)"
exit 0
