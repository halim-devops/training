#!/bin/bash
user=$1
password=$2

if [ "${user}" == "" ]; then
	echo "Missing username as parameter!"
	exit 1
fi

if [ "${password}" == "" ]; then
	echo "Missing password as parameter!"
	exit 1
fi

mongo --quiet -u ${user} -p "${password}" --authenticationDatabase admin --eval "db.stats();" crawl | grep "storageSize" | tail -n 1 | sed -r 's/.* ([0-9]*),.*/\1/g' > /opt/workit/dbstorage.prod.info
mongo --quiet -u ${user} -p "${password}" --authenticationDatabase admin --eval "db.jobs.stats();" crawl | grep "count" | head -n 1 | sed -r 's/.* ([0-9]*),.*/\1/g' > /opt/workit/dbjobs.prod.info
mongo --quiet -u ${user} -p "${password}" --authenticationDatabase admin --eval "db.offer_specifications.stats();" crawl | grep "count" | head -n 1 | sed -r 's/.* ([0-9]*),.*/\1/g' > /opt/workit/dbofferpec.prod.info

