#!/bin/bash

## INPUT ##


#echo "$@"

feed_name=$1
schedule_hour=$(printf "%02d\n" $2)
schedule_minute=$(printf "%02d\n" $3)
metrics=$4
user="opsservice"
password="0pss6rv1ce1"

error=0

if [ "$schedule_hour" == "" ]; then
  echo "Schedule Hour not defined."
  error=1
fi

if [ "$schedule_minute" == "" ]; then
  echo "Schedule Minute not defined."
  error=1
fi

if [ "$feed_name" == "" ]; then
  echo "Feed name not defined."
  error=1
fi

if [ $error -eq 1 ]; then
  exit 1
fi

###################

###################

jobname=""
if [ "${metrics}" == "yes" ]; then
  jobname="metrics_"
fi
jobname="${jobname}${feed_name}_${schedule_hour}h${schedule_minute}"
# Replace in feed name slash by underscore
jobname=$(echo "${jobname}" | sed -e 's/\//_/g')

item_action="rundeck.jobs.status[Exporter,${jobname}]"
feed_zabbix_name=$(echo $feed_name |sed -e 's/\// /g')

# Get Token ZABBIX_TOKEN

output=$(curl -s -X POST \
  http://pral-opszab.workit.fr/zabbix/api_jsonrpc.php/ \
  -H 'cache-control: no-cache' \
  -H 'content-type: application/json' \
  -d "{
    \"jsonrpc\": \"2.0\",
    \"method\": \"user.login\",
    \"params\": {
        \"user\": \"${user}\",
        \"password\": \"${password}\"
    },
    \"id\": 1,
    \"auth\": null
}")

if [ $? -ne 0 ]; then
  echo "Error while authenticating to zabbix"
  exit 1
fi
ZABBIX_TOKEN=$(echo $output | sed -e 's/.*"result":"\([^"]*\)".*/\1/')

echo "Creating Item for ${feed_name}."

output=$(curl -s -X POST \
  http://pral-opszab.workit.fr/zabbix/api_jsonrpc.php/ \
  -H 'cache-control: no-cache' \
  -H 'content-type: application/json' \
  -d "{
      \"jsonrpc\": \"2.0\",
      \"method\": \"item.create\",
      \"params\": {
          \"name\": \"JOB MONITOR: FLUX ${feed_zabbix_name}\",
          \"key_\": \"rundeck.jobs.status[Exporter,${jobname}]\",
          \"hostid\": \"11847\",
          \"type\": 0,
          \"value_type\": 0,
          \"interfaceid\": \"2199\",
          \"applications\": [
              \"38705\"
          ],
          \"delay\": 30
      },
      \"auth\": \"${ZABBIX_TOKEN}\",
      \"id\": 1
  }")



echo "Creating Trigger  for ${feed_name}."

output=$(curl -s -X POST \
  http://pral-opszab.workit.fr/zabbix/api_jsonrpc.php/ \
  -H 'cache-control: no-cache' \
  -H 'content-type: application/json' \
  -d "{
      \"jsonrpc\": \"2.0\",
      \"method\": \"trigger.create\",
      \"params\": {
          \"description\": \"JOB FAIL: FLUX ${feed_zabbix_name}\",
          \"expression\": \"{pral-monzab.workit.fr:rundeck.jobs.status[Exporter,${jobname}].last()}=-1\",
          \"priority\": \"5\"
      },
      \"auth\": \"${ZABBIX_TOKEN}\",
      \"id\": 1
  }")


echo "Zabbix updated successfully."
exit 0
