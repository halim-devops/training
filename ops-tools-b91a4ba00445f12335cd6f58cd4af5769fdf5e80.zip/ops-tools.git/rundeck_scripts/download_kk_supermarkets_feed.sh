#!/bin/bash -x
#
#
BASEURL="$1"
FILENAME="$2"
TARGETPATH="$3"

if [ ! -d $TARGETPATH ]; then
  echo "Error target directory does not exists !"
  exit 2
fi

if [ "X${FILENAME}" == "X" ]; then
  FILENAME="noname.gz"
fi


CURLBASE="curl"

TARGETURL="${BASEURL}"
echo -n "Getting $TARGETURL..."
cd $TARGETPATH
if [ $? -ne 0 ]; then
  echo "Error cannot change directory to ${TARGETPATH}"
  exit 3
fi

$CURLBASE -s -L -o ${FILENAME} ${TARGETURL}
if [ $? -eq 0 ]; then

  gzip -d -f ${FILENAME}
  if [ $? -ne 0 ]; then
    echo "Error decompressing."
  fi
  #rm ${FILENAME}
  echo "File available."
else
  echo "File not retrieve."
fi

