#!/usr/bin/env bash

RUNDECK_WEB=http://localhost:4440
RUNDECK_CHECK_LOG=/var/log/rundeck-check/rundeck-check.log

echo curl -o /dev/null --silent --max-time 15 --connect-timeout 15 --head --write-out '%{http_code}\n' $RUNDECK_WEB
STATUS=`curl -o /dev/null --silent --max-time 15 --connect-timeout 15 --head --write-out '%{http_code}\n' $RUNDECK_WEB`
echo $STATUS
if [ $STATUS -eq 200 ] || [ $STATUS -eq 302 ] ; then
    echo "$(date) - Rundeck Status 200/302 - OK. Not Restarting" >> $RUNDECK_CHECK_LOG
    break
else
    echo "$(date) - Rundeck Status $STATUS" >> $RUNDECK_CHECK_LOG
    sudo ps aux | grep java >> $RUNDECK_CHECK_LOG
    sudo netstat -anp >> $RUNDECK_CHECK_LOG
    echo "$(date) - Stopping Rundeck" >> $RUNDECK_CHECK_LOG
    echo `sudo service rundeckd stop ` >> $RUNDECK_CHECK_LOG
    sleep 1
    echo `sudo pkill -9 java ` >> $RUNDECK_CHECK_LOG
    echo "$(date) - Starting Rundeck" >> $RUNDECK_CHECK_LOG
    echo `sudo service rundeckd start ` >> $RUNDECK_CHECK_LOG
fi

