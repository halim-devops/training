#!/bin/bash
# Create Dryrun job for all existing jobs in EXPORTER PROJECT
RD_TOKEN="yJHjyHmo0M4oe8sczSLRrG7bNCdv9GSd"
RD_URL_BASE="http://pral-rdk01.workit.fr:4440"
RD_URL_14="${RD_URL_BASE}/api/14"
RD_URL_1="${RD_URL_BASE}/api/1"
RD_URL_18="${RD_URL_BASE}/api/18"
#
# First Get all job ID
jobidlist=$(curl --request POST \
  --url ${RD_URL_14}/project/Exporter/jobs \
  --header 'Cache-Control: no-cache' \
  --header "x-rundeck-auth-token: ${RD_TOKEN}" \
  -s | grep "<job id" | sed -e "s/<job id='\([^']*\)'.*/\1/")
if [ $? -ne 0 ]; then
  echo "Error getting job lists from Rundeck"
  exit 1
fi

cp /dev/null executionPlan.txt

for jobid in $jobidlist
do
  #Get Job info
  jobinfo=$(curl --request GET \
    --url ${RD_URL_18}/job/{$jobid}/info \
    --header 'Cache-Control: no-cache' \
    --header "x-rundeck-auth-token: ${RD_TOKEN}" -s)
  group=$(echo $jobinfo | sed -e 's/<group>\(.*\)<\/group>/\1/' | grep  -i -v dryrun | grep -i -v disabled)
  if [ "$group" != "" ]; then
    name=$(echo $jobinfo | sed -e 's/.*<name>\(.*\)<\/name>.*/\1/')

    echo $jobinfo | grep 'scheduleEnabled="true"' > /dev/null 2>&1
    scheduleEnable=$?
    echo $jobinfo | grep 'scheduled="true"' > /dev/null 2>&1
    scheduled=$?
    echo $jobinfo | grep "averageDuration" > /dev/null 2>&1
    averageDuration=$?
    echo $jobinfo | grep "nextScheduledExecution" > /dev/null 2>&1
    nextScheduleExecution=$?



    if [ $scheduleEnable -eq 0 -a $scheduled -eq 0 ]; then
      # Scheduled enable
      if [ $averageDuration -eq 0 -a $nextScheduleExecution -eq 0 ]; then
        jobduration=$(echo $jobinfo | sed -e 's/.*averageDuration="\([^"]*\)\".*/\1/')
        nextschedule=$(echo $jobinfo | sed -e 's/.*nextScheduledExecution="\([^"]*\)\".*/\1/')
        jobduration_s=$(( jobduration / 1000 ))
        jobschedule=$(echo $nextschedule | sed -e 's/.*\(..:..\):\(..\).*/\1/')
        #printf -vch  "%${jobduration_s}s" ""
        # $(printf "%s\n" "${ch// /#}")
        echo "$name;$jobduration_s;$jobschedule" |tee -a executionPlan.txt
      fi
    fi
  fi
done
echo "###"
cat executionPlan.txt | sort -t ';' -k 3 > executionPlan.sorted
