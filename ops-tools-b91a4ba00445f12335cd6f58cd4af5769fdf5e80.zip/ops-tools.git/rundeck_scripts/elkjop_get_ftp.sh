#!/bin/sh

logdate="$(date +%Y%m%d%H%M%S)"
logfile="/var/log/workit/ELKJOP_ftp_${logdate}.log"

echo "FTP_ELKJOP_SCRIPT STARTED: $(date)"

filedate="$(date +%Y%m%d)"

remote_host="217.28.206.200"
remote_user="workit"
remote_passwd="4WDxc9Nj"
remote_dir="out"

target_dir="/nas-e1-ftp/IN/exportelkjop/"

#
cd $target_dir
if [ $? -ne 0 ]; then
  echo "ERROR: cannot change directory to $target_dir !"
  exit 0
fi

beforeC=$(ls | wc -l)

echo "CONNECTING TO REMOTE SITE ${remote_host}"
ftp -n $remote_host <<END_SCRIPT
quote USER $remote_user
quote PASS $remote_passwd
bin
prompt
cd $remote_dir
mget *
quit
END_SCRIPT

afterC=$(ls | wc -l)
delta=$((afterC - beforeC))
if [ $delta -ne 8 ]; then
  echo "ERROR: There is something wrong in my kingdom !"
  exit 0
fi

echo "CONNECTING TO REMOTE SITE ${remote_host} (DEL)"
ftp -v -n $remote_host <<END_SCRIPT
quote USER $remote_user
quote PASS $remote_passwd
prompt
cd $remote_dir
mdel *
quit
END_SCRIPT


if [ $? -ne 0 ]; then
  echo "-- ERROR DURING FTP OPERATION."
  exit 0
fi
echo "FTP_ELKJOP_SCRIPT SUCCESS: $(date)"
exit 0
