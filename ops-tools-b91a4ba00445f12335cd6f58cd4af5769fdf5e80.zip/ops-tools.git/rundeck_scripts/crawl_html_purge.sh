#!/bin/bash

echo "CPPurge Script"
TARGET=$1
if [ "$TARGET" == "" ]; then
        echo "Missing Argument!"
        exit 1
fi

LOG="/var/log/$TARGET-$(date +%Y%m%d).log"
echo "Purge starting at $(date +%H%M)" >> $LOG
#find /mnt/html_pages/CPPROD -maxdepth 1 -type d -mtime +1 | grep -v ".zfs" | xargs -n 50 rm -r
#EXIT=$?

DIRECTORY=/mnt/html_pages/$TARGET
DATED_DIRECTORY=$(date --date="7 days ago" "+%Y%m%d")
echo "Purging directory $DATED_DIRECTORY in $DIRECTORY" >> $LOG
if [ -d $DIRECTORY/$DATED_DIRECTORY ]; then
        rm -rf $DIRECTORY/$DATED_DIRECTORY
        EXIT=$?

        echo "Purge exit code : $EXIT" >> $LOG
else
        echo "Nothing to purge. " >> $LOG
fi

echo "Purge ending at $(date +%H%M)" >> $LOG

find /var/log/ -name "$TARGET-*" -type f -mtime +14 -delete

exit $EXIT

