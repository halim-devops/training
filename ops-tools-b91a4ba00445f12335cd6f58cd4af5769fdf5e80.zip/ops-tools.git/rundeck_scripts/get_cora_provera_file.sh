#!/bin/bash
# $1 : Date formatted as YYYYMMDD (20161102)
#
DATE_FILE=$1
DATE_FILE=${DATE_FILE:=$(date "+%Y%m%d")}

echo "Working with $DATE_FILE"

GET_FILE="exportxml${DATE_FILE}.xml"
echo "About to get $GET_FILE"
GET_FILE_PATH="/SFTP_Provera/OUT/"
echo "In directory $GET_FILE_PATH"
#PUT_FILE_PATH_WT="/nas-e1-ftp/WORKIT-INPUT/fr/cora/"
PUT_FILE_PATH_WT="/mnt/nas-e1-input/fr/cora/"
CORA_SITE="81.80.135.243"
echo "ON client Site $CORA_SITE"


CORA_USER="workit"
## BAD BAD BAD
CORA_PASSWD="Gj57pk"

# Check if SSHPASS installed
sshpass >/dev/null 2>&1
if [ $? -ne 0 ]; then
	apt-get -y install sshpass >dev/null 2>&1
	if [ $? -ne 0 ]; then
		echo "Error: not sshpass and can be installed." > 2
		exit 1
	fi
fi

# Get the file
cd /tmp

echo "Getting file ${GET_FILE} from ${CORA_SITE}"

sshpass -p "${CORA_PASSWD}" sftp -o StrictHostKeyChecking=no ${CORA_USER}@${CORA_SITE} >/dev/null 2>&1 << EOF
cd ${GET_FILE_PATH}
get ${GET_FILE}
EOF

if [ ! -f ${GET_FILE} ]; then
	echo "Error: File not found on target site (${GET_FILE_PATH}${GET_FILE}." > 2
	exit 1
fi

# Move the file the nas
echo "Moving ${GET_FILE}to ${PUT_FILE_PATH_WT}."
mv /tmp/${GET_FILE} ${PUT_FILE_PATH_WT}
if [ $? -ne 0 ]; then
	echo "Error: Cannot move file ${GET_FILE} in ${PUT_FILE_PATH_WT}." > 2
	exit 1
fi
chmod 777 ${PUT_FILE_PATH_WT}${GET_FILE}

echo "Operation successful."
exit 0
