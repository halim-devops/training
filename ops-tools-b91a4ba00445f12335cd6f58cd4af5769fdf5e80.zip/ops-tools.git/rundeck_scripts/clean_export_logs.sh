#!/bin/bash


EXPORTER_DATA=/mnt/nas-ovh/EXPORTER

find ${EXPORTER_DATA}/PROD/ -type f -mtime +7 -exec rm {} \;
find ${EXPORTER_DATA}/QA/ -type f -mtime +3 -exec rm {} \;


exit 0
