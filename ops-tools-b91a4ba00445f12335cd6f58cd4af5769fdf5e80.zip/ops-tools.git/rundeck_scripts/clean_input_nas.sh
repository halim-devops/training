#!/bin/bash
CUSTOMERLIST=$1
FTP_OUT=$2
if [ "$FTP_OUT" != "" ]; then
	if [ "$CUSTOMERLIST" != "" ]; then
		curl -o /tmp/customer.list -L $CUSTOMERLIST
		if [ $? -ne 0 ]; then	
			echo "Error getting list from $CUSTOMERLIST"
			exit 1
		fi
		for customerline in $(cat /tmp/customer.list)
		do
			echo "Purging in $platform customer $customer ($delay)"
			platform=$(echo $customerline | cut -d':' -f1)
			customer=$(echo $customerline | cut -d':' -f2)
			delay=$(echo $customerline | cut -d':' -f3)
		
			find ${FTP_OUT}/$platform/$customer -type f -mtime +${delay} -ls -delete
		done
	else
		echo "Customer list URL not provided"
		exit 1
	fi
else
	echo "FTP OUT directory not provided."
	exit 1
fi
exit 0
