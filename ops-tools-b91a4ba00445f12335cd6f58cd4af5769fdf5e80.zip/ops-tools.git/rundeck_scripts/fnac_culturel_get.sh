#!/bin/sh
# JDB: 07/11/2016 - Added Error management

echo "FTP_FNAC_SCRIPT STARTED: $(date)" >> /var/log/workit/fnac_ftp.log

#if [ "X$1" != "X" ]; then
  #importday="$1"
#else
  importday=$(date +"%d%m%Y")
#fi

#importday=$(date --date="$dropday" -d "-2 day" +"%d%m%Y")
#dropday=$(date --date="$dropday" -d "-2 day" +"%d%m%Y")
if [ "X$1" != "X" ]; then
  dropday="$1"
else
  dropday=$(date +"%d%m%Y")
fi

cd /tmp

fnac_dropfile_compressed="Fnac-Culturel-$dropday.xml.gz"
fnac_dropfile="Fnac-Culturel-$dropday.xml"
fnac_importfile="Fnac-Culturel-$importday.xml"

#FNAC FTP
host_fnac='ftp-01.fnac.com'
user_fnac='exp-workit'
pass_fnac='scLJO88qkW'
cultural_folder='/cultural/'

#EROS FTP
host_eros='in.w2p.workit.fr'
user_eros='affiliation'
pass_eros='W7iX9nb4'
dropfolder_eros="/fichier\ fnac/culturel/"

#Retrieving FNAC zipped feed
wget -nv ftp://$user_fnac:$pass_fnac@$host_fnac$cultural_folder$fnac_dropfile_compressed

echo "-- RETRIEVED FILE FROM FNAC FTP: DONE" >> /var/log/workit/fnac_ftp.log

if [ ! -f $fnac_dropfile_compressed ]; then
  echo "-- ERROR FILE FROM FNAC WAS NOT RETRIEIVE. CHECK FNAC."
  exit 1
fi

#Extraction & renaming
gunzip -f $fnac_dropfile_compressed
if [ $? -ne 0 ]; then
  echo "-- ERROR WHILE UNCOMPRESSING FILE $fnac_dropfile_compressed."
  exit 2
fi
if [ ! -f $fnac_importfile ]; then
  mv $fnac_dropfile $fnac_importfile 2>> /var/log/workit/fnac_ftp.log
  if [ $? -ne 0 ]; then
    echo "-- ERROR WHILE MOVIN FILE $fnac_dropfile to $fnac_importfile."
    exit 3
  fi
fi

#Upload on EROS
ftp -n $host_eros <<END_SCRIPT
quote USER $user_eros
quote PASS $pass_eros
cd $dropfolder_eros
put $fnac_importfile
quit
END_SCRIPT
if [ $? -ne 0 ]; then
  echo "-- ERROR DURING FTP OPERATION."
  exit 4
fi
rm -rf $fnac_importfile

echo "FTP_FNAC_SCRIPT SUCCESS: $(date)"

exit 0

