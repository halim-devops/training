#!/bin/bash
if [ "$1" == "" ]; then
    echo "Error missing URL parameter"
else
    urlscript=$1
    shift
    echo "Parameter for target script: $@"
    scriptname=$(basename $urlscript)
    localscriptname=/tmp/$scriptname.${$}
    echo "Downloading script $scriptname into temporary directory from $urlScript in $localscriptname"
    curl -sS -L -o $localscriptname $urlscript
    if [ ! -f $localscriptname ]; then
        echo "Error error while downloading script !"
    else
        echo "Executing $localscriptname"
        /bin/bash $localscriptname $@
        ret=$?
        rm -f $localscriptname
        exit $ret
    fi
fi

