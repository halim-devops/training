#!/bin/bash


FTP_OUT_REPOSITORY=/mnt/nas-ovh/FTP-Data/OUT/showroom

cd ${FTP_OUT_REPOSITORY}/$1
echo "Executing: find ${FTP_OUT_REPOSITORY}/$1 -type f -mtime $2  -ls -delete"
find ${FTP_OUT_REPOSITORY}/$1 -type f -mtime $2  -ls -delete
exit 0
