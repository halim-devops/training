#!/bin/bash

FTP_OUT_REPOSITORY=/mnt/nas-ovh/FTP-Data/OUT/

find ${FTP_OUT_REPOSITORY}/hp -type f -mtime +15 ! -path '*historical*' -exec rm {} \;

find ${FTP_OUT_REPOSITORY}/hp -type f -mtime +60 -path '*historical*' -exec rm {} \;

exit 0
