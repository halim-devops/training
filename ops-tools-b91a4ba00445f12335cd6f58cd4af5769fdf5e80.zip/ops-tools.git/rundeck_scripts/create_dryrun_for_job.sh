#!/bin/bash
job_id=$1

if [ "$job_id" == "" ]; then
  echo "Usage: $0 <rundeck_id>"
  exit 1
fi

RD_TOKEN="yJHjyHmo0M4oe8sczSLRrG7bNCdv9GSd"
RD_URL_BASE="http://pral-rdk01.workit.fr:4440"
RD_URL_14="${RD_URL_BASE}/api/14"
RD_URL_1="${RD_URL_BASE}/api/1"

PROJECT="Exporter"

job_info=$(curl -s --request GET \
  --url "${RD_URL_1}/job/${job_id}" \
  --header 'Cache-Control: no-cache' \
  --header 'Content-Type: application/json' \
  --header "x-rundeck-auth-token: yJHjyHmo0M4oe8sczSLRrG7bNCdv9GSd")

echo "For job with id : ${job_id}:"
# Get Group / Name and EXEC (no metrics)
group=$(echo "${job_info}" |grep -i "<group>" | sed -e 's/<group>\(.*\)<\/group>/\1/'| sed -e 's/^[ \t]*//')
echo "Found $group as group."
jobname_dryrun=$(echo "${job_info}" |grep -i "<name>" | sed -e 's/<name>\(.*\)<\/name>/\1/' | sed -e 's/^[ \t]*//')
echo "Found $jobname_dryrun as job name."

echo "${jobname_dryrun}" | grep -v "dryrun" > /dev/null 2>&1
if [ $? -ne 0 ]; then
  echo "Already a dryrun"
  echo
  echo
  exit 0
fi


jobname_dryrun=$(echo ${jobname_dryrun} | sed -e 's/^\(.*\)_[0-9]*h.*/\1/' |sed -e 's/metrics_//g')_dryrun
echo "New job for dryrun will be $jobname_dryrun"

feed_command=$(echo "${job_info}" |grep -i "<exec>" | head -1 | grep -i "launch_exporter" | sed -e 's/^[ \t]*//')
#echo "${feed_command}"

feed_command=$(echo "${feed_command}" | grep -v "enabledryrun" | sed -e 's/^<exec>\(.*\)<\/exec>$/\1/' | sed 's/disabledryrun/enabledryrun/g' )
#echo "${feed_command}"
if [ "$feed_command" == "" ]; then
  echo "No command or already a dryrun command. No action."
  echo
  echo
  exit 0
fi
echo "Before: $feed_command"
feed_command=$(echo "$feed_command" | sed -e 's/^bash launch_exporter.sh \(.*\)\/mnt.*$/bash launch_exporterv2 \1/')
echo "After: $feed_command"

echo "${feed_command}" | grep "enabledryrun" > /dev/null 2>&1
if [ $? -ne 0 ]; then
  feed_command="${feed_command}enabledryrun"
fi

feed_command="<command><exec>${feed_command}</exec></command>"


# Dry Run version
dryrun="enabledryrun"
tmp_job_def_dryrun="/tmp/temporary_job_${jobname}.dryrun.$$.xml"

cat > ${tmp_job_def_dryrun} <<EOF
<joblist>
	<job>
		<description/>
		<dispatch>
			<excludePrecedence>true</excludePrecedence>
			<keepgoing>false</keepgoing>
			<rankOrder>ascending</rankOrder>
			<successOnEmptyNodeFilter>true</successOnEmptyNodeFilter>
			<threadcount>1</threadcount>
		</dispatch>
		<executionEnabled>true</executionEnabled>
		<group>${group}/DRYRUN</group>
		<loglevel>INFO</loglevel>
		<name>${jobname_dryrun}</name>
		<nodeFilterEditable>false</nodeFilterEditable>
		<nodefilters>
			<filter>name: pral-haexp01.workit.fr:2222</filter>
		</nodefilters>
		<nodesSelectedByDefault>true</nodesSelectedByDefault>
		<retry delay="20s">2</retry>
		<scheduleEnabled>false</scheduleEnabled>
		<sequence keepgoing="false" strategy="node-first">
			${feed_command}
		</sequence>
	</job>
</joblist>
EOF

#Now import in rundeck
export RD_URL=http://pral-rdk01.workit.fr:4440/api/14
export RD_TOKEN=yJHjyHmo0M4oe8sczSLRrG7bNCdv9GSd
echo "Creating dryrun feed job ${jobname_dryrun} - No Schedule"
cat ${tmp_job_def_dryrun} >> result.txt
#rd jobs load -p Exporter --duplicate skip --file ${tmp_job_def_dryrun}  #>/dev/null
if [ $? -ne 0 ]; then
  echo "Error while creating dryrun job."
  echo
  echo
  exit 1
fi
echo
echo
# End
rm ${tmp_job_def_dryrun} > /dev/null 2>&1
