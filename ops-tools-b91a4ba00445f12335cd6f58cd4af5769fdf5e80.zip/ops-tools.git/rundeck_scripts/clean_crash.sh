#!/bin/bash

APP_DATA_DOWNLOAD=/mnt/nas-ovh/CRASH

find ${APP_DATA_DOWNLOAD}/ -type f -mtime +1 -ls -delete

exit 0
