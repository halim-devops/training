#!/bin/sh

sed  -i 's|https://tracker-retail.workit|http://tracker-retail-qa.workit|' /var/www/tracker-retail/background.js
service apache2 restart