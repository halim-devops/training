#!/bin/sh

logdate="$(date +%Y%m%d)"
logfile="/var/log/workit/StatsExp_${logdate}.log"

tar="charac_stats_$(date +%Y-%m-%d).tar.gz"
nas="/nas-e1-ftp/"

echo "statistics export : Start"

cd /tmp

tar cvzf $tar *.csv
echo "File Compressed : OK"

rm /tmp/*.csv

chmod 0666 $tar

mv $tar $nas
echo "File $tar Moved"

chmod 0666 $nas$tar

echo "EXPORT_SCRIPT SUCCESS: $(date)"
exit 0
