#!/bin/bash
#
#
EXTCT="$1"
BASEURL="$2"
TARGETPATH="$3"
DEBUG=0
PASSWORDURL="http://gitlab.workit.fr/ops-team/ops-tools/raw/master/rundeck_scripts/passwordfile.${EXTCT}"
PASSWORDFILE="/tmp/passwordfile.$$.${EXTCT}"
#
Get password file from git
curl -o $PASSWORDFILE $PASSWORDURL
if [ $? -ne 0 ]; then
	echo "Error cannot retrieve password ! "
	exit 1
fi

if [ ! -f $PASSWORDFILE ]; then
  echo "Error not password file found : $PASSWORDFILE"
  exit 1
fi

echo "Password file retrieved."

if [ ! -d $TARGETPATH ]; then
  echo "Error target directory does not exists !"
  exit 2
fi

FEEDLIST="/tmp/afeeds.${EXTCT}.$(date +%Y%m%d%H%M%S)"
FILE2RET="/tmp/file2ret.${EXTCT}.$(date +Y%m%d%H%M%S)"

CURLBASE="curl --netrc-file $PASSWORDFILE -X GET --digest"
CURLBASE_URL="$CURLBASE ${BASEURL}/datafeed/"

# Get all file
${CURLBASE_URL}listFeeds | grep -oE "href='.?[^<>]*'>[^<>]+" | cut -d'>' -f1 | sed "s/^href='//g" | sed "s/'$//g" | grep -i -v "xml" | grep "standardized" | grep -E "(baby|camera|_ce_|home|kitchen|large_appliances|pc)" | grep  -E "(retail|mp|all).csv" > $FILE2RET
if [ $? -ne 0 ]; then
  echo "Error cannot get source list."
  exit 1
fi
echo "Working in $TARGETPATH."

count=1
len=$(cat $FILE2RET |wc -l)
echo "$len files to retrieve from remote host."

echo "Start of download operations. $(date)"

for file in $(cat $FILE2RET)
do
  TARGETURL="${BASEURL}/datafeed/$file"
  echo "Getting $TARGETURL... $count / $len"
  TARGETFILE=$(echo $file | sed -e 's/^.*=\(.*\)$/\1/g')
  if [ $DEBUG -eq 1 ]; then
    echo "DEBUG: Will get the file below"
    echo $CURLBASE -s -L -o ${TARGETPATH}${TARGETFILE} ${TARGETURL}
  else
    $CURLBASE -s -L -o ${TARGETPATH}${TARGETFILE} ${TARGETURL}
    if [ $? -eq 0 ]; then
      echo "File ${TARGETFILE} downloaded."
    else
      echo "File ${TARGETFILE} not retrieved."
    fi
  fi
  count=$((count+1))
done
rm ${PASSWORDFILE} >/dev/null 2>&1
echo "End of download. $(date)"

# Unzip now all files
echo "Starting uncompress operations : $(date)"
cd $TARGETPATH
for file in $(ls *.gz)
do
  gzip -df $file
  if [ $? -ne 0 ]; then
    echo "ERROR uncompressing file $file."
  fi
done
echo "End of uncompress operation.($date)"

if [ $DEBUG -eq 0 ]; then
  rm $FILE2RET $FEEDLIST
fi
exit 0
