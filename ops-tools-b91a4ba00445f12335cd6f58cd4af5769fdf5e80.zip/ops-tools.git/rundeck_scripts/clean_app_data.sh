#!/bin/bash

APP_DATA_DOWNLOAD=/mnt/nas-ovh/APP-Data/w2p
APP_DATA_CRAWL=/mnt/nas-ovh/APP-Data/crawl

find ${APP_DATA_DOWNLOAD}/DE -type f -mtime +1 -ls -delete
find ${APP_DATA_DOWNLOAD}/FR -type f -mtime +1 -ls -delete
find ${APP_DATA_DOWNLOAD}/II -type f -mtime +1 -ls -delete
find ${APP_DATA_DOWNLOAD}/IT -type f -mtime +1 -ls -delete
find ${APP_DATA_DOWNLOAD}/UK -type f -mtime +1 -ls -delete 
find ${APP_DATA_DOWNLOAD}/ADHOC -type f -mtime +1  -ls -delete
find ${APP_DATA_DOWNLOAD}/FA -type f -mtime +1 -ls -delete 

find ${APP_DATA_DOWNLOAD}/QA/FR -type f -mtime +1 -ls -delete
find ${APP_DATA_DOWNLOAD}/QA/II -type f -mtime +1 -ls -delete 
find ${APP_DATA_DOWNLOAD}/QA/UK -type f -mtime +1 -ls -delete 
find ${APP_DATA_DOWNLOAD}/STATS/matching -type f -mtime +7 -ls -delete

find ${APP_DATA_CRAWL}/showroom -type f -mtime +30 -ls -delete
#find ${APP_DATA_CRAWL}/showroom/ -type d -mtime +30 -ls -delete

find ${APP_DATA_CRAWL}/adhoc -type f -mtime +30 -ls -delete
#find ${APP_DATA_CRAWL}/adhoc/ -type d -mtime +30 -ls -delete

find ${APP_DATA_CRAWL}/error_pages -type f -mtime +3 -ls -delete

exit 0
