#!/bin/bash
#!/bin/bash
user=$1
password=$2

if [ "${user}" == "" ]; then
	echo "Missing username as parameter!"
	exit 1
fi

if [ "${password}" == "" ]; then
	echo "Missing password as parameter!"
	exit 1
fi


export MYSQL_PWD=$password

PLATFORM=$(hostname | sed -e 's/..\(..\).*/\1/')
BGB_DB_NAME="workit_${PLATFORM}_v4"
case "$PLATFORM" in
"fr")
  BGB_DB_NAME="workit_bgb_v4"
  ;;
"fa")
  BGB_DB_NAME="workit_fashion_v4"
  ;;
"ad")
  BGB_DB_NAME="workit_adhoc_v4"
  ;;
esac

/usr/bin/mysql -sN --silent --user=${user}  --database=${BGB_DB_NAME}  --execute='SELECT COUNT(*) FROM site_product_instances;' > /opt/workit/site_product_instances.sizing.info
/usr/bin/mysql -sN --silent --user=${user}  --database=${BGB_DB_NAME}  --execute='SELECT COUNT(*) FROM catalog_product_identifiers;' > /opt/workit/catalog_product_identifiers.sizing.info
/usr/bin/mysql -sN --silent --user=${user}  --database=${BGB_DB_NAME}  --execute="SELECT Round(Sum(data_length + index_length) / 1024 / 1024, 1) FROM   information_schema.tables  WHERE table_schema = '${BGB_DB_NAME}' GROUP  BY table_schema;" > /opt/workit/db_size.sizing.info
