#!/bin/bash

FTP_HOME=/data/ftp

if [[ $# -lt 1 ]]; then
    echo "Usage: `basename $0` username"
    exit 1
fi

if [[ $UID != 0 ]]; then
    echo "This script requires sudo privileges."
    echo "sudo $0 $*"
    exit 1
fi

USER="$1"
DIRECTORY="$2"

if [ "$DIRECTORY" == "" ]; then
	DIRECTORY="${USER}"
fi

if [ ! -d ${FTP_HOME}/${DIRECTORY} ]; then
  echo "Creating directory ${FTP_HOME}/${DIRECTORY} for user ${USER}."
  mkdir ${FTP_HOME}/${DIRECTORY}
else
  echo "Directory ${FTP_HOME}/${DIRECTORY} already exists."
fi
chown -R vsftpd:nogroup ${FTP_HOME}/${DIRECTORY}
chmod 777 ${FTP_HOME}/${DIRECTORY}

echo "Creating VSFTP user configuration."
cat > /etc/vsftpd_user_conf/${USER} <<EOF
local_root=/data/ftp/${DIRECTORY}
write_enable=YES
EOF
exit 0
