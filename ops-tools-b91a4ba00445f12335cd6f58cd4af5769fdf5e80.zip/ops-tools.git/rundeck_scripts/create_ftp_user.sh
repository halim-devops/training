#!/bin/bash

FTP_HOME=/data/ftp

if [[ $# -ne 1 ]]; then
    echo "Usage: `basename $0` username"
    exit 1
fi

if [[ $UID != 0 ]]; then
    echo "This script requires sudo privileges."
    echo "sudo $0 $*"
    exit 1
fi

USER=$1

if [ ! -d ${FTP_HOME}/${USER} ]; then
  echo "Creating directory ${FTP_HOME}/${USER}."
  mkdir ${FTP_HOME}/${USER}
else
  echo "Directory ${FTP_HOME}/${USER} already exists."
fi
chown -R vsftpd:nogroup ${FTP_HOME}/${USER}
chmod 777 ${FTP_HOME}/${USER}
exit 0
