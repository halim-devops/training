#!/bin/bash

echo Starting ACTIONS BATCH

export JAVA_HOME=$1
BATCH_HOME=$2
BATCH_SCRIPT=$3
PLATFORM=$4
BATCH_LOG=$5

sudo -E -u root chmod 777 $BATCH_LOG
sudo -E -u root $BATCH_HOME/$BATCH_SCRIPT $PLATFORM $BATCH_HOME >> $BATCH_LOG

echo End.
