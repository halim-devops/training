#!/bin/bash
# Script de scénario de test archive_backup.sh
# Génération de faux backup pour test

BACKUP_DIRECTORY="/net/backup/MYSQL/AL"

mkdir -p $BACKUP_DIRECTORY

BEGIN_DATE="2016-05-15"
END_DATE="2018-05-15"

#CURRENT_DATE =$(date "+%Y%m%d %H:%M")

#Set the Begin date
echo "Set date to begin date variable"
date +%Y-%m-%d -s $BEGIN_DATE
# Let's go
loop="go"
while [ "$loop" != "stop" ]; do 
	#echo ""
	#echo " **************************************************************************************"
	CURRENTDATE=$(date -I -d "$CURRENTDATE + 1 day")
	date -s $CURRENTDATE
	BACKUPDAY=$(date -I -d "$CURRENTDATE - 1 day")
	YEAR=`echo $BACKUPDAY | cut -d "-" -f1`
	MONTH=`echo $BACKUPDAY | cut -d "-" -f2`
        DAY=`echo $BACKUPDAY | cut -d "-" -f3`	
	NAME_DIRECTORY="$YEAR$MONTH$DAY"
#	echo "Creating $BACKUP_DIRECTORY/$NAME_DIRECTORY directory"
	for srv in fr_pral-mysmut02 ad_pral-mysmut04 de_pral-mysmut01 ii_pral-mysmut01 it_pral-mysmut01 cg_pral-mysmut01 uk_pral-mysmut05; do
		f=$(echo $srv|cut -d"_" -f1)
		mkdir -p $BACKUP_DIRECTORY/$NAME_DIRECTORY/$f && touch -d $BACKUPDAY $BACKUP_DIRECTORY/$NAME_DIRECTORY/$f/${srv}_${NAME_DIRECTORY}_1701.tar.gz
	done
	#	echo "Executing backup_archive.sh script"
#	bash  $SCRIPT "$CURRENTDATE"
	cur=$(date -d $CURRENTDATE +%s)
	end=$(date -d $END_DATE +%s)
	if [ $cur -ge $end ]; then
		loop="stop"
	fi
done
#date -s "$CURRENT_DATE"
