DELIMITER $$
CREATE DEFINER=`opsadmin`@`%` FUNCTION `get_common_sku_count`(site_1_id INTEGER, site_2_id INTEGER) RETURNS int(11)
    READS SQL DATA
    DETERMINISTIC
BEGIN

declare result integer ;

SELECT 
    COUNT(*)
INTO result FROM
    (SELECT 
        sku
    FROM
        (SELECT DISTINCT
        sku
    FROM
        site_product_identifiers sp2
    WHERE
        sp2.sid = site_1_id UNION ALL SELECT DISTINCT
        sku
    FROM
        site_product_identifiers sp3
    WHERE
        sp3.sid = site_2_id) combined_list
    GROUP BY sku
    HAVING COUNT(*) = 2) common_sku_list;
RETURN result; 
END$$
DELIMITER ;
