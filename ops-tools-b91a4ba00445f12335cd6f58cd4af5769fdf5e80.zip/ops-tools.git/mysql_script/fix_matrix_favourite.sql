DELIMITER $$
CREATE DEFINER=`root`@`%` PROCEDURE `fix_matrix_favourite`()
BEGIN

	DECLARE matrix_favourite_id INT;
	DECLARE roo_value_id INT;
	DECLARE local_charac_value_id INT;

	DECLARE done INT DEFAULT FALSE;
	DECLARE cur CURSOR for select 
		umf.id as matrix_favourite_id,
		umdcf.characteristic_id as roo_value_id,
		(select cv.id from characteristic_values cv where ct.id = cv.characteristic_type_id and c.descriptive_value = cv.value limit 1) as local_charac_value_id
		from user_matrix_favourites umf
		inner join user_matrix_display_characteristics_filter umdcf on umf.ID = umdcf.user_matrix_favourite_id
		inner join user_matrix_filter_values umfv on umfv.user_matrix_favourite_id = umf.ID
		inner join characteristic c on c.id = umdcf.characteristic_id
		inner join characteristic_types ct on ct.roo_characteristic_type_id = c.characteristic_type and ct.catalog_id = umfv.filter_id;

	DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = TRUE;

	OPEN cur;

	read_loop: LOOP
    FETCH cur INTO matrix_favourite_id, roo_value_id, local_charac_value_id;

    IF done THEN
      LEAVE read_loop;
    END IF;

    update user_matrix_display_characteristics_filter
	set characteristic_id = local_charac_value_id
	where user_matrix_favourite_id = matrix_favourite_id and characteristic_id = roo_value_id;

  	END LOOP;

  	CLOSE cur;
END$$
DELIMITER ;
