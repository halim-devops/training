#!/bin/bash

usage () {
    echo "`basename $0` <BACKUP REPOSITORY>"
    exit 1
}

if [[ $# -ne 1 ]]; then
    usage
fi

BACKUP_REPOSITORY=$1

find ${BACKUP_REPOSITORY}/XTRA -type d -mtime +30 -not -name "*01" -exec rm -rf {} \;
find ${BACKUP_REPOSITORY}/DATA -type f -mtime +30 -exec rm -rf {} \;

exit 0
