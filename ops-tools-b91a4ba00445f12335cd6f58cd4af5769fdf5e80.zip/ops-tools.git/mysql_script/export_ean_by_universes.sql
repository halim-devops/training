DELIMITER $$
CREATE DEFINER=`imoussa`@`%` PROCEDURE `export_ean_by_universes`(IN universes_name VARCHAR(50),IN universes_id INT,IN path VARCHAR(50),IN nb_line INT)
BEGIN
	DECLARE nb_ean INT;
	DECLARE index_file INT;
	DECLARE total_ean INT;
    
    SET nb_ean=0;
	SET index_file=1;
		
	SET @SQLString1 = CONCAT('SELECT COUNT(distinct(EAN)) INTO @total_ean FROM site_product_identifiers INNER JOIN site_product_instances ON site_product_instances.SITE_PRODUCT_IDENTIFIER_ID = site_product_identifiers.id where site_product_identifiers.EAN <> '''' and site_product_instances.RPID = ', universes_id);
	PREPARE total_ean_request FROM @SQLString1;
	EXECUTE total_ean_request;
		
	WHILE nb_ean <= @total_ean DO
			-- export the rows from select statement with limit nb_line
		SET @SQLString = CONCAT('SELECT distinct(EAN) FROM site_product_identifiers INNER JOIN site_product_instances ON site_product_instances.SITE_PRODUCT_IDENTIFIER_ID = site_product_identifiers.id where site_product_identifiers.EAN <> '''' and site_product_instances.RPID = ',universes_id,' LIMIT ',nb_ean,',',nb_line,' INTO OUTFILE "',path,universes_name,'-',index_file,'.csv" FIELDS TERMINATED BY '','' LINES TERMINATED BY ''\n''');
		PREPARE get_ean FROM @SQLString;
		EXECUTE get_ean;
		 
		SET nb_ean=nb_ean+nb_line;
		SET index_file=index_file+1;
	 
	END WHILE;
END$$
DELIMITER ;
