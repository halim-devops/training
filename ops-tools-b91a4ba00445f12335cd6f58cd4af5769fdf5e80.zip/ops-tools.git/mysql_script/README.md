# Besoin du package percona-xtrabackup
apt-get -f -y install percona-xtrabackup
# Besoin d'avoir le user backup
# DB_USER=backup-user
# DB_PASSWORD=b4cKup3r
# Dans la base 

