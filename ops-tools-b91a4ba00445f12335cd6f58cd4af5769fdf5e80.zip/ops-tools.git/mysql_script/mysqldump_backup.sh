#!/bin/bash

LOGIN=$1
PASS=$2
DB=$3
TIME=$4
typeset -u DBPATH
DBPATH=$DB
FULLPATH="/net/backup/MYSQL/$DBPATH"

export BCK_DAY=`date +%Y%m%d`
export BCK_TIME=`date +%H%M`

#echo $PASS

if [ -z $DBPATH ]
then
	exit 1
fi

mkdir -p $FULLPATH

echo "Dump of $DB  starting"

mysqldump -u $LOGIN -p"$PASS"  -c --add-drop-table --add-locks  --lock-tables --quick $DB > $FULLPATH/${DB}_dump_${BCK_DAY}_${BCK_TIME}.sql

if [ $? -ne 0 ]
then
	echo "Dump Failed"
	exit 1
fi

echo "Dump Succefully done"
echo "Compression starting"

gzip -f $FULLPATH/${DB}_dump_${BCK_DAY}_${BCK_TIME}.sql

if [ $? -ne 0 ]
then
	echo "Compression Failed"
        exit 1
fi

echo "Compression Succefully done"
#echo "Purge in progress"

#find $FULLPATH -mtime $TIME -ls -delete

#echo "Purge Done"
