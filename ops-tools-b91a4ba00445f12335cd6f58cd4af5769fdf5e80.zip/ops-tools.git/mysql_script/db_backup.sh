#!/bin/bash

export CONTACT="exploitation@workit-software.com"
export SENDMAIL="/usr/sbin/sendmail"
export TEMP_DATE=$(date +%Y%m%d)
export TEMP_MAIL="/tmp/mail.$TEMP_DATE.msg"

SOCKET=""
if [ ! -z "$1" ]; then
        VAL=$(sed -n "/\[mysqld\]/,/\[/{/socket/p}" /etc/mysql/$1/my.cnf|awk '{print $3}')
        SOCKET="--socket $VAL"
fi

function sendmessage {
        MSG="$1"
        echo "To: $CONTACT" > $TEMP_MAIL
        echo "Subject: [$HOSTNAME][BACKUP ALREADY IN PROGRESS][PREVIOUS JOBS NOT FINISHED ??]" >> $TEMP_MAIL
        echo "From: $HOSTNAME@workit.fr" >> $TEMP_MAIL
        echo "" >> $TEMP_MAIL
        echo "$MSG" >> $TEMP_MAIL
        $SENDMAIL -t < $TEMP_MAIL
}


SCRIPT=$(basename "$0")
NB_PROCESS=$(ps ux|grep $SCRIPT|grep -v grep|wc -l)
if [ "$NB_PROCESS" -gt 3 ]; then
        MSG="$$\n\nThe backup of mysql $HOSTNAME is already running.\n\nMaybe a previous jobs isn't finished properly.\n\nProcess LIST:\n"
        PROCESS=$(ps ux|grep $SCRIPT|grep -v grep)
        MSG=$(echo -e "$MSG$PROCESS")
        sendmessage "$MSG"
        exit 0
fi

export BCK_DAY=`date +%Y%m%d`
export BCK_TIME=`date +%H%M`

export BCK_ROOT=/net/backup/MYSQL

if [ $# -eq 1 ]; then
	if [ -d $1 ]; then
		BCK_ROOT="$1"
	fi
fi

export WIT_PLATFORM=`hostname -s| cut -c 3,4 | tr "[:lower:]" "[:upper:]"`
export CPU_COUNT=`facter physicalprocessorcount`
if [ ! -z "$1" ]; then
	export WRK_DIR=${BCK_ROOT}/${WIT_PLATFORM}/latest/`hostname -s`/$1
	export BCK_DIR=${BCK_ROOT}/${WIT_PLATFORM}/${BCK_DAY}/$1
	export ARCHIVE_FILE=${BCK_DIR}/$1_`hostname -s`_${BCK_DAY}_${BCK_TIME}.tar.gz
else
	export WRK_DIR=${BCK_ROOT}/${WIT_PLATFORM}/latest/`hostname -s`
	export BCK_DIR=${BCK_ROOT}/${WIT_PLATFORM}/${BCK_DAY}
	export ARCHIVE_FILE=${BCK_DIR}/mu_`hostname -s`_${BCK_DAY}_${BCK_TIME}.tar.gz
fi
export DB_USER=backup-user
export DB_PASSWORD=b4cKup3r

# delete the former backup
echo cleaning
rm -rf ${WRK_DIR}

# ensure directories existence
echo preparing
mkdir -p ${BCK_DIR}

echo backing up
# Backup the whole database
innobackupex $SOCKET \
 --user=${DB_USER} \
 --password=${DB_PASSWORD} \
 --parallel=${CPU_COUNT} \
 --no-lock \
 --no-timestamp \
 ${WRK_DIR}

echo post backup operation
# Prepare the backup before restoring it
innobackupex \
 --apply-log \
 ${WRK_DIR}

echo backupset compression
# Compress the backupset
tar -cpvzf \
 ${ARCHIVE_FILE} \
 -C ${WRK_DIR} . 

echo end
