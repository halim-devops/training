#/bin/bash
DEBUG=0
DUMPPATH=/net/backup/MYSQL/BACKUPS
YEAR=$(date +%Y)
MONTH=$(date +%m)
PLATFORMNUMBER=$(echo $(( ( RANDOM % 7 )  )))
PLATFORM=(ad cg de fr ii it uk)
PLATFORMDB=(workit_adhoc_v4 workit_cg_v4 workit_de_v4 workit_bgb_v4 workit_ii_v4 workit_it_v4 workit_uk_v4)
[ DEBUG == 1 ] && echo "Choose platform number: ${PLATFORMNUMBER}"
SELECTEDPF="${PLATFORM[${PLATFORMNUMBER}]}"
SELECTEDDB="${PLATFORMDB[${PLATFORMNUMBER}]}"
[ DEBUG == 1 ] && echo "=>: ${SELECTEDPF} ${SELECTEDDB}"
MAXDAY=$(ls $DUMPPATH/$YEAR/$MONTH | tail -1)
[ DEBUG == 1 ] && echo "=> MAXDAY=$MAXDAY"
RANDOMDAY=$(printf "%02d" $(( ( RANDOM % $MAXDAY ) + 1 )))
[ DEBUG == 1 ] && echo "=> RANDOMDAY=$RANDOMDAY"
FILE=$(find $DUMPPATH/$YEAR/$MONTH/$RANDOMDAY -name "*${SELECTEDPF}*.tar.gz")
echo "$FILE $SELECTEDDB"


