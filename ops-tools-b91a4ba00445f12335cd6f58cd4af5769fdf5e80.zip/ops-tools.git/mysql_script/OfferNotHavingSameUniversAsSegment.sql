DELIMITER $$
CREATE DEFINER=`opsadmin`@`%` PROCEDURE `OfferNotHavingSameUniverseAsSegment`()
BEGIN
        DECLARE var_offer_id INT DEFAULT 0;
        DECLARE var_segment_universe_id INT DEFAULT 0;
        DECLARE done INT DEFAULT 0;
        DECLARE curseur1 CURSOR FOR select ins.id as offer_id, parent.id as segment_universe_id from universes as child inner join universes as parent on parent.lft <= child.lft and parent.rgt >= child.rgt inner join site_product_instances ins on ins.pid = child.id where parent.id > 0  and parent.pid < 0 and ins.rpid <> parent.id LIMIT 0, 50000;
        DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;
 
        OPEN curseur1; 
        
        REPEAT
                FETCH curseur1 INTO var_offer_id, var_segment_universe_id;
                IF done = 0 THEN
                        update site_product_instances set rpid = var_segment_universe_id where id = var_offer_id; 
                END IF;
        UNTIL done
        END REPEAT;
 
        CLOSE curseur1; 
END$$
DELIMITER ;
