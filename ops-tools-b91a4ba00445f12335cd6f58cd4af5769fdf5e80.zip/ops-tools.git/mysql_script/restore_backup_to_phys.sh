#!/bin/bash

function usage {
        echo "sudo $0 <file to restore> <datadir>"
        exit 1
}

if [[ $EUID -ne 0 ]]; then
        echo "You must be root or sudoers"
        exit 1;
fi


if [ -z "$1" ]; then
        echo "File to restore mandatory";
        usage;
fi;

if [ -z "$2" ]; then
        echo "datadir mandatory";
        usage;
fi;

DATADIR="$2"

if [ ! -f "$1" ]; then
        echo "$1 is not a file";
fi

if [ ! -d "$DATADIR" ]; then
        echo "$DATADIR doesn't exist"
        exit
fi

echo "*** Mysql data dir: $DATADIR"

#DATE=$(date +%Y-%m-%d-%H-%M-%S)
#USER='root'
#PASS='W0rk1T!121!'

for pid in $(pgrep mysql); do
	echo "mysql must be shutdown $pid"
	exit 1
done;

echo "Removing $DATADIR/* before restore"
rm -rf $DATADIR/*

echo "Updating from dump"
tar xvfpz $1 -C $DATADIR/

echo "Updating rights"
chown -R mysql:mysql $DATADIR
echo "Database restored you can start-it"

echo "Restoration complete"
exit 0
