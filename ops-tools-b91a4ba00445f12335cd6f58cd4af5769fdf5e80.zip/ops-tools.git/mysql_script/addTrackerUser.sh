#!/bin/bash

TARGET=$1
REQUEST_USER=$2
REQUEST_PWD=$3
MYSQL_USER="opsadmin"
export MYSQL_PWD="W@rk1T!!!"



if [ -z "$TARGET" ]; then
		echo "TARGET mandatory"
		exit 1;
fi

if [ -z "$REQUEST_USER" ]; then
		echo "User mandatory"
		exit 1;
fi

if [ -z "$REQUEST_PWD" ]; then
		echo "Password mandatory"
		exit 1;
fi

typeset -l PLATFORM
PLATFORM="$(echo $TARGET | cut -c3-4)"
DATABASE="workit_${PLATFORM}_v4"
case "$PLATFORM" in 
"fr")
  DATABASE="workit_bgb_v4"
  ;;
"ad")
  DATABASE="workit_adhoc_v4"
  ;;
esac

REQUEST="$(cat <<EOF
INSERT INTO tr_users (login,password,b2b_user_id,b2b_admin_id,isconstructor,sid,disabled,email,prospect)
SELECT login, password, id, id, 0, -1, 0 , '', 0
FROM users
WHERE login = '$REQUEST_USER' AND password = '$REQUEST_PWD';
EOF
)"

echo $REQUEST >> /tmp/request.sql

/usr/bin/mysql -sN --user=${MYSQL_USER} --database=${DATABASE} -h ${TARGET} < /tmp/request.sql

rm /tmp/request.sql

exit 0;
