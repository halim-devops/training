#!/bin/bash
BACKUPTYPE=$1
BACKUPHOME=/net/backup/MYSQL
DATEBACKUP=$(date -d "1 day ago" '+%Y%m%d')
YEAR=$(date -d "1 day ago" '+%Y')
MONTH=$(date -d "1 day ago" '+%m')
DAY=$(date -d "1 day ago" '+%d')

if [ -z $BACKUPTYPE ]; then
        echo "Précisez le backup à checker W2P ou artifactory"
        exit 1
fi


if [ "$BACKUPTYPE" == "ARTIFACTORY" ];then
        find $BACKUPHOME/BACKUPS -name "pral-artifactmys01_${DATEBACKUP}*"  -type f | egrep '.*' > /dev/null 2>&1
        if [ $? -ne 0 ];then
                echo -1
        else
                echo 0
        fi
fi

if [ "$BACKUPTYPE" == "W2P" ];then
        find $BACKUPHOME/BACKUPS/$YEAR/$MONTH/$DAY -type f | egrep '.*' > /dev/null 2>&1
        if [ $? -ne 0 ]; then
                echo -1      
        else
                NB_BACKUP=$(find  $BACKUPHOME/BACKUPS/$YEAR/$MONTH/$DAY -type f | wc -l)
                if [ $NB_BACKUP -lt 7 ]; then
                        echo -1
                else
                        echo 0
                fi
        fi
fi
