#/bin/bash
DBNAME=$1
TARGETHOST=$2
USER=$3
PASSWORD="$4"

mysql -u "${USER}" -p${PASSWORD} -D "${DBNAME}" -h "${TARGETHOST}" -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='${DBNAME}'"
