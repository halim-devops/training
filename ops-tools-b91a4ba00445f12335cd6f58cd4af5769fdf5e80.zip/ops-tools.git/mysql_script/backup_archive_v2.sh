#!/bin/bash
# Set variable

function log {
	LOGDATE=$(date "+%Y%m%d-%H:%M:%S")
	echo " ${LOGDATE}: $1"
}

function checkCreateDirectory {
	DIRECTORY=$1
	log "        [checkCreateDirectory] Checking ${DIRECTORY}"
	if [ ! -d "${DIRECTORY}" ]; then
	        log "WARNING: Creating directory \"${DIRECTORY}\""
	        mkdir -p "${DIRECTORY}"
		if [ $? -ne 0 ];then
  		      log "Error creating folder \"${DIRECTORY}\""
		      exit 1
		fi
	fi
	DIRECTORY=""
}

function movingFilesToDirectory {
	LIST=$1
	DIRECTORY_MV=$2
	log "        [movingFilesDirectory] Checking ${DIRECTORY_MV}"
	for FILE_TO_BACKUP in ${LIST}; do
		FILE_FOLDER=$(basename $FILE_TO_BACKUP|sed 's|.._[^_]*_\([0-9]\{4\}\)\([0-9]\{2\}\)\([0-9]\{2\}\)_.*|\1/\2/\3|g')
		checkCreateDirectory "${DIRECTORY_MV}/${FILE_FOLDER}"
		mv -v ${FILE_TO_BACKUP} "${DIRECTORY_MV}/${FILE_FOLDER}/"
	done
	DIRECTORY_MV=""
}

function displayNumberOfBackups {
	FOLDER=$1
	MSG=$2
	log ""
	log " ************************************************"
	log " * ARCHIVE TYPE: ${MSG}"
	log " * FOLDER: ${FOLDER}"
	log " * INFO: Number of backups for each platform"
	log " *"
	#find $BACKUP_DIRECTORY -type f -regex ".*tar.gz" -ls
	LIST_SRV=$(find ${FOLDER} -type f -regex ".*tar.gz" |xargs -I % basename %|sed 's|\(.*\)[0-9]\{2\}_[0-9]\{8\}_[0-9]\{4\}.tar.gz|\1|g'|sort -u)
	for srv in $LIST_SRV; do
        	NB=$(find ${FOLDER} -type f -regex ".*${srv}.*tar.gz"|wc -l)
	        log " * ${srv} = ${NB} backups available"
	done;
	log " ************************************************"
	FOLDER=""
}
if [ ! -z $1 ]; then
	log "MODE DEBUG: changing current date to $1"
	date -s "$1"
fi

log "Start of archiving backups"
BACKUP_SOURCE_DIRECTORY="/net/backup/MYSQL/AL"
BACKUP_DIRECTORY="/net/backup/MYSQL/BACKUPS"
ARCHIVE_DIRECTORY="/net/backup/MYSQL/ARCHIVES"
ARCHIVE_DIRECTORY_YEARLY="/net/backup/MYSQL/ARCHIVES_YEARLY"

# Checking if the directory existing
checkCreateDirectory "${BACKUP_DIRECTORY}"
checkCreateDirectory "${ARCHIVE_DIRECTORY}"
checkCreateDirectory "${ARCHIVE_DIRECTORY_YEARLY}"


# Moving Last Backup on good directory
log "INFO: MOVING new backup in ${BACKUP_DIRECTORY} directory"
LIST=$(find $BACKUP_SOURCE_DIRECTORY -type f -regex ".*tar.gz")
movingFilesToDirectory "${LIST}" "${BACKUP_DIRECTORY}"

# Archivage de tous les fichiers de plus de 15j
log "INFO: MOVING backups to archive directory if older than 15 days"
LIST_BACK=$(find $BACKUP_DIRECTORY -mtime +15 -type f -regex ".*tar.gz")
movingFilesToDirectory "${LIST_BACK}" "${ARCHIVE_DIRECTORY}"


# Yearly Archivage
log "INFO: MOVING first of januray and july to ${ARCHIVE_DIRECTORY_YEARLY}"
LIST_YEAR=$(find $ARCHIVE_DIRECTORY -type f -mtime +365 -regextype posix-extended -regex ".*_[0-9]{4}0(1|7)01_[0-9]{4}.tar.gz")
movingFilesToDirectory "${LIST_YEAR}" "${ARCHIVE_DIRECTORY_YEARLY}"


# Apply daily purge
log "INFO: PURGING ${ARCHIVE_DIRECTORY} directory leaving only first of the month backup"
find $ARCHIVE_DIRECTORY  -type f -regextype posix-extended -not -regex ".*_[0-9]{6}01_[0-9]{4}.tar.gz" -ls -delete
if [ $? -ne 0 ];then
	log "ERROR: Cleaning other than first month failed!"
	exit 1
fi

# Apply monthly purge
########################################################################
# SCRIPT en mode DATE DANS LE FICHIER
# FAIT LA MEME CHOSE QUE LE FIND MAIS AVEC LE NOM DE FICHIER
# CAS OU LES FICHIERS ONT UNE DATE DE CREATION 1970...
########################################################################

#DATE_YEAR_AGO=$(date +%Y%m%d -d "1 year ago")
#LIST_TO_CLEAN=$(find $ARCHIVE_DIRECTORY -type f -mtime +335 -regextype posix-extended -regex ".*.tar.gz")
#for OLD_FILE in ${LIST_TO_CLEAN}; do
#	DATE_IN_FILE=$(basename $OLD_FILE|sed 's|.._[^_]*_\([0-9]\{4\}\)\([0-9]\{2\}\)\([0-9]\{2\}\)_.*|\1\2\3|g')
#	DATE_FILE=$(date -d "$DATE_IN_FILE"  +%Y%m%d)
#	if [[ $DATE_YEAR_AGO -gt $DATE_FILE ]]; then
#		rm $OLD_FILE
#	fi
#done;

log "INFO: PURGING ${ARCHIVE_DIRECTORY} directory leaving only 12 months of backups"
find $ARCHIVE_DIRECTORY -type f -mtime +365 -regextype posix-extended -regex ".*tar.gz" -ls -delete
if [ $? -ne 0 ];then
        log "ERROR: Cleaning monthly over one year failed!"
        exit 1
fi

displayNumberOfBackups "${BACKUP_DIRECTORY}" "15 sliding days"
displayNumberOfBackups "${ARCHIVE_DIRECTORY}" "12 sliding months"
displayNumberOfBackups "${ARCHIVE_DIRECTORY_YEARLY}" "Yearly backups"


# Clean all empty directory
log "INFO: Purge empty directory in ${BACKUP_SOURCE_DIRECTORY}"
find ${BACKUP_SOURCE_DIRECTORY} -empty -type d -ls -delete

log "INFO: Purge empty directory in ${BACKUP_DIRECTORY}"
find ${BACKUP_DIRECTORY} -empty -type d -ls -delete

log "INFO: Purge empty directory in ${ARCHIVE_DIRECTORY}"
find ${ARCHIVE_DIRECTORY} -empty -type d -ls -delete
log "End archiving backups"


