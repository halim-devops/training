#!/bin/bash
# Set variable

function log {
	LOGDATE=$(date "+%Y%m%d-%H:%M:%S")
	echo "${LOGDATE}: $1"
}

if [ ! -z $1 ]; then
	log "MODE DEBUG: changing current date to $1"
	date -s "$1"
fi

BACKUP_SOURCE_DIRECTORY="/net/backup/MYSQL/AL"
BACKUP_DIRECTORY="/net/backup/MYSQL/BACKUPS"
ARCHIVE_DIRECTORY="/net/backup/MYSQL/ARCHIVES"

# Checking if the directory existing
if [ ! -d "${ARCHIVE_DIRECTORY}" ]; then
	log "WARNING: THE BACKUP ARCHIVE _DIRECTORY NOT EXISTING"
	log "WARNING: CREATING _DIRECTORY \"$ARCHIVE_DIRECTORY\""
	mkdir ${ARCHIVE_DIRECTORY}
fi

# Checking if the directory existing
if [ ! -d "${BACKUP_DIRECTORY}" ]; then
        log "WARNING: THE BACKUP  _DIRECTORY NOT EXISTING"
        log "WARNING: CREATING _DIRECTORY \"$BACKUP_DIRECTORY\""
        mkdir ${BACKUP_DIRECTORY}
fi


# Moving Last Backup on good directory
log "INFO: MOVING in backup directory"
for FILE_TO_BACKUP in $(find $BACKUP_SOURCE_DIRECTORY -type f -regex ".*tar.gz") ; do
	FILE_FOLDER=$(basename $FILE_TO_BACKUP|sed 's|.._[^_]*_\([0-9]\{4\}\)\([0-9]\{2\}\)\([0-9]\{2\}\)_.*|\1/\2/\3|g')
	mkdir -p $BACKUP_DIRECTORY/$FILE_FOLDER
	mv -v $FILE_TO_BACKUP $BACKUP_DIRECTORY/$FILE_FOLDER/
done

# Archivage
log "INFO: MOVING to archive directory"
for FILE_TO_BACKUP in $(find $BACKUP_DIRECTORY -mtime +15 -type f -regex ".*tar.gz") ; do
        FILE_FOLDER=$(basename $FILE_TO_BACKUP|sed 's|.._[^_]*_\([0-9]\{4\}\)\([0-9]\{2\}\)\([0-9]\{2\}\)_.*|\1/\2/\3|g')
        mkdir -p $ARCHIVE_DIRECTORY/$FILE_FOLDER
        mv -v $FILE_TO_BACKUP $ARCHIVE_DIRECTORY/$FILE_FOLDER/
done



# Apply daily purge
log "INFO: Purging daily file older than 15 days"
find $ARCHIVE_DIRECTORY  -type f -mtime +15 -regextype posix-extended -not -regex ".*_[0-9]{6}01_[0-9]{4}.tar.gz" -ls -delete 
if [ $? -ne 0 ];then
	log "ERROR: Daily/Monthly failed!"
	exit 1
fi


find $ARCHIVE_DIRECTORY -type f -mtime +365 -regextype posix-extended -not -regex ".*_[0-9]{4}0(1|7)01_[0-9]{4}.tar.gz" -ls -delete
if [ $? -ne 0 ];then
        log "ERROR: Yealy Purge failed!"
        exit 1
fi


# Clean all empty directory

log "Purge source backup directory"
find ${BACKUP_SOURCE_DIRECTORY} -empty -type d -ls -delete

log "Purge backup directory"
find ${BACKUP_DIRECTORY} -empty -type d -ls -delete

log "Purge archive directory"
find ${ARCHIVE_DIRECTORY} -empty -type d -ls -delete
log "End backup script"


