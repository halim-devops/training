DELIMITER $$
CREATE DEFINER=`opsadmin`@`%` FUNCTION `get_sku_count`(site_id integer) RETURNS int(11)
    NO SQL
    DETERMINISTIC
BEGIN
declare result integer ;
SELECT count(DISTINCT
        sku) into result
    FROM
        site_product_identifiers sp2
    WHERE
        sp2.sid = site_id ;
RETURN result;
END$$
DELIMITER ;
