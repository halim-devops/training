#!/bin/bash
DELAY=30s
LOGFILE=/var/log/zabbix/FS_NFS_Check.log
DEBUG=${1:-0}
OPTTEST="ops_test.txt.$(hostname).$$"
DAY="$(date +%d)"
#
lineHeader=$(head -1 $LOGFILE)
if [ "${lineHeader}" != "#${DAY}" ]; then
	echo "#${DAY}" > $LOGFILE
fi

MOUNTED_REQUIRED=$(awk '/^[^#]/ ' /etc/fstab | grep -v "/home/nfs" |  grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}.*' | awk '{ print $1 }')
[ $DEBUG -eq 1 ] && echo "MOUNTED_REQUIRED=$MOUNTED_REQUIRED"
if [ "$MOUNTED_REQUIRED" != "" ] ;then
        for MOUNT in $MOUNTED_REQUIRED
        do
                [ $DEBUG -eq 1 ] && echo "MOUNT=$MOUNT"
                grep $MOUNT /proc/mounts > /dev/null
                if [ $? -ne 0 ]; then
                        echo "$(date +%Y%m%d-%H%M%S) - $MOUNT Not mounted" >> $LOGFILE
                        echo 1
                        exit 0
                fi
                # Check for ro file system that should not be ro
                MOUNT_POINT=$(awk '/^[^#]/ ' /etc/fstab |  grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}.*' | sed -e 's/[[:space:]]\+/#/g' | grep "^${MOUNT}#" |awk -F"#" '{print $2}')
                MOUNT_OPTIONS=$(awk '/^[^#]/ ' /etc/fstab |  grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}.*' | sed -e 's/[[:space:]]\+/#/g' | grep "^${MOUNT}#" |awk -F"#" '{print $4}')
                [ $DEBUG -eq 1 ] && echo "MOUNT_POINT=$MOUNT_POINT"
                [ $DEBUG -eq 1 ] && echo "MOUNT_OPTION=$MOUNT_OPTIONS"
                rofound=$(grep $MOUNT /proc/mounts |grep  "\sro[\s,]")
                if [ "${rofound}" != "" ]; then
                        romount=$(echo $MOUNT_OPTIONS | grep -w "ro")
                        if [ "${romount}" == "" ]; then
                                echo "$(date +%Y%m%d-%H%M%S) - $MOUNT seems to be RO. Check !!!" >> $LOGFILE
                                echo 1
                                exit 0
                        fi
                fi
        done

        MOUNTED_POINT_REQUIRED=$(awk '/^[^#]/ ' /etc/fstab | grep -v "/home/nfs" | grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}.*' | awk '{ print $2 }')
        if [ "$MOUNTED_POINT_REQUIRED" != "" ] ;then
                for MOUNTP in $MOUNTED_POINT_REQUIRED
                do
                        df --all 2> /dev/null |grep -w $MOUNTP > /dev/null
                        if [ $? -ne 0 ]; then
                                echo "$(date +%Y%m%d-%H%M%S) - $MOUNTP not mounted !!!" >> $LOGFILE
                                echo 1
                                exit 0
                        else
                                filter=$(echo $MOUNTP | grep -v -i ssl)
                                ISRO=$(awk '/^[^#]/ ' /etc/fstab | grep -v "/home/nfs" | grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}.*' | awk '{ print $4}' | grep ro)
                                if [ "${ISRO}" == "" ]; then
                                        if [ "${filter}" != "" ]; then
                                                # Try to write a file
                                                timeout $DELAY touch $MOUNTP/$OPTTEST
                                                if [ $? -eq 124 ]; then
                                                                echo "$(date +%Y%m%d-%H%M%S) - $MOUNTP has problem. Cannot write" >> $LOGFILE
                                                                echo 1
                                                                exit 0
                                                else
                                                        res=$(ls $MOUNTP/$OPTTEST | wc -l)
                                                        if [ $res -eq 0 ]; then
                                                                echo "$(date +%Y%m%d-%H%M%S) - $MOUNTP/$OPTTEST not found after touch command executed. Check." >> $LOGFILE
                                                                echo 1
                                                                exit 0
                                                        else
                                                                rm $MOUNTP/$OPTTEST
                                                        fi
                                                fi
                                        fi
                                fi
                        fi
                done
        else
                echo "$(date +%Y%m%d-%H%M%S) - Cannot determine mount point." >> $LOGFILE
                echo 1
                exit 0
        fi
fi
echo "$(date +%Y%m%d-%H%M%S) - OK" >> $LOGFILE
echo 0
exit 0

