#!/bin/bash 
DELAY=30s
LOGFILE=/var/log/zabbix/NFS_Check_$(date +%Y%m%d).log
echo "Starting checking NFS" >> $LOGFILE

MOUNTED_REQUIRED=$(awk '/^[^#]/ ' /etc/fstab | grep -v "/home/nfs" |  grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}.*' | awk '{ print $1 }')
if [ "$MOUNTED_REQUIRED" != "" ] ;then
        for MOUNT in $MOUNTED_REQUIRED
        do
                grep $MOUNT /proc/mounts > /dev/null
                if [ $? -ne 0 ]; then
                        echo "$MOUNT Not mounted" >> $LOGFILE
                        echo 1
                        exit 0
                fi
        done

        MOUNTED_POINT_REQUIRED=$(awk '/^[^#]/ ' /etc/fstab | grep -v "/home/nfs" | grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}.*' | awk '{ print $2 }')
        if [ "$MOUNTED_POINT_REQUIRED" != "" ] ;then
                for MOUNTP in $MOUNTED_POINT_REQUIRED
                do
                        df --all 2> /dev/null |grep -w $MOUNTP > /dev/null
                        if [ $? -ne 0 ]; then
                                echo "$MOUNTP not mounted !!!" >> $LOGFILE
                                echo 1
                                exit 0
                        else
				filter=$(echo $MOUNTP | grep -v -i ssl)
				ISRO=$(awk '/^[^#]/ ' /etc/fstab | grep -v "/home/nfs" | grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}.*' | awk '{ print $4}' | grep ro)
				if [ "${ISRO}" == "" ]; then
					if [ "${filter}" != "" ]; then
						# Try to write a file
						timeout $DELAY touch $MOUNTP/ops_test.txt
						if [ $? -eq 124 ]; then
								echo "$MOUNTP has problem. Cannot write" >> $LOGFILE
								echo 1
								exit 0
						else
							res=$(ls $MOUNTP/ops_test.txt | wc -l)
							if [ $res -eq 0 ]; then
								echo "ops_test.txt not found after touch command executed. Check." >> $LOGFILE
								echo 1
								exit 0
							else
                                       	        		rm $MOUNTP/ops_test.txt
                                       			fi
						fi
					fi
                                fi
                        fi
                done
        else
                echo "Cannot determine mount point." >> $LOGFILE
                echo 1
                exit 0
        fi
fi
echo "OK" >> $LOGFILE
echo 0
exit 0

