#!/bin/bash

URL="https://insight.workit-software.com/insight/rest/open/health"
TIMEOUT=30

res=$(curl -f -s -L -m $TIMEOUT $URL)
if [ $? -ne 0 ]; then
        echo "ERROR executing CURL to $URL" >> /var/log/zabbix/insight_health.log
        zabbix_sender -z "pral-opszab.workit.fr" -p 10051 -s "pral-monzab.workit.fr" -k "workit.insight.health" -o "1"
        exit 1
fi

json=$(echo $res | jq -e . >/dev/null 2>&1)
if [ $? -ne 0 ]; then
        echo "$(date +%Y%m%d) - ERROR bad formatted JSON from $URL" >> /var/log/zabbix/insight_health.log
        echo "$(date +%Y%m%d) - $res ">> /var/log/zabbix/insight_health.log
        zabbix_sender -z "pral-opszab.workit.fr" -p 10051 -s "pral-monzab.workit.fr" -k "workit.insight.health" -o "1"
        exit 1
fi
isGreen=$(echo $json |grep -i green > /dev/null 2>&1)
if [ $? -ne 0 ]; then
        echo "$(date +%Y%m%d) - GREEN status not found. Could be YELLOW or RED" >> /var/log/zabbix/insight_health.log
        echo "$(date +%Y%m%d) - $res" >> /var/log/zabbix/insight_health.log
        zabbix_sender -z "pral-opszab.workit.fr" -p 10051 -s "pral-monzab.workit.fr" -k "workit.insight.health" -o "1"
        exit 1
fi
zabbix_sender -z "pral-opszab.workit.fr" -p 10051 -s "pral-monzab.workit.fr" -k "workit.insight.health" -o "0"
echo "$(date +%Y%m%d) - Status OK - GREEN" >> /var/log/zabbix/insight_health.log
echo "$(date +%Y%m%d) - $res" >> /var/log/zabbix/insight_health.log

exit 0

