#!/bin/bash
# Get consumer on specific QUEUE and compare with expected value
QUEUE=$1
VALUES=$2

ips=$(curl -sb -H "Accept: application/json"  -u admin:'W@rk1T!!!' http://pral-cplrmq02.workit.fr:15672/api/consumers| jq '.[] | select(.queue.name == ("'$QUEUE'")) | .channel_details.name' | sed -e 's/"\([^:]*\):[0-9]* -> .*"/\1/' | sort |uniq )

# resolve name from ip
missing=""
for expectedServers in $2
do
	expectedIP=$(nslookup $expectedServers | grep -i address | awk '{print $2}' |tail -n 1)
	if [ "$expectedIP" != "" ]; then
		found=$(echo $ips | grep $expectedIP)
		if [ $? -ne 0 ]; then
			missing="$missing$expectedServers/$expectedIP;"

		fi
	else
		missing="$missingCannot find IP for $expectedServers;"
	fi
done
if [ "$missing" != "" ]; then
	echo "$missing"	
else
	echo "OK"
fi
