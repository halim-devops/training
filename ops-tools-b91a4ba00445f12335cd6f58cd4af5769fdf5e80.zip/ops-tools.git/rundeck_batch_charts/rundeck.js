var authtoken = 'yJHjyHmo0M4oe8sczSLRrG7bNCdv9GSd';
var historyUrl= 'getHistory.php';
var histoFilter='1d';

/*var tasks = [
{"startDate":new Date("Sun Dec 09 01:36:45 EST 2012"),"endDate":new Date("Sun Dec 09 02:36:45 EST 2012"),"taskName":"E Job","status":"RUNNING"},
{"startDate":new Date("Sun Dec 09 04:56:32 EST 2012"),"endDate":new Date("Sun Dec 09 06:35:47 EST 2012"),"taskName":"A Job","status":"RUNNING"},
{"startDate":new Date("Sun Dec 09 06:29:53 EST 2012"),"endDate":new Date("Sun Dec 09 06:34:04 EST 2012"),"taskName":"D Job","status":"RUNNING"},
{"startDate":new Date("Sun Dec 09 05:35:21 EST 2012"),"endDate":new Date("Sun Dec 09 06:21:22 EST 2012"),"taskName":"P Job","status":"RUNNING"},
{"startDate":new Date("Sun Dec 09 08:40:11 EST 2012"),"endDate":new Date("Sun Dec 09 08:46:35 EST 2012"),"taskName":"A Job","status":"SUCCEEDED"},
{"startDate":new Date("Sun Dec 09 08:00:03 EST 2012"),"endDate":new Date("Sun Dec 09 08:09:51 EST 2012"),"taskName":"D Job","status":"SUCCEEDED"},
{"startDate":new Date("Sun Dec 09 10:21:00 EST 2012"),"endDate":new Date("Sun Dec 09 10:51:42 EST 2012"),"taskName":"P Job","status":"SUCCEEDED"},
{"startDate":new Date("Sun Dec 09 11:08:42 EST 2012"),"endDate":new Date("Sun Dec 09 11:33:42 EST 2012"),"taskName":"N Job","status":"FAILED"},
{"startDate":new Date("Sun Dec 09 12:27:15 EST 2012"),"endDate":new Date("Sun Dec 09 12:54:56 EST 2012"),"taskName":"E Job","status":"SUCCEEDED"},
{"startDate":new Date("Sat Dec 08 23:12:24 EST 2012"),"endDate":new Date("Sun Dec 09 00:26:13 EST 2012"),"taskName":"A Job","status":"KILLED"}];
*/
var tasks = [];

var taskStatus = {
    "SUCCEEDED" : "bar",
    "FAILED" : "bar-failed",
    "RUNNING" : "bar-running",
    "KILLED" : "bar-killed"
};

//var taskNames = [ "D Job", "P Job", "E Job", "A Job", "N Job" ];
var taskNames = [ ];


var format = "%d/%m/%y - %H:%M";


function updateHistory(token,filter){
	var url_histo= historyUrl + "?authtoken=" + token + "&recentFilter=" +filter ;
        $.ajax({
        	url: url_histo,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function(response) {
                	updateOutput(response);
                },
                error: function(error) {
	                console.log(error);
                }
        });
}

var maxDate, minDate;

function updateOutput(response){
	console.log(response);
	var list = response.events;
	for(var i = 0; i < list.length; i++){
		var element = list[i];
		if(taskNames.indexOf(element.title)<0){
			taskNames.push(element.title);
		}
		var json = {"startDate": new Date(element["date-started"]), "endDate": new Date(element["date-ended"]), "taskName": element.title, "status": element.status.toUpperCase()}
		tasks.push(json);
		json = null;
	}

	console.log(taskNames);
	console.log(tasks);
	tasks.sort(function(a, b) {
		return a.endDate - b.endDate;
	});
	maxDate = tasks[tasks.length - 1].endDate;
	tasks.sort(function(a, b) {
		return a.startDate - b.startDate;
	});
	minDate = tasks[0].startDate;
	var gantt = d3.gantt().taskTypes(taskNames).taskStatus(taskStatus).tickFormat(format);
	gantt(tasks);
}


updateHistory(authtoken,histoFilter);


