<?php
$token=$_GET['authtoken'];
$filter=$_GET['recentFilter'];
$command="curl  -s -H 'Accept: application/json' -X GET 'http://pral-rdk01.workit.fr:4440/api/14/project/Exporter/history?authtoken=$token&recentFilter=$filter&max=400'";
echo shell_exec($command);
?>
